/**
 * Options for writing a WAVE file.
 *
 * @group Utilities
 */
export interface WaveWriteOptions {
    /**
     * If true, the gain of the entire song will be adjusted,
     * so the loudest sample (by absolute value) becomes 32,767 or -32,767. Recommended.
     */
    normalizeAudio: boolean;
    /**
     * The loop start and end points. Undefined if no loop should be written.
     * The loop will be written to the file (using the `cue ` chunk)
     */
    loop?: {
        /**
         * The start point in seconds.
         */
        start: number;
        /**
         * The end point in seconds.
         */
        end: number;
    };
    /**
     * The metadata to write into the file.
     *
     * The metadata uses the `INFO` chunk to write the information.
     * It is encoded with `utf-8`
     */
    metadata: Partial<WaveMetadata>;
}

/**
 * The result of reading a WAVE file with {@link wavToAudio}.
 *
 * @group Utilities
 */
export interface WaveReadResult {
    /**
     * The PCM audio data, one array per channel.
     */
    audioData: Float32Array[];
    /**
     * The sample rate, in Hertz.
     */
    sampleRate: number;
    /**
     * The loop of the file, undefined if it has none.
     * The points are in sample frames, not seconds.
     */
    loop?: {
        /**
         * The loop start, in sample frames.
         */
        start: number;
        /**
         * The loop end, in sample frames.
         */
        end: number;
    };
}

/**
 * Metadata to write into a WAVE file.
 *
 * @group Utilities
 */
export interface WaveMetadata {
    /**
     * The song's title.
     * This writes to the `INAM` chunk.
     */
    title: string;
    /**
     * The song's artist.
     * This writes to the `IART` chunk.
     */
    artist: string;
    /**
     * The song's album.
     * This writes to the `IPRD` chunk.
     */
    album: string;
    /**
     * The song's genre.
     * This writes to the `IGNR` chunk.
     */
    genre: string;
}
