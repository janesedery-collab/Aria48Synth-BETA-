import { GSInsertionControlSources } from "../../enums";
import { DEFAULT_DRUM_REVERB, resetChannelInternal, resetRP15 } from "./reset";
import { renderVoice, VoiceSendBuffer } from "./render_voice";
import { controllerChange } from "./controller_change";
import { dataEntry } from "./data_entry";
import { noteOn } from "./note_on";
import { noteOff } from "./note_off";
import { programChange } from "./program_change";
import {
    CONTROLLER_TABLE_SIZE,
    GENERATOR_OVERRIDE_NO_CHANGE_VALUE,
    MIDI_DRUM_CHANNEL,
    SPESSASYNTH_GAIN_FACTOR
} from "../synth_constants";
import { DynamicModulatorManager } from "./dynamic_modulator_system";
import {
    computeModulator,
    computeModulators
} from "../voice/compute_modulator";
import {
    GeneratorLimits,
    GENERATORS_AMOUNT,
    type GeneratorType
} from "../../../soundbank/basic_soundbank/generator_types";
import type { SpessaSynthProcessor } from "../../processor";
import { ModulatorControllerSources } from "../../../soundbank/enums";
import type { MIDIPatch } from "../../../soundbank/basic_soundbank/midi_patch";
import { BankSelectHacks } from "../../../utils/midi_hacks";
import {
    applySnapshot,
    type ChannelSnapshot,
    getChannelSnapshot
} from "./channel_snapshot";
import type { ChannelGenerators } from "./awe32_nrpn";
import {
    type ChannelMIDIParameter,
    DEFAULT_CHANNEL_MIDI_PARAMETERS,
    lockMIDIParameterInternal,
    setMIDIParameterInternal
} from "./parameters/midi";
import {
    type ChannelSystemParameter,
    DEFAULT_CHANNEL_SYSTEM_PARAMETERS,
    setSystemParameterInternal
} from "./parameters/system";
import type { MIDISystem } from "../../../soundbank/types";
import type { MIDIController } from "../../../midi/enums";

import type { SynthesizerPatch } from "../../types";
import { DrumParameterUtils as DrumParameterUtilities } from "../../../midi/drum_parameters";
import type { DrumParameter } from "../../../midi/types";
import type { CustomChannelVibrato } from "./types";
import type { Voice } from "../voice/voice";
import { SpessaLog } from "../../../utils/loggin";
import {
    DEFAULT_GS_DRUM_MAP,
    DEFAULT_XG_DRUM_MAP,
    MELODIC_MAP
} from "../../../midi/midi_tools/sysex_data";

/**
 * This class represents a single MIDI channel within a {@link SpessaSynthProcessor}.
 *
 * In terms of old sound modules, it can also be considered a "Part", since the receiving MIDI channel number can be changed.
 *
 * @group Synthesizer.Channel
 */
export class MIDIChannel {
    /**
     * An array for the MIDI 2.0 Per-note pitch wheels.
     * @internal
     */
    public readonly pitchWheels = new Int16Array(128).fill(8192);

    /**
     * An array of poly pressure values for the channel.
     * Poly pressure persists across notes, much like per-note pitch wheels.
     * @internal
     */
    public readonly polyPressures = new Uint8Array(128);

    /**
     * Parameters for each drum instrument.
     * @internal
     */
    public readonly drumParams: readonly DrumParameter[] = Array.from(
        { length: 128 },
        // eslint-disable-next-line unicorn/consistent-function-scoping
        (_, index) => ({ ...DrumParameterUtilities.DEFAULT_DATA[index] })
    );
    /**
     * A system for dynamic modulator assignment for advanced system exclusives.
     * @internal
     */
    public readonly dynamicModulators;
    /**
     * SF2 NRPN LSB for selecting a generator value.
     * @internal
     */
    public sf2NRPNGeneratorLSB = 0;
    /**
     * The currently selected MIDI patch of the channel.
     * > **Note**
     * >
     * > The exact matching preset may not be available in the sound bank list,
     * > but this property represents exactly what MIDI asks for.
     */
    public readonly patch: MIDIPatch = {
        bankMSB: 0,
        bankLSB: 0,
        program: 0,
        isGMGSDrum: false
    };
    /**
     * The preset currently assigned to the channel.
     * This property can be set to directly replace a preset on this channel.
     *
     * > **Note**
     * >
     * > This may be undefined in some cases.
     *
     */
    public preset?: SynthesizerPatch;
    /**
     * Indicates the MIDI system when the preset was locked.
     * @internal
     */
    public lockedSystem: MIDISystem = "gs";
    /**
     * The channel's number (0-based index).
     */
    public readonly channel: number;

    /**
     * The vibrato settings for the channel.
     * @internal
     */
    public readonly customVibrato: CustomChannelVibrato = {
        delay: 0,
        depth: 0,
        rate: 0
    };
    /**
     * Core synthesis engine.
     * @internal
     */
    public readonly synthCore: SpessaSynthProcessor;

    /**
     * If true, this skips sends as they all go through insertion.
     * Set by {@link SpessaSynthProcessor}.
     * @internal
     */
    public xgInsertionAssigned = false;

    /**
     * Current left PCM output of this channel. Will be routed to either EFX or EQ if needed, and extracted for visualization.
     * Always 0-based index.
     * Double precision, as voices accumulate into it (faster than float32 in JS).
     * @internal
     */
    public readonly outputLeft: Float64Array;
    /**
     * Current right PCM output of this channel. Will be routed to either EFX or EQ if needed, and extracted for visualization.
     * Always 0-based index.
     * Double precision, as voices accumulate into it (faster than float32 in JS).
     * @internal
     */
    public readonly outputRight: Float64Array;
    /**
     * If the output buffers may contain audio.
     * If not, clearing and mixing them can be skipped.
     * Set by {@link SpessaSynthProcessor}.
     * @internal
     */
    public outputDirty = true;
    /**
     * The voice send buffers of this channel.
     * Used for grouping sends for better performance.
     * @internal
     */
    public readonly voiceSendBuffers: VoiceSendBuffer[] = [];
    /**
     * The number of voice send buffers used in the current rendering block.
     * @internal
     */
    public voiceSendBufferCount = 0;
    /**
     * Sets a channel MIDI parameter of the synthesizer.
     * @param parameter The type of the channel MIDI parameter to set.
     * @param value The value to set for the channel MIDI parameter.
     * @internal
     */
    public readonly setMIDIParameter: typeof setMIDIParameterInternal =
        setMIDIParameterInternal.bind(this);
    /**
     * An array indicating if a controller, at the equivalent index in the {@link MIDIChannel.midiControllers `midiControllers`} array, is locked
     * (i.e., not allowed changing).
     * A locked controller cannot be modified.
     * @internal
     */
    protected readonly lockedControllers = new Array(
        CONTROLLER_TABLE_SIZE
    ).fill(false) as boolean[];

    /*
    =================
    END OF PUBLIC API
    =================
     */
    /**
     * An array of MIDI controllers for the channel.
     * This array is used to store the state of various MIDI controllers
     * such as volume, pan, modulation, etc.
     * @remarks
     * A bit of an explanation:
     * The controller table is stored as an int16 array, it stores 14-bit values, allowing for full 14-bit LSB resolution.
     * The only exception from this are the Registered and Non-Registered Parameter Numbers.
     * Data entries do store it!
     * @internal
     */
    protected readonly _midiControllers: Int16Array = new Int16Array(
        CONTROLLER_TABLE_SIZE
    );
    /**
     * An array of octave tuning values for each note on the channel.
     * Each index corresponds to a note (0 = C, 1 = C#, ..., 11 = B).
     * Note: Repeated every 12 notes.
     * @internal
     */
    protected readonly octaveTuning: Int8Array = new Int8Array(128);
    /**
     * https://amei.or.jp/midistandardcommittee/Recommended_Practice/e/rp15.pdf
     * Reset controllers according to RP-15 Recommended Practice.
     * @internal
     */
    protected readonly resetRP15 = resetRP15.bind(this);
    /**
     * Executes a data entry (MSB or LSB) change for the current channel.
     * The value is read from the controller table and applied to the selected RPN or NRPN.
     * @internal
     */
    protected readonly dataEntry = dataEntry.bind(this);
    /**
     * An object indicating if a Channel MIDI parameter, at the equivalent key, is locked
     * (i.e., not allowed changing).
     * A locked parameter cannot be modified.
     * @internal
     */
    protected readonly lockedMIDIParameters = Object.fromEntries(
        // This funky code takes DEFAULT_PARAMETERS and sets the values to false
        (
            Object.keys(
                DEFAULT_CHANNEL_MIDI_PARAMETERS
            ) as (keyof ChannelMIDIParameter)[]
        ).map((key) => [key, false])
    ) as Record<keyof ChannelMIDIParameter, boolean>;
    /** @internal*/
    protected readonly _midiParameters: Readonly<ChannelMIDIParameter> = {
        ...DEFAULT_CHANNEL_MIDI_PARAMETERS
    };
    /**
     * All system parameters of this channel.
     * @internal
     */
    protected readonly _systemParameters: Readonly<ChannelSystemParameter> = {
        ...DEFAULT_CHANNEL_SYSTEM_PARAMETERS
    }; // Copy, not set!
    /**
     * Note On message tracking, for grouping voices for specific Note On messages.
     * Used for overlapping Note Ons.
     * MIDI note: current note on ID
     * @protected
     * @internal
     */
    protected readonly noteOnID = new Array<number>(128).fill(0);
    /**
     * Note Off message tracking, for grouping voices for specific Note On messages.
     * Used for overlapping Note Ons.
     * MIDI note: current note on ID
     * @protected
     * @internal
     */
    protected readonly noteOffID = new Array<number>(128).fill(0);
    /**
     * If the last Parameter was RPN.
     * If false then the last parameter was NRPN.
     * @protected
     * @internal
     */
    protected lastParameterIsRegistered = true;
    /**
     * Per-note pitch wheel mode uses the pitchWheels table as source
     * instead of the regular entry in the midiControllers table.
     * @internal
     */
    protected perNotePitch = false;
    /**
     * Current pan in range [-500;500]
     * Updated in `updateInternalParams`.
     * This is used to avoid a big addition for every voice rendering call.
     * @internal
     */
    protected currentPan = 0;
    /**
     * Current tuning in cents.
     * Updated in `updateInternalParams`.
     * This is used to avoid a big addition for every voice rendering call.
     * @internal
     */
    protected currentTuning = 0;
    /**
     * Current key-shift.
     * Updated in `updateInternalParams`.
     * @internal
     */
    protected currentKeyShift = 0;
    /**
     * Current gain.
     * Updated in `updateInternalParams`.
     * This is used to avoid a big multiplication for every voice rendering call.
     * @internal
     */
    protected currentGain = 0;
    /**
     * The last pressed note on this channel for portamento tracking.
     * -1 means none.
     * This is not a `ChannelMIDIParameter` and is strictly internal,
     * mostly because we don't want to send events for every note on message.
     * It can be set with Portamento Control CC anyway.
     * @protected
     * @internal
     */
    protected lastPortamentoNote = -1;
    /**
     * If the portamento should be executed once regardless of Portamento on/off.
     * Adhering to the MIDI spec, CC#84 ignores on/off.
     * This is also not a `ChannelMIDIParameter` for the same reason as `lastPortamentoNote`
     * @protected
     * @internal
     */
    protected portamentoForce = false;
    /**
     * The last pressed note on this channel in mono mode.
     * Used for tracking and releasing this note on a new Note On event.
     * -1 means none.
     * @protected
     * @internal
     */
    protected lastMonoNote = -1;
    /**
     * The last pressed note's velocity on this channel in mono mode.
     * @protected
     * @internal
     */
    protected lastMonoVelocity = 0;
    /**
     * For Mono Mode restoring notes.
     * playingNotes[midiNote]
     * @protected
     * @internal
     */
    protected readonly playingNotes = new Array<boolean>(128).fill(false);
    /**
     * Used for handling SF2/AWE32 NRPN generator adjustments.
     * @internal
     */
    protected readonly generators: ChannelGenerators = {
        offsets: new Int16Array(GENERATORS_AMOUNT),
        offsetsEnabled: false,
        overrides: new Int16Array(GENERATORS_AMOUNT),
        overridesEnabled: false
    };
    /** @internal*/
    protected readonly computeModulator = computeModulator.bind(this);
    /** @internal*/
    protected readonly computeModulators = computeModulators.bind(this);

    /**
     * Constructs a new MIDI channel.
     * @internal
     */
    public constructor(
        synthProperties: SpessaSynthProcessor,
        preset: SynthesizerPatch | undefined,
        drumPreset: SynthesizerPatch | undefined,
        channelNumber: number
    ) {
        this.synthCore = synthProperties;
        this.preset = preset;
        this.channel = channelNumber;
        this.outputLeft = new Float64Array(this.synthCore.maxBufferSize);
        this.outputRight = new Float64Array(this.synthCore.maxBufferSize);

        this.noteOn = noteOn.bind(this);
        this.noteOff = noteOff.bind(this);
        this.controllerChange = controllerChange.bind(this);
        this.programChange = programChange.bind(this);
        this.lockMIDIParameter = lockMIDIParameterInternal.bind(this);
        this.setSystemParameter = setSystemParameterInternal.bind(this);
        this.reset = resetChannelInternal.bind(this);
        this.renderVoice = renderVoice.bind(this);

        // @ts-expect-error Rx Channel init here!
        this._midiParameters.rxChannel = channelNumber;
        this.dynamicModulators = new DynamicModulatorManager(channelNumber);
        // Init
        this.resetGeneratorOverrides();
        this.resetGeneratorOffsets();
        this.resetDrumParams();
        this.resetVibratoParams();
        // Drum preset
        if (this.channel % 16 === MIDI_DRUM_CHANNEL) {
            if (drumPreset) {
                this.preset = drumPreset;
                this.patch.program = drumPreset.program;
                this.patch.bankLSB = drumPreset.bankLSB;
                this.patch.bankMSB = drumPreset.bankMSB;
                this.patch.isGMGSDrum = drumPreset.isGMGSDrum;
            }
            this.setDrumFlag(true);
        }
    }

    /**
     * Current amount of voices that are playing on this channel.
     * @internal
     */
    protected _voiceCount = 0;

    /**
     * Current amount of voices that are playing on this channel.
     */
    public get voiceCount(): number {
        return this._voiceCount;
    }

    /**
     * Current amount of voices that are playing on this channel.
     * @internal
     */
    public set voiceCount(value: number) {
        this._voiceCount = value;
    }

    /**
     * Indicates whether this channel is a drum channel.
     * @internal
     */
    protected _drumChannel = false;

    /**
     * Indicates whether this channel is a drum channel.
     */
    public get drumChannel() {
        return this._drumChannel;
    }

    // noinspection JSUnusedGlobalSymbols
    /**
     * An array of MIDI controllers for the channel.
     * This array is used to store the state of various MIDI controllers
     * such as volume, pan, modulation, etc.
     *
     * > **Note**
     * >
     * > A bit of an explanation:
     * > The controller table is stored as an `Int16Array`,
     * > it stores 14-bit values, allowing for full 14-bit LSB resolution.
     * > The only exception from this are
     * > the Registered and Non-Registered Parameter Numbers.
     * > Data entries do store it!
     *
     * > **Warning**
     * >
     * > Readonly, do not modify directly!
     */
    public get midiControllers() {
        return this._midiControllers as Readonly<Int16Array>;
    }

    // noinspection JSUnusedGlobalSymbols
    /**
     * The Channel System Parameters of this channel.
     * These are only editable via the API.
     *
     * Use {@link MIDIChannel.setSystemParameter} to set them.
     */
    public get systemParameters(): Readonly<ChannelSystemParameter> {
        return this._systemParameters;
    }

    /**
     * The Channel MIDI Parameters of this channel.
     * These are only editable via MIDI messages.
     */
    public get midiParameters(): Readonly<ChannelMIDIParameter> {
        return this._midiParameters;
    }

    /** @internal */
    public get channelSystem(): MIDISystem {
        return this._systemParameters.presetLock
            ? this.lockedSystem
            : this.synthCore.midiParameters.system;
    }

    /*
    ==========
    PUBLIC API
    ==========
     */
    /**
     * Sets a system parameter of the channel.
     * @param parameter The type of the system parameter to set.
     * @param value The value to set for the system parameter.
     */
    public setSystemParameter<P extends keyof ChannelSystemParameter>(
        parameter: P,
        value: ChannelSystemParameter[P]
    ) {
        // Patched with core in the constructor.
        void parameter;
        void value;
    }

    // noinspection JSUnusedGlobalSymbols
    /**
     * Locks or unlocks a given Channel MIDI Parameter.
     * This prevents any changes to it until it's unlocked.
     * @param parameter The Channel MIDI Parameter to lock.
     * @param isLocked If the parameter should be locked.
     */
    public lockMIDIParameter(
        parameter: keyof ChannelMIDIParameter,
        isLocked: boolean
    ) {
        // Patched with core in the constructor.
        void parameter;
        void isLocked;
    }

    // MIDI messages
    /**
     * Sends a "MIDI Note on" message and starts a note.
     * @param midiNote The MIDI note number (0-127).
     * @param velocity The velocity of the note (0-127). If less than 1, it will send a note off instead.
     * @param emit If the note on should be updated and emitted (non-internal)
     * @internal
     */
    public noteOn(midiNote: number, velocity: number, emit = true) {
        // Patched with core in the constructor.
        void midiNote;
        void velocity;
        void emit;
    }

    /**
     * Releases a note by its MIDI note number.
     * If the synthesizer is in high performance mode and the channel is not a drum channel,
     * or the drum channel has an rxNoteOff enabled,
     * it kills the note instead of releasing it.
     * @param midiNote The MIDI note number to release (0-127).
     * @internal
     */
    public noteOff(midiNote: number) {
        // Patched with core in the constructor.
        void midiNote;
    }

    /**
     * Changes the program (preset) of the channel.
     * @param programNumber The program number (0-127) to change to.
     * @internal
     */
    public programChange(programNumber: number) {
        // Patched with core in the constructor.
        void programNumber;
    }

    // CC (Continuous Controller)
    /**
     * Handles MIDI controller changes for a channel.
     * @param controller The MIDI controller number (0-127).
     * @param value The value of the controller (0-127).
     * @param sendEvent If an event should be emitted.
     * @remarks
     * This function processes MIDI controller changes, updating the channel's
     * midiControllers table and handling special cases like bank select,
     * data entry, and sustain pedal. It also computes modulators for all voices
     * in the channel based on the controller change.
     * @internal
     */
    public controllerChange(
        controller: MIDIController,
        value: number,
        sendEvent = true
    ) {
        // Patched with core in the constructor.
        void controller;
        void value;
        void sendEvent;
    }

    /*
    ==========
    PUBLIC API
    ==========
     */

    /**
     * Reset this channel to its default state.
     * Except for the locked controllers.
     * @param sendEvent If controller change events should be emitted for the reset controllers.
     * @internal
     */
    public reset(sendEvent = true) {
        // Patched with core in the constructor.
        void sendEvent;
    }

    /*
    =================
    END OF PUBLIC API
    =================
    */

    // Voice rendering methods
    /**
     * Renders a voice into one of the channel's voice send buffers,
     * which are later mixed into the stereo output and the effect sends.
     * @param voice the voice to render
     * @param timeNow current time in seconds
     * @param sampleCount the number of samples to render (the buffers are 0-based, so no offset is needed)
     * @internal
     */
    public renderVoice(voice: Voice, timeNow: number, sampleCount: number) {
        // Patched with core in the constructor.
        void voice;
        void timeNow;
        void sampleCount;
    }

    /*
    ==========
    PUBLIC API
    ==========
     */

    // noinspection JSUnusedGlobalSymbols
    /**
     * Locks or unlocks a given MIDI controller.
     * This prevents any changes to it until it's unlocked.
     * @param controller The MIDI controller number (0-127).
     * @param isLocked If the controller should be locked.
     */
    public lockController(
        this: MIDIChannel,
        controller: MIDIController,
        isLocked: boolean
    ) {
        this.lockedControllers[controller] = isLocked;
    }

    /**
     * Toggles drums on the channel and keeps the current program number.
     * Executes a program change so the change is immediately audible.
     *
     * > **Note**
     * >
     * > This does _not_ bypass {@link ChannelSystemParameter.presetLock `presetLock`}.
     *
     * @param isDrum If the channel should be a drum channel or not.
     */
    public setDrums(isDrum: boolean) {
        if (this._systemParameters.presetLock) return;

        if (BankSelectHacks.isSystemXG(this.channelSystem)) {
            if (isDrum) {
                if (BankSelectHacks.isXGDrum(this.patch.bankMSB)) return;
                this.setBankMSB(
                    BankSelectHacks.getDrumBank(this.channelSystem)
                );
            } else {
                if (this.channel % 16 === MIDI_DRUM_CHANNEL) {
                    SpessaLog.warn(
                        `Cannot disable drums on channel ${this.channel} for XG.`
                    );
                    return;
                }
                this.setBankMSB(
                    BankSelectHacks.getDefaultBank(this.channelSystem)
                );
            }

            // Commit the changes and return
            this.programChange(this.patch.program);
            return;
        }
        if (isDrum === this._drumChannel) return;
        // Flip the drums for GS
        this.setIsGMGSDrum(isDrum);
        this.programChange(this.patch.program);
        // Fallback if no preset matched and the flag didn't sync
        this.setDrumFlag(isDrum);
    }

    /**
     * Stops all notes on the channel.
     * @param force If true, stops all notes immediately,
     * otherwise applies release time.
     */
    public stopAllNotes(force = false) {
        // Clear IDs
        this.noteOnID.fill(0);
        this.noteOffID.fill(0);
        this.playingNotes.fill(false);
        if (force) {
            // Force stop all
            let vc = 0;
            if (this._voiceCount > 0)
                for (const v of this.synthCore.voices) {
                    if (v.channel === this.channel && v.isActive) {
                        v.isActive = false;
                        if (++vc >= this._voiceCount) break; // We already checked all the voices
                    }
                }
            this.clearVoiceCount();
        } else {
            // Gracefully stop
            let vc = 0;
            if (this._voiceCount > 0)
                for (const v of this.synthCore.voices) {
                    if (v.channel === this.channel && v.isActive) {
                        v.releaseVoice(this.synthCore.currentTime);
                        if (++vc >= this._voiceCount) break; // We already checked all the voices
                    }
                }
        }
        this.synthCore.callEvent("stopAll", {
            channel: this.channel,
            force
        });
    }

    /*
    =================
    END OF PUBLIC API
    =================
     */

    /**
     * @internal
     */
    public clearVoiceCount() {
        this._voiceCount = 0;
    }

    /**
     * Sets the octave tuning for a given channel.
     * @param tuning The tuning array of 12 values, each representing the tuning for a note in the octave.
     * @remarks
     * Cent tunings are relative.
     * @internal
     */
    public setOctaveTuning(tuning: Int8Array) {
        if (tuning.length !== 12) {
            throw new Error("Tuning is not the length of 12.");
        }
        for (let index = 0; index < 128; index++) {
            this.octaveTuning[index] = tuning[index % 12];
        }
    }

    /**
     * Passes a controller to the EFX control sources of the GS insertion block if this part has EFX assigned.
     * @param source The controller: a control change number or a {@link GSInsertionControlSources} value.
     * @param value The controller value (14-bit for pitch bend).
     * @internal
     */
    public efxControl(source: number, value: number) {
        if (
            source !== GSInsertionControlSources.off &&
            this._midiParameters.efxAssign
        ) {
            this.synthCore.gsInsertionBlock.setControllerValue(source, value);
        }
    }

    /**
     * Sets the pitch of the given channel.
     * @param pitch The pitch (0 - 16383)
     * @param midiNote The MIDI note number, pass -1 for the regular pitch wheel
     * @internal
     */
    public pitchWheel(pitch: number, midiNote = -1) {
        if (midiNote === -1) {
            // Disable the per note pitch mode
            this.perNotePitch = false;
            this.setMIDIParameter("pitchWheel", pitch);
        } else {
            if (!this.perNotePitch) {
                // Enable the per-note pitch (fill the pitches with the current CC value)
                this.pitchWheels.fill(this._midiParameters.pitchWheel);
            }
            this.perNotePitch = true;

            this.pitchWheels[midiNote] = pitch;

            // Recompute only specific modulators
            this.computeModulatorsAll(0, ModulatorControllerSources.pitchWheel);
        }
    }

    /**
     * Sets the pressure of the given note on a specific channel.
     * This is used for polyphonic pressure (aftertouch).
     * @param midiNote 0 - 127, the MIDI note number to set the pressure for.
     * @param pressure 0 - 127, the pressure value to set for the note.
     * @internal
     */
    public polyPressure(midiNote: number, pressure: number) {
        // Note to self: Store the pressure first, the modulators read it
        this.polyPressures[midiNote] = pressure;
        this.computeModulatorsAll(0, ModulatorControllerSources.polyPressure);
        this.synthCore.callEvent("polyPressure", {
            channel: this.channel,
            midiNote: midiNote,
            pressure: pressure
        });
    }

    /**
     * @internal
     */
    public updateInternalParams() {
        const globalSystem = this.synthCore.systemParameters;
        const channelSystem = this._systemParameters;
        const globalMIDI = this.synthCore.midiParameters;
        const channelMIDI = this._midiParameters;
        // Note:
        // - System -> System Parameter
        // - MIDI -> MIDI Parameter

        // Global MIDI + Channel MIDI
        const midiKeyShift = globalMIDI.keyShift + channelMIDI.keyShift;
        const pitchBased = globalSystem.pitchBasedKeyShift;

        // Drum key shift in XG is treated as semitone shift
        const drumFineTune =
            this._drumChannel && this.channelSystem === "xg"
                ? channelMIDI.keyShift * 100
                : 0;

        // Only Channel System is processed for drum channels.
        // Drum channels ignore key shift
        // Testcase: th07_19_user_gm.mid
        const currentKeyShift = this._drumChannel
            ? channelSystem.keyShift
            : // Global System
              globalSystem.keyShift +
              // Global MIDI + Channel MIDI (unless pitch based)
              (pitchBased ? 0 : midiKeyShift) +
              // Channel System
              channelSystem.keyShift;
        // Ensure integer
        this.currentKeyShift = Math.trunc(currentKeyShift);

        // Only Channel System is processed for drum channels
        this.currentTuning = this._drumChannel
            ? channelSystem.fineTune + drumFineTune
            : // Global System
              globalSystem.fineTune +
              // Global MIDI
              globalMIDI.fineTune +
              // Channel System
              channelSystem.fineTune +
              // Channel MIDI
              channelMIDI.fineTune +
              // MIDI key shift as semitone pitch change
              (pitchBased ? midiKeyShift * 100 : 0);

        // [-1;1] normalized
        const currentPanNormalized =
            // Global System
            globalSystem.pan +
            // Global MIDI
            globalMIDI.pan +
            // Channel System
            channelSystem.pan;
        // Channel MIDI is the pan controller

        // For faster renderVoice calculation
        this.currentPan = currentPanNormalized * 500;

        this.currentGain =
            // Global forced
            SPESSASYNTH_GAIN_FACTOR *
            // Global System
            globalSystem.gain *
            // Global MIDI
            // It corresponds to CC volume, so volume is squared.
            Math.pow(globalMIDI.volume, 2) *
            // Channel System
            channelSystem.gain;
        // Channel MIDI are the volume/expression controllers
    }

    /**
     * Stops a note nearly instantly.
     * @param midiNote The note to stop.
     * @param releaseTime in timecents, defaults to -12000 (very short release).
     * @internal
     */
    public killNote(midiNote: number, releaseTime = -12_000) {
        let vc = 0;
        this.noteOffID[midiNote] = 0;
        this.noteOnID[midiNote] = 0;
        if (this._voiceCount > 0)
            for (const v of this.synthCore.voices) {
                if (
                    v.channel === this.channel &&
                    v.isActive &&
                    v.midiNote === midiNote
                ) {
                    v.overrideReleaseVolEnv = releaseTime; // Set release to be very short
                    v.isInRelease = false; // Force release again
                    v.releaseVoice(this.synthCore.currentTime);
                    if (++vc >= this._voiceCount) break; // We already checked all the voices
                }
            }
    }

    /**
     * Applies the `ChannelSnapshot` to this `MIDIChannel` instance.
     * @param snapshot The snapshot to apply.
     * @internal
     */
    public applySnapshot(snapshot: ChannelSnapshot) {
        applySnapshot.call(this, snapshot);
    }

    /**
     * @internal
     */
    public getSnapshot() {
        return getChannelSnapshot.call(this);
    }

    /**
     * Strictly internal, used by the sequencer for
     * very accurate portamento recreation.
     * @internal
     * @param midiNote
     */
    public setLastNote(midiNote: number) {
        this.lastPortamentoNote = midiNote;
    }

    /**
     * @internal
     */
    public destroy() {
        this.preset = undefined;
        // @ts-expect-error destruction
        this.lockedControllers = undefined;
        // @ts-expect-error destruction
        this._systemParameters = undefined;
        // @ts-expect-error destruction
        this._midiControllers = undefined;
        // @ts-expect-error destruction
        this._midiParameters = undefined;
    }

    /**
     * Resets the given Channel MIDI Parameter to the default value, taking special actions depending on the parameter.
     * @internal
     */
    protected resetMIDIParameter(param: keyof ChannelMIDIParameter) {
        switch (param) {
            default: {
                this.setMIDIParameter(
                    param,
                    DEFAULT_CHANNEL_MIDI_PARAMETERS[param]
                );
                break;
            }

            case "rxChannel": {
                this.setMIDIParameter("rxChannel", this.channel);
                break;
            }

            case "drumMap": {
                // Set the correct default map
                const defaultMap =
                    this.channelSystem === "xg"
                        ? DEFAULT_XG_DRUM_MAP
                        : DEFAULT_GS_DRUM_MAP;
                this.setMIDIParameter(
                    "drumMap",
                    this.channel % 16 === MIDI_DRUM_CHANNEL
                        ? defaultMap
                        : MELODIC_MAP
                );
                break;
            }

            case "pitchWheel": {
                // This one has a wrapper, for per-note pitch wheel
                this.pitchWheel(8192);
                break;
            }
        }
    }

    /** @internal */
    protected setBankMSB(bankMSB: number) {
        if (this._systemParameters.presetLock) return;
        this.patch.bankMSB = bankMSB;
    }

    /** @internal */
    protected setBankLSB(bankLSB: number) {
        if (this._systemParameters.presetLock) return;
        this.patch.bankLSB = bankLSB;
    }

    /** @internal */
    protected setIsGMGSDrum(isGMGSDrum: boolean) {
        if (this._systemParameters.presetLock) return;
        this.patch.isGMGSDrum = isGMGSDrum;
    }

    /** @internal */
    protected resetGeneratorOverrides() {
        this.generators.overrides.fill(GENERATOR_OVERRIDE_NO_CHANGE_VALUE);
        this.generators.overridesEnabled = false;
    }

    /** @internal */
    protected setGeneratorOverride(
        gen: GeneratorType,
        value: number,
        realtime = false
    ) {
        this.generators.overrides[gen] = value;
        this.generators.overridesEnabled = true;
        if (realtime) {
            let vc = 0;
            if (this._voiceCount > 0)
                for (const v of this.synthCore.voices) {
                    if (v.channel === this.channel && v.isActive) {
                        v.generators[gen] = value;
                        this.computeModulators(v);
                        if (++vc >= this._voiceCount) break; // We already checked all the voices
                    }
                }
        }
    }

    /** @internal */
    protected resetGeneratorOffsets() {
        this.generators.offsets.fill(0);
        this.generators.offsetsEnabled = false;
    }

    /** @internal */
    protected setGeneratorOffset(gen: GeneratorType, value: number) {
        this.generators.offsets[gen] = value * GeneratorLimits[gen].nrpn;
        this.generators.offsetsEnabled = true;
        let vc = 0;
        if (this._voiceCount > 0)
            for (const v of this.synthCore.voices) {
                if (v.channel === this.channel && v.isActive) {
                    this.computeModulators(v);
                    if (++vc >= this._voiceCount) break; // We already checked all the voices
                }
            }
    }

    /** @internal */
    protected resetDrumParams() {
        if (this.synthCore.systemParameters.drumLock || !this._drumChannel)
            return;
        for (let index = 0; index < 128; index++) {
            const p = this.drumParams[index];
            DrumParameterUtilities.copyInto(
                DrumParameterUtilities.DEFAULT_DATA[index],
                p
            );
            p.chorusSend =
                this.channelSystem === "xg" ? DEFAULT_DRUM_REVERB[index] : 0; // Mirror reverb on XG only, GS has no chorus by default
            p.variationSend =
                this.channelSystem === "xg" ? DEFAULT_DRUM_REVERB[index] : 0;
        }
    }

    /** @internal */
    protected resetVibratoParams() {
        if (!this.synthCore.systemParameters.customVibrato) return;
        this.customVibrato.rate = 0;
        this.customVibrato.depth = 0;
        this.customVibrato.delay = 0;
    }

    /** @internal */
    protected addDefaultVibrato() {
        if (
            this.customVibrato.delay === 0 &&
            this.customVibrato.rate === 0 &&
            this.customVibrato.depth === 0
        ) {
            this.customVibrato.depth = 50;
            this.customVibrato.rate = 8;
            this.customVibrato.delay = 0.6;
        }
    }

    /**
     *
     * @param sourceUsesCC what modulators should be computed, -1 means all, 0 means modulator source enum 1 means midi controller.
     * @param sourceIndex
     * @internal
     */
    protected computeModulatorsAll(
        sourceUsesCC: -1 | 0 | 1,
        sourceIndex: number
    ) {
        let vc = 0;
        if (this._voiceCount > 0)
            for (const v of this.synthCore.voices) {
                if (v.channel === this.channel && v.isActive) {
                    this.computeModulators(v, sourceUsesCC, sourceIndex);
                    if (++vc >= this._voiceCount) break; // We already checked all the voices
                }
            }
    }

    /**
     * Sets drums on channel.
     * @internal
     */
    protected setDrumFlag(isDrum: boolean) {
        if (this._systemParameters.presetLock || this._drumChannel === isDrum)
            return;

        this._drumChannel = isDrum;
        this.updateInternalParams();
    }
}
