import type {
    DefaultXGEffectProcessor,
    DefaultXGEffectProcessorConstructor
} from "./dsp/effect_processor";
import { getMemorySize } from "./dsp/xg_dsp_program";
import type {
    XGEffectBlock,
    XGEffectBlockSnapshot
} from "../interface/xg_effect_block";

/**
 * The default implementation for {@link XGEffectBlock}.
 *
 * This class represents a single XG effect block.
 * Each block contains a specific processor and may be an insertion or system effect.
 * This class does the mixing and routing of the effect.
 *
 * @group Synthesizer.XG Effects
 */
export abstract class DefaultXGEffect implements XGEffectBlock {
    /**
     * The currently used processor.
     * Hidden from the docs as the processor types are internal.
     * @hidden
     */
    protected processor: DefaultXGEffectProcessor;
    protected readonly outputLeft;
    protected readonly outputRight;
    /**
     * The list of effects available in this block.
     * Effect type: processor.
     */
    private readonly effectMap = new Map<number, DefaultXGEffectProcessor>();
    private readonly fallbackProcessor: DefaultXGEffectProcessor;
    private readonly defaultType;
    private type;

    /**
     * Initializes the new XG effect block.
     * @param effectMap The map of all effect constructors to initialize.
     * @param fallbackProcessor The fallback processor in case the real processor is missing.
     * @param defaultType The default effect type.
     * @param sampleRate The sample rate, in Hertz.
     * @param maxBufferSize The maximum buffer size the synthesizer can render at once.
     * Processing more samples than this is not supported and produces undefined output.
     * @param variation True for the variation and insertion blocks.
     * @hidden
     */
    protected constructor(
        effectMap: Map<number, DefaultXGEffectProcessorConstructor>,
        fallbackProcessor: DefaultXGEffectProcessorConstructor,
        defaultType: number,
        sampleRate: number,
        maxBufferSize: number,
        variation: boolean
    ) {
        // Only one processor runs at a time,
        // So they all share one delay memory.
        let memoryLength = getMemorySize(
            sampleRate,
            fallbackProcessor.memorySize
        );
        for (const constructor of effectMap.values()) {
            memoryLength = Math.max(
                memoryLength,
                getMemorySize(sampleRate, constructor.memorySize)
            );
        }
        const memory = new Float32Array(memoryLength);
        for (const [key, value] of effectMap) {
            this.effectMap.set(
                key,
                new value(sampleRate, maxBufferSize, memory, variation)
            );
        }
        this.fallbackProcessor = new fallbackProcessor(
            sampleRate,
            maxBufferSize,
            memory,
            variation
        );
        this.processor =
            this.effectMap.get(defaultType) ?? this.fallbackProcessor;
        this.defaultType = defaultType;
        this.type = defaultType;

        this.outputLeft = new Float32Array(maxBufferSize);
        this.outputRight = new Float32Array(maxBufferSize);
    }

    public setType(type: number) {
        this.type = type;
        this.processor =
            this.effectMap.get(type) ??
            this.effectMap.get(type & 0xff_00) ??
            this.fallbackProcessor;
        this.processor.reset();
    }

    public getType() {
        return this.type;
    }

    public reset() {
        this.setType(this.defaultType);
    }
    public setParameter(param: number, value: number) {
        this.processor.setParameter(param, value);
    }

    public getSnapshot() {
        return {
            type: this.type,
            params: this.processor.getSnapshot()
        };
    }

    public applySnapshot(snapshot: XGEffectBlockSnapshot) {
        this.setType(snapshot.type);
        const params = snapshot.params;
        for (let i = 0; i < 16 && i < params.length; i++) {
            this.setParameter(i, params[i]);
        }
    }
}
