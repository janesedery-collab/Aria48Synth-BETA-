import type { DefaultXGEffectProcessorConstructor } from "./dsp/effect_processor";
import { XGThru } from "./dsp/thru";
import { XGTremolo } from "./dsp/tremolo/tremolo";
import { XGAutoPan } from "./dsp/tremolo/auto_pan";
import { XGPhaser1 } from "./dsp/phaser/phaser1";
import { XGTwoBandEQ } from "./dsp/equalizer/two_band_eq";
import { XGAutoWah } from "./dsp/auto_wah/auto_wah";
import { XGThreeBandEQ } from "./dsp/equalizer/three_band_eq";
import { XGDistortion } from "./dsp/distortion/distortion";
import { XGOverdrive } from "./dsp/distortion/overdrive";
import { XGAmpSimulator } from "./dsp/distortion/amp_simulator";
import { XGSymphonic } from "./dsp/symphonic/symphonic";
import { XGRotarySpeaker } from "./dsp/rotary/rotary_speaker";
import { XGDelayLCR } from "./dsp/delay/delay_lcr";
import { XGDelayLR } from "./dsp/delay/delay_lr";
import { XGEcho } from "./dsp/delay/echo";
import { XGCrossDelay } from "./dsp/delay/cross_delay";
import { XGKaraoke1 } from "./dsp/karaoke/karaoke1";
import { XGKaraoke2 } from "./dsp/karaoke/karaoke2";
import { XGKaraoke3 } from "./dsp/karaoke/karaoke3";
import { XGHall1 } from "./dsp/reverb/hall1";
import { XGHall2 } from "./dsp/reverb/hall2";
import { XGPlate } from "./dsp/reverb/plate";
import { XGRoom1 } from "./dsp/reverb/room1";
import { XGRoom2 } from "./dsp/reverb/room2";
import { XGRoom3 } from "./dsp/reverb/room3";
import { XGStage1 } from "./dsp/reverb/stage1";
import { XGStage2 } from "./dsp/reverb/stage2";
import { XGCeleste1 } from "./dsp/chorus/celeste1";
import { XGCeleste2 } from "./dsp/chorus/celeste2";
import { XGCeleste3 } from "./dsp/chorus/celeste3";
import { XGCeleste4 } from "./dsp/chorus/celeste4";
import { XGChorus1 } from "./dsp/chorus/chorus1";
import { XGChorus2 } from "./dsp/chorus/chorus2";
import { XGChorus3 } from "./dsp/chorus/chorus3";
import { XGChorus4 } from "./dsp/chorus/chorus4";
import { XGFlanger1 } from "./dsp/chorus/flanger1";
import { XGFlanger2 } from "./dsp/chorus/flanger2";
import { XGFlanger3 } from "./dsp/chorus/flanger3";
import { DefaultXGEffect } from "./effect";
import type {
    XGInsertionBlock,
    XGInsertionBlockSnapshot
} from "../interface/xg_insertion_block";

const INSERTION_MAP = new Map<number, DefaultXGEffectProcessorConstructor>([
    [0x00_00, XGThru],
    [0x01_00, XGHall1],
    [0x01_01, XGHall2],
    [0x02_00, XGRoom1],
    [0x02_01, XGRoom2],
    [0x02_02, XGRoom3],
    [0x03_00, XGStage1],
    [0x03_01, XGStage2],
    [0x04_00, XGPlate],
    [0x05_00, XGDelayLCR],
    [0x06_00, XGDelayLR],
    [0x07_00, XGEcho],
    [0x08_00, XGCrossDelay],
    [0x14_00, XGKaraoke1],
    [0x14_01, XGKaraoke2],
    [0x14_02, XGKaraoke3],
    [0x41_00, XGChorus1],
    [0x41_01, XGChorus2],
    [0x41_02, XGChorus3],
    [0x41_08, XGChorus4],
    [0x42_00, XGCeleste1],
    [0x42_01, XGCeleste2],
    [0x42_02, XGCeleste3],
    [0x42_08, XGCeleste4],
    [0x43_00, XGFlanger1],
    [0x43_01, XGFlanger2],
    [0x43_08, XGFlanger3],
    [0x44_00, XGSymphonic],
    [0x45_00, XGRotarySpeaker],
    [0x46_00, XGTremolo],
    [0x47_00, XGAutoPan],
    // The XG spec's EFFECT 2 list only has PHASER 1.
    // PHASER 2 (48 08) is variation only and falls back to PHASER 1 here.
    [0x48_00, XGPhaser1],
    [0x49_00, XGDistortion],
    [0x4a_00, XGOverdrive],
    [0x4b_00, XGAmpSimulator],
    [0x4c_00, XGThreeBandEQ],
    [0x4d_00, XGTwoBandEQ],
    [0x4e_00, XGAutoWah]
]);

/**
 * The default implementation for {@link XGInsertionBlock}.
 *
 * The default type is DISTORTION. The EFFECT 2 types run on the same processors as the variation block types.
 * The early reflection types and PHASER 2 are variation only, so PHASER 2 falls back to PHASER 1 here.
 * Unknown types use the type with LSB 0, or THRU if that is missing too.
 *
 * @group Synthesizer.XG Effects
 * @sealed
 */
export class DefaultXGInsertion
    extends DefaultXGEffect
    implements XGInsertionBlock
{
    public partNumber = 127;
    /**
     * Constructs a new default XG insertion processor.
     * @param sampleRate The sample rate, in Hertz.
     * @param maxBufferSize The maximum buffer size the synthesizer can render at once.
     * Processing more samples than this is not supported and produces undefined output.
     */
    public constructor(sampleRate: number, maxBufferSize: number) {
        super(INSERTION_MAP, XGThru, 0x49_00, sampleRate, maxBufferSize, true);
    }

    /**
     * Resets this block to default values, including the processor type.
     */
    public reset() {
        super.reset();
        this.partNumber = 127;
    }

    public processInsertion(
        inputLeft: Float32Array,
        inputRight: Float32Array,
        sampleCount: number
    ) {
        this.processor.process(
            inputLeft,
            inputRight,
            this.outputLeft,
            this.outputRight,
            sampleCount,
            true
        );
        // Copy without creating subarray views on the audio thread
        const { outputLeft, outputRight } = this;
        for (let i = 0; i < sampleCount; i++) {
            inputLeft[i] = outputLeft[i];
            inputRight[i] = outputRight[i];
        }
    }

    /**
     * Gets a snapshot of this XG effect block.
     */
    public getSnapshot() {
        return {
            ...super.getSnapshot(),
            partNumber: this.partNumber
        };
    }

    /**
     * Restores this XG effect block from a snapshot.
     * @param snapshot The snapshot to restore.
     */
    public applySnapshot(snapshot: XGInsertionBlockSnapshot) {
        super.applySnapshot(snapshot);
        this.partNumber = snapshot.partNumber;
    }
}
