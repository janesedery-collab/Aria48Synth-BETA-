/**
 * The GS conversion table of the SC-88Pro manual ("conversion data"): what the EFX parameters mean in physical
 * units. One row per value (0-127), the columns are below. The programs follow most columns exactly (phase 2 of the
 * rewrite checked each one against the hardware's tables).
 */
/* eslint-disable unicorn/numeric-separators-style, unicorn/no-zero-fractions */
// prettier-ignore
const CONVERSION_TABLE: readonly (readonly number[])[] = [
    // PreDly,Dly1, Dly2, Dly3, Dly4,Rate1, Rate2, HF,   Cut,  EQ,   LPF,  Man,  Azim, Accl
    [0.0, 200, 200, 0.0, 0, 0.05, 0.05, 315, 250, 200, 250, 100, -180, 0], // 00
    [0.1, 205, 205, 0.1, 5, 0.1, 0.1, 315, 250, 200, 250, 110, -180, 1], // 01
    [0.2, 210, 210, 0.2, 10, 0.15, 0.15, 315, 250, 200, 250, 120, -180, 2], // 02
    [0.3, 215, 215, 0.3, 15, 0.2, 0.2, 315, 250, 200, 250, 130, -180, 3], // 03
    [0.4, 220, 220, 0.4, 20, 0.25, 0.25, 315, 250, 200, 250, 140, -180, 4], // 04
    [0.5, 225, 225, 0.5, 25, 0.3, 0.3, 315, 250, 200, 250, 150, -180, 5], // 05
    [0.6, 230, 230, 0.6, 30, 0.35, 0.35, 315, 250, 200, 250, 160, -168, 5], // 06
    [0.7, 235, 235, 0.7, 35, 0.4, 0.4, 315, 250, 200, 250, 170, -168, 5], // 07
    [0.8, 240, 240, 0.8, 40, 0.45, 0.45, 400, 315, 250, 315, 180, -168, 5], // 08
    [0.9, 245, 245, 0.9, 45, 0.5, 0.5, 400, 315, 250, 315, 190, -168, 5], // 09
    [1.0, 250, 250, 1.0, 50, 0.55, 0.55, 400, 315, 250, 315, 200, -156, 5], // 10
    [1.1, 255, 255, 1.1, 55, 0.6, 0.6, 400, 315, 250, 315, 210, -156, 5], // 11
    [1.2, 260, 260, 1.2, 60, 0.65, 0.65, 400, 315, 250, 315, 220, -156, 5], // 12
    [1.3, 265, 265, 1.3, 65, 0.7, 0.7, 400, 315, 250, 315, 230, -156, 5], // 13
    [1.4, 270, 270, 1.4, 70, 0.75, 0.75, 400, 315, 250, 315, 240, -144, 5], // 14
    [1.5, 275, 275, 1.5, 75, 0.8, 0.8, 400, 315, 250, 315, 250, -144, 5], // 15
    [1.6, 280, 280, 1.6, 80, 0.85, 0.85, 500, 400, 315, 400, 260, -144, 5], // 16
    [1.7, 285, 285, 1.7, 85, 0.9, 0.9, 500, 400, 315, 400, 270, -144, 5], // 17
    [1.8, 290, 290, 1.8, 90, 0.95, 0.95, 500, 400, 315, 400, 280, -132, 5], // 18
    [1.9, 295, 295, 1.9, 95, 1.0, 1.0, 500, 400, 315, 400, 290, -132, 5], // 19
    [2.0, 300, 300, 2.0, 100, 1.05, 1.05, 500, 400, 315, 400, 300, -132, 5], // 20
    [2.1, 305, 305, 2.1, 105, 1.1, 1.1, 500, 400, 315, 400, 320, -132, 5], // 21
    [2.2, 310, 310, 2.2, 110, 1.15, 1.15, 500, 400, 315, 400, 340, -120, 5], // 22
    [2.3, 315, 315, 2.3, 115, 1.2, 1.2, 500, 400, 315, 400, 360, -120, 5], // 23
    [2.4, 320, 320, 2.4, 120, 1.25, 1.25, 630, 500, 400, 500, 380, -120, 5], // 24
    [2.5, 325, 325, 2.5, 125, 1.3, 1.3, 630, 500, 400, 500, 400, -120, 5], // 25
    [2.6, 330, 330, 2.6, 130, 1.35, 1.35, 630, 500, 400, 500, 420, -108, 5], // 26
    [2.7, 335, 335, 2.7, 135, 1.4, 1.4, 630, 500, 400, 500, 440, -108, 5], // 27
    [2.8, 340, 340, 2.8, 140, 1.45, 1.45, 630, 500, 400, 500, 460, -108, 5], // 28
    [2.9, 345, 345, 2.9, 145, 1.5, 1.5, 630, 500, 400, 500, 480, -108, 5], // 29
    [3.0, 350, 350, 3.0, 150, 1.55, 1.55, 630, 500, 400, 500, 500, -96, 6], // 30
    [3.1, 355, 355, 3.1, 155, 1.6, 1.6, 630, 500, 400, 500, 520, -96, 6], // 31
    [3.2, 360, 360, 3.2, 160, 1.65, 1.65, 800, 630, 500, 630, 540, -96, 6], // 32
    [3.3, 365, 365, 3.3, 165, 1.7, 1.7, 800, 630, 500, 630, 560, -96, 6], // 33
    [3.4, 370, 370, 3.4, 170, 1.75, 1.75, 800, 630, 500, 630, 580, -84, 6], // 34
    [3.5, 375, 375, 3.5, 175, 1.8, 1.8, 800, 630, 500, 630, 600, -84, 6], // 35
    [3.6, 380, 380, 3.6, 180, 1.85, 1.85, 800, 630, 500, 630, 620, -84, 6], // 36
    [3.7, 385, 385, 3.7, 185, 1.9, 1.9, 800, 630, 500, 630, 640, -84, 6], // 37
    [3.8, 390, 390, 3.8, 190, 1.95, 1.95, 800, 630, 500, 630, 660, -72, 6], // 38
    [3.9, 395, 395, 3.9, 195, 2.0, 2.0, 800, 630, 500, 630, 680, -72, 6], // 39
    [4.0, 400, 400, 4.0, 200, 2.05, 2.05, 1000, 800, 630, 800, 700, -72, 6], // 40
    [4.1, 405, 405, 4.1, 205, 2.1, 2.1, 1000, 800, 630, 800, 720, -72, 6], // 41
    [4.2, 410, 410, 4.2, 210, 2.15, 2.15, 1000, 800, 630, 800, 740, -60, 6], // 42
    [4.3, 415, 415, 4.3, 215, 2.2, 2.2, 1000, 800, 630, 800, 760, -60, 6], // 43
    [4.4, 420, 420, 4.4, 220, 2.25, 2.25, 1000, 800, 630, 800, 780, -60, 6], // 44
    [4.5, 425, 425, 4.5, 225, 2.3, 2.3, 1000, 800, 630, 800, 800, -60, 6], // 45
    [4.6, 430, 430, 4.6, 230, 2.35, 2.35, 1000, 800, 630, 800, 820, -48, 6], // 46
    [4.7, 435, 435, 4.7, 235, 2.4, 2.4, 1000, 800, 630, 800, 840, -48, 6], // 47
    [4.8, 440, 440, 4.8, 240, 2.45, 2.45, 1250, 1000, 800, 1000, 860, -48, 9], // 48
    [4.9, 445, 445, 4.9, 245, 2.5, 2.5, 1250, 1000, 800, 1000, 880, -48, 9], // 49
    [5.0, 450, 450, 5.0, 250, 2.55, 2.55, 1250, 1000, 800, 1000, 900, -36, 9], // 50
    [5.5, 455, 455, 5.5, 255, 2.6, 2.6, 1250, 1000, 800, 1000, 920, -36, 9], // 51
    [6.0, 460, 460, 6.0, 260, 2.65, 2.65, 1250, 1000, 800, 1000, 940, -36, 9], // 52
    [6.5, 465, 465, 6.5, 265, 2.7, 2.7, 1250, 1000, 800, 1000, 960, -36, 9], // 53
    [7.0, 470, 470, 7.0, 270, 2.75, 2.75, 1250, 1000, 800, 1000, 980, -24, 9], // 54
    [7.5, 475, 475, 7.5, 275, 2.8, 2.8, 1250, 1000, 800, 1000, 1000, -24, 9], // 55
    [8.0, 480, 480, 8.0, 280, 2.85, 2.85, 1600, 1250, 1000, 1250, 1100, -24, 9], // 56
    [8.5, 485, 485, 8.5, 285, 2.9, 2.9, 1600, 1250, 1000, 1250, 1200, -24, 9], // 57
    [9.0, 490, 490, 9.0, 290, 2.95, 2.95, 1600, 1250, 1000, 1250, 1300, -12, 9], // 58
    [9.5, 495, 495, 9.5, 295, 3.0, 3.0, 1600, 1250, 1000, 1250, 1400, -12, 9], // 59
    [10, 500, 500, 10, 300, 3.05, 3.05, 1600, 1250, 1000, 1250, 1500, -12, 9], // 60
    [11, 505, 505, 11, 305, 3.1, 3.1, 1600, 1250, 1000, 1250, 1600, -12, 9], // 61
    [12, 510, 510, 12, 310, 3.15, 3.15, 1600, 1250, 1000, 1250, 1700, 0, 9], // 62
    [13, 515, 515, 13, 315, 3.2, 3.2, 1600, 1250, 1000, 1250, 1800, 0, 9], // 63
    [14, 520, 520, 14, 320, 3.25, 3.25, 2000, 1600, 1250, 1600, 1900, 0, 12], // 64
    [15, 525, 525, 15, 325, 3.3, 3.3, 2000, 1600, 1250, 1600, 2000, 0, 12], // 65
    [16, 530, 530, 16, 330, 3.35, 3.35, 2000, 1600, 1250, 1600, 2100, 12, 12], // 66
    [17, 535, 535, 17, 335, 3.4, 3.4, 2000, 1600, 1250, 1600, 2200, 12, 12], // 67
    [18, 540, 540, 18, 340, 3.45, 3.45, 2000, 1600, 1250, 1600, 2300, 12, 12], // 68
    [19, 545, 545, 19, 345, 3.5, 3.5, 2000, 1600, 1250, 1600, 2400, 12, 12], // 69
    [20, 550, 550, 20, 350, 3.55, 3.55, 2000, 1600, 1250, 1600, 2500, 24, 12], // 70
    [21, 560, 555, 21, 355, 3.6, 3.6, 2000, 1600, 1250, 1600, 2600, 24, 12], // 71
    [22, 570, 560, 22, 360, 3.65, 3.65, 2500, 2000, 1600, 2000, 2700, 24, 12], // 72
    [23, 580, 565, 23, 365, 3.7, 3.7, 2500, 2000, 1600, 2000, 2800, 24, 12], // 73
    [24, 590, 570, 24, 370, 3.75, 3.75, 2500, 2000, 1600, 2000, 2900, 36, 12], // 74
    [25, 600, 575, 25, 375, 3.8, 3.8, 2500, 2000, 1600, 2000, 3000, 36, 12], // 75
    [26, 610, 580, 26, 380, 3.85, 3.85, 2500, 2000, 1600, 2000, 3100, 36, 12], // 76
    [27, 620, 585, 27, 385, 3.9, 3.9, 2500, 2000, 1600, 2000, 3200, 36, 12], // 77
    [28, 630, 590, 28, 390, 3.95, 3.95, 2500, 2000, 1600, 2000, 3300, 48, 12], // 78
    [29, 640, 595, 29, 395, 4.0, 4.0, 2500, 2000, 1600, 2000, 3400, 48, 12], // 79
    [30, 650, 600, 30, 400, 4.05, 4.05, 3150, 2500, 2000, 2500, 3500, 48, 10], // 80
    [31, 660, 610, 31, 405, 4.1, 4.1, 3150, 2500, 2000, 2500, 3600, 48, 10], // 81
    [32, 670, 620, 32, 410, 4.15, 4.15, 3150, 2500, 2000, 2500, 3700, 60, 10], // 82
    [33, 680, 630, 33, 415, 4.2, 4.2, 3150, 2500, 2000, 2500, 3800, 60, 10], // 83
    [34, 690, 640, 34, 420, 4.25, 4.25, 3150, 2500, 2000, 2500, 3900, 60, 10], // 84
    [35, 700, 650, 35, 425, 4.3, 4.3, 3150, 2500, 2000, 2500, 4000, 60, 10], // 85
    [36, 710, 660, 36, 430, 4.35, 4.35, 3150, 2500, 2000, 2500, 4100, 72, 10], // 86
    [37, 720, 670, 37, 435, 4.4, 4.4, 3150, 2500, 2000, 2500, 4200, 72, 10], // 87
    [38, 730, 680, 38, 440, 4.45, 4.45, 4000, 3150, 2500, 3150, 4300, 72, 11], // 88
    [39, 740, 690, 39, 445, 4.5, 4.5, 4000, 3150, 2500, 3150, 4400, 72, 11], // 89
    [40, 750, 700, 40, 450, 4.55, 4.55, 4000, 3150, 2500, 3150, 4500, 84, 11], // 90
    [41, 760, 710, 50, 455, 4.6, 4.6, 4000, 3150, 2500, 3150, 4600, 84, 11], // 91
    [42, 770, 720, 60, 460, 4.65, 4.65, 4000, 3150, 2500, 3150, 4700, 84, 11], // 92
    [43, 780, 730, 70, 465, 4.7, 4.7, 4000, 3150, 2500, 3150, 4800, 84, 11], // 93
    [44, 790, 740, 80, 470, 4.75, 4.75, 4000, 3150, 2500, 3150, 4900, 96, 11], // 94
    [45, 800, 750, 90, 475, 4.8, 4.8, 4000, 3150, 2500, 3150, 5000, 96, 11], // 95
    [46, 810, 760, 100, 480, 4.85, 4.85, 5000, 4000, 3150, 4000, 5100, 96, 12], // 96
    [47, 820, 770, 110, 485, 4.9, 4.9, 5000, 4000, 3150, 4000, 5200, 96, 12], // 97
    [48, 830, 780, 120, 490, 4.95, 4.95, 5000, 4000, 3150, 4000, 5300, 108, 12], // 98
    [49, 840, 790, 130, 495, 5.0, 5.0, 5000, 4000, 3150, 4000, 5400, 108, 12], // 99
    [50, 850, 800, 140, 500, 5.1, 5.05, 5000, 4000, 3150, 4000, 5500, 108, 12], // 100
    [52, 860, 810, 150, 505, 5.2, 5.1, 5000, 4000, 3150, 4000, 5600, 108, 12], // 101
    [54, 870, 820, 160, 510, 5.3, 5.15, 5000, 4000, 3150, 4000, 5700, 120, 12], // 102
    [56, 880, 830, 170, 515, 5.4, 5.2, 5000, 4000, 3150, 4000, 5800, 120, 12], // 103
    [58, 890, 840, 180, 520, 5.5, 5.25, 6300, 5000, 4000, 5000, 5900, 120, 13], // 104
    [60, 900, 850, 190, 525, 5.6, 5.3, 6300, 5000, 4000, 5000, 6000, 120, 13], // 105
    [62, 910, 860, 200, 530, 5.7, 5.35, 6300, 5000, 4000, 5000, 6100, 132, 13], // 106
    [64, 920, 870, 210, 535, 5.8, 5.4, 6300, 5000, 4000, 5000, 6200, 132, 13], // 107
    [66, 930, 880, 220, 540, 5.9, 5.45, 6300, 5000, 4000, 5000, 6300, 132, 13], // 108
    [68, 940, 890, 230, 545, 6.0, 5.5, 6300, 5000, 4000, 5000, 6400, 132, 13], // 109
    [70, 950, 900, 240, 550, 6.1, 5.55, 6300, 5000, 4000, 5000, 6500, 144, 13], // 110
    [72, 960, 910, 250, 555, 6.2, 5.6, 6300, 5000, 4000, 5000, 6600, 144, 13], // 111
    [74, 970, 920, 260, 560, 6.3, 5.65, 8000, 6300, 5000, 6300, 6700, 144, 14], // 112
    [76, 980, 930, 270, 565, 6.4, 5.7, 8000, 6300, 5000, 6300, 6800, 144, 14], // 113
    [78, 990, 940, 280, 570, 6.5, 5.75, 8000, 6300, 5000, 6300, 6900, 156, 14], // 114
    [80, 1000, 950, 290, 575, 6.6, 5.8, 8000, 6300, 5000, 6300, 7000, 156, 14], // 115
    [82, 1000, 960, 300, 580, 6.7, 5.85, 8000, 6300, 5000, 6300, 7100, 156, 14], // 116
    [84, 1000, 970, 320, 585, 6.8, 5.9, 8000, 6300, 5000, 6300, 7200, 156, 14], // 117
    [86, 1000, 980, 340, 590, 6.9, 5.95, 8000, 6300, 5000, 6300, 7300, 168, 14], // 118
    [88, 1000, 990, 360, 595, 7.0, 6.0, 8000, 6300, 5000, 6300, 7400, 168, 14], // 119
    [
        90, 1000, 1000, 380, 600, 7.5, 6.05, 13500, 8000, 6300, 13500, 7500,
        168, 15
    ], // 120
    [
        92, 1000, 1000, 400, 605, 8.0, 6.1, 13500, 8000, 6300, 13500, 7600, 168,
        15
    ], // 121
    [
        94, 1000, 1000, 420, 610, 8.5, 6.15, 13500, 8000, 6300, 13500, 7700,
        -180, 15
    ], // 122
    [
        96, 1000, 1000, 440, 615, 9.0, 6.2, 13500, 8000, 6300, 13500, 7800,
        -180, 15
    ], // 123
    [
        98, 1000, 1000, 460, 620, 9.5, 6.25, 13500, 8000, 6300, 13500, 7900,
        -180, 15
    ], // 124
    [
        100, 1000, 1000, 480, 625, 10.0, 6.3, 13500, 8000, 6300, 13500, 8000,
        -180, 15
    ], // 125
    [
        100, 1000, 1000, 500, 630, 10.0, 6.35, 13500, 8000, 6300, 13500, 8000,
        -180, 15
    ], // 126
    [
        100, 1000, 1000, 500, 635, 10.0, 6.4, 13500, 8000, 6300, 13500, 8000,
        -180, 15
    ] // 127
];
/* eslint-enable unicorn/numeric-separators-style, unicorn/no-zero-fractions */

const PRE_DELAY = 0;
const DLY_1 = 1;
const DLY_2 = 2;
const DLY_3 = 3;
const DLY_4 = 4;
const RATE_1 = 5;
const RATE_2 = 6;
const HF = 7;
const CUT = 8;
const AZIM = 12;

/**
 * The PreDly column: 0 to 100 ms. The programs hold it in whole 32 kHz samples, rounded down.
 * @param value The parameter (0-127).
 * @internal
 */
export function preDelay(value: number) {
    return Math.floor(CONVERSION_TABLE[value][PRE_DELAY] * 32) / 32;
}

/**
 * An LFO rate column as the hardware runs it: a phase step per 16 kHz tick, in 2^-24 of a cycle, rounded down to
 * an even word. That is up to 0.8 % slow (0.0496 Hz for 0.05). A chorus needs it, its delay swing turns the rate
 * error into a phase drift of the wet signal.
 * @param hz The column's rate.
 */
function lfoRate(hz: number) {
    return (2 * Math.floor((hz * 2 ** 24) / 16_000 / 2) * 16_000) / 2 ** 24;
}

/**
 * The Rate1 column: an LFO rate of 0.05 to 10 Hz.
 * @param value The parameter (0-127).
 * @internal
 */
export function rate1(value: number) {
    return lfoRate(CONVERSION_TABLE[value][RATE_1]);
}

/**
 * The Rate2 column (the multis): an LFO rate of 0.05 to 6.4 Hz.
 * @param value The parameter (0-127).
 * @internal
 */
export function rate2(value: number) {
    return lfoRate(CONVERSION_TABLE[value][RATE_2]);
}

/**
 * The Cut column: a tone filter corner of 250 to 8000 Hz.
 * @param value The parameter (0-127).
 * @internal
 */
export function cutoff(value: number) {
    return CONVERSION_TABLE[value][CUT];
}

/**
 * One 32 kHz sample in ms, the shared stage's step between the left and the right side.
 * @internal
 */
export const STEP_MS = 1 / 32;

/**
 * A bound on the swing of `modulationDepth` (12.4 ms at depth 127), in ms, for sizing the lines.
 * @internal
 */
export const SWING_MS = 12.5;

/**
 * The modulation depth of the choruses and flangers (no unit in the manual): the swing of the delay in ms,
 * 0 to 12.4 ms. Exponential in the value.
 * @param value The parameter (0-127).
 * @internal
 */
export function modulationDepth(value: number) {
    return (25_395 * (Math.exp(0.005_46 * value) - 1)) / 2048;
}

/**
 * The LFO phase difference of the choruses and flangers: 2 degrees per step up to 180.
 * @param value The parameter (0-127).
 * @internal
 */
export function chorusPhase(value: number) {
    return Math.min(2 * value, 180);
}

/**
 * The feedback of the flangers and delays (-98 to +98 % in 2 % steps from 15 to 113): the loop gain, the percentage
 * of 127/128 truncated to a byte (98 % is 124/128).
 * @param value The parameter (0-127, 64 is no feedback).
 * @internal
 */
export function feedbackGain(value: number) {
    const percent = Math.max(-98, Math.min(98, (value - 64) * 2));
    return Math.trunc((percent * 127) / 100) / 128;
}

/**
 * The HF column: the delays' HF damp corner, 315 to 8000 Hz, or Bypass (120-127).
 * @param value The parameter (0-127).
 * @returns The corner in Hz, infinite for Bypass.
 * @internal
 */
export function hfDamp(value: number) {
    return value >= 120 ? Infinity : CONVERSION_TABLE[value][HF];
}

/**
 * A delay column in ms as the programs hold it: whole 32 kHz samples rounded down, at least one sample.
 * @param column The column.
 * @param value The parameter (0-127).
 */
function delayTime(column: number, value: number) {
    return Math.max(1, Math.floor(CONVERSION_TABLE[value][column] * 32)) / 32;
}

/**
 * The Dly1 column: 200 to 1000 ms (Triple and Quad Tap, which stop at 115).
 * @param value The parameter (0-127).
 * @internal
 */
export function delay1(value: number) {
    return delayTime(DLY_1, value);
}

/**
 * The Dly2 column: 200 to 1000 ms (Time Ctrl Delay).
 * @param value The parameter (0-127).
 * @internal
 */
export function delay2(value: number) {
    return delayTime(DLY_2, value);
}

/**
 * The Dly3 column: 0 to 500 ms.
 * @param value The parameter (0-127).
 * @internal
 */
export function delay3(value: number) {
    return delayTime(DLY_3, value);
}

/**
 * The Dly4 column: 0 to 635 ms (the multis).
 * @param value The parameter (0-127).
 * @internal
 */
export function delay4(value: number) {
    return delayTime(DLY_4, value);
}

/**
 * The slew step of Time Ctrl Delay's acceleration, per 32 kHz sample over 2^18, in 16 groups of 8 values. The Accl
 * column only displays these (it is not even monotonic in them).
 */
const ACCELERATION_WORDS = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 16, 32, 64, 128, 255
];

/**
 * Time Ctrl Delay's acceleration: the time constant of the delay's slew toward its target, 8.2 s (0) to 32 ms (127).
 * @param value The parameter (0-127).
 * @returns The time constant in seconds.
 * @internal
 */
export function slewTime(value: number) {
    return 8.192 / ACCELERATION_WORDS[value >> 3];
}

/**
 * The pitch shifters' pitch: coarse -24 to +12 semitones (40-76), fine -100 to +100 cents in 2 cent steps (14-114).
 * @param coarse The coarse parameter, EFX control included.
 * @param fine The fine parameter.
 * @returns The ratio.
 * @internal
 */
export function pitchRatio(coarse: number, fine: number) {
    const cents = Math.max(
        -2400,
        Math.min(
            1200,
            (coarse - 64) * 100 + (Math.max(14, Math.min(114, fine)) - 64) * 2
        )
    );
    return 2 ** (cents / 1200);
}

/**
 * The pitch shifters' read speeds by mode.
 */
const PITCH_SPEEDS = [8, 6, 4, 3, 2];

/**
 * The pitch shifters' window by mode (0-4): 64 x 8 / speed ms, the speeds 8, 6, 4, 3, 2.
 * @param mode The mode parameter.
 * @returns The window in ms.
 * @internal
 */
export function pitchWindow(mode: number) {
    return (64 * 8) / PITCH_SPEEDS[mode];
}

/**
 * The Reverb's time: the gain of each pass through a tank, linear from 0 to 0.742 (no conversion table column).
 * Room 1 lasts 0.47 s at 32, 2.5 s at 127, Hall 1 1.17 and 6.2 s (RT60 at mid frequencies).
 * @param value The parameter (0-127).
 * @internal
 */
export function reverbTime(value: number) {
    return Math.floor((0x5f_00 * value) / 127) / 32_768;
}

/**
 * The Azim column: the 3D azimuth, L180 (-180) to R168 in 12 degree steps (four values each, 122-127 are 180 again).
 * @param value The parameter (0-127).
 * @returns The azimuth in degrees, negative on the left.
 * @internal
 */
export function azimuth(value: number) {
    return CONVERSION_TABLE[value][AZIM];
}

/**
 * Keyboard Multi's ring modulator frequency (no conversion table column): one semitone per step as a MIDI note
 * number, 8.18 Hz at 0, held at 8 kHz from 120. The hardware holds it as a phase step per 16 kHz tick, in 2^-16 of
 * a cycle rounded down (the word saturates at 120). That is a few cents flat at the bottom, but the gates see the
 * carrier's phase drift over seconds, as with the LFO rates.
 * @param value The parameter (0-127).
 * @returns The carrier frequency in Hz.
 * @internal
 */
export function ringFrequency(value: number) {
    const hz = 440 * 2 ** ((value - 69) / 12);
    return (
        (Math.min(0x7f_ff, Math.floor((hz * 65_536) / 16_000)) * 16_000) /
        65_536
    );
}

/**
 * The resonance (0-127) as the feedback byte over 128, up to 0.89.
 */
// prettier-ignore
const RESONANCES = new Uint8Array([
    0, 1, 1, 2, 3, 3, 4, 4, 5, 6, 6, 7, 8, 8, 9, 10, 10, 11, 12, 12, 13, 14, 15, 15, 16, 17, 17, 18, 19, 20, 20, 21,
    22, 22, 23, 24, 25, 26, 26, 27, 28, 29, 29, 30, 31, 32, 33, 33, 34, 35, 36, 37, 37, 38, 39, 40, 41, 42, 42, 43,
    44, 45, 46, 47, 48, 49, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
    70, 71, 72, 73, 74, 75, 76, 77, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 92, 93, 94, 95, 96, 97, 98, 100,
    101, 102, 103, 104, 105, 107, 108, 109, 110, 112, 113, 114
]);

/**
 * A resonance value as its gain (0 to 0.89). The multis' delays use the same table for their feedback.
 * @param value The parameter (0-127).
 * @internal
 */
export function resonanceGain(value: number) {
    return RESONANCES[value] / 128;
}
