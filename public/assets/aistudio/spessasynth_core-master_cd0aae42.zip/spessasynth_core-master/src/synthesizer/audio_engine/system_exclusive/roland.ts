import { SpessaLog } from "../../../utils/loggin";
import { type MIDIController, MIDIControllers } from "../../../midi/enums";
import { ModulatorControllerSources } from "../../../soundbank/enums";
import { readBinaryString } from "../../../utils/byte_functions/string";
import type { SpessaSynthProcessor } from "../../processor";
import { MIDIUtils } from "../../../midi/midi_tools/midi_utils";
import type { SysExAcceptedArray } from "../../../midi/types";
import { ConsoleColors } from "../../../utils/other";
import {
    DEFAULT_GS_DRUM_MAP,
    MELODIC_MAP
} from "../../../midi/midi_tools/sysex_data";

function handleUserDrum(
    this: SpessaSynthProcessor,
    a2: number,
    a3: number,
    data: number,
    syx: SysExAcceptedArray
) {
    if (this.systemParameters.userDrumLock) return;
    const drumSet = a2 >> 4;
    const midiNote = a3;
    const command = a2 & 0xf;
    switch (command) {
        default: {
            SpessaLog.gsFail("User Drum set", syx);
            return;
        }

        // User drum set name
        case 0: {
            const newName = readBinaryString(syx, 12, 7).trim();
            SpessaLog.gsInfo(`User Drum Set ${drumSet} Name`, newName);
            this.callEvent("displayMessage", [...syx]);
            return;
        }

        case 0x1: {
            // Here it's relative to 60, not 64 like NRPN. For some reason...
            const pitch = data - 60;

            // Use the full 100 cents here as we choose the correct pitch (50 or 100 cents) when committing changes
            this.setUserDrumSetParam(drumSet, midiNote, "pitchCoarse", pitch);
            return;
        }

        case 0x2: {
            // Drum Level
            this.setUserDrumSetParam(drumSet, midiNote, "level", data);
            return;
        }

        case 0x3: {
            // Drum Assign Group (exclusive class)
            this.setUserDrumSetParam(drumSet, midiNote, "assignGroup", data);
            return;
        }

        case 0x4: {
            // Pan
            this.setUserDrumSetParam(drumSet, midiNote, "pan", data);
            return;
        }

        case 0x5: {
            // Reverb
            this.setUserDrumSetParam(drumSet, midiNote, "reverbSend", data);
            return;
        }

        case 0x6: {
            // Chorus
            this.setUserDrumSetParam(drumSet, midiNote, "chorusSend", data);
            return;
        }

        case 0x7: {
            // Receive Note Off
            this.setUserDrumSetParam(
                drumSet,
                midiNote,
                "rxNoteOff",
                data === 1
            );
            return;
        }

        case 0x8: {
            // Receive Note On
            this.setUserDrumSetParam(drumSet, midiNote, "rxNoteOn", data === 1);
            return;
        }

        case 0x9: {
            // Delay
            this.setUserDrumSetParam(drumSet, midiNote, "variationSend", data);
            return;
        }

        // Source drum set
        case 0xa: {
            this.setUserDrumSetParam(drumSet, midiNote, "sourceDrumSet", data);
            return;
        }

        // Program number
        case 0xb: {
            this.setUserDrumSetParam(drumSet, midiNote, "program", data);
            return;
        }

        // Source note number
        case 0xc: {
            this.setUserDrumSetParam(
                drumSet,
                midiNote,
                "sourceNoteNumber",
                data
            );
            return;
        }
    }
}

/**
 * Handles a Roland GS system exclusive
 * http://www.bandtrax.com.au/sysex.htm
 * https://cdn.roland.com/assets/media/pdf/SC-8850_OM.pdf
 * @param syx
 * @param channelOffset
 */
export function rolandSystemExclusive(
    this: SpessaSynthProcessor,
    syx: SysExAcceptedArray,
    channelOffset = 0
) {
    // 0x12: DT1 (Device Transmit)
    if (syx[3] === 0x12) {
        // Model ID
        switch (syx[2]) {
            // GS
            case 0x42: {
                // This is a GS sysex
                const a1 = syx[4];
                const a2 = syx[5];
                const a3 = syx[6];

                // Sanity check
                const data = Math.min(syx[7], 127);
                // SYSTEM MODE SET
                if (
                    a1 === 0 &&
                    a2 === 0 &&
                    a3 === 0x7f &&
                    (data === 0x00 || data === 0x01)
                ) {
                    if (data === 0x01) {
                        // Double module mode, ensure at least 32 channels
                        SpessaLog.gsInfo("Mode", "Double Module");
                        while (this.midiChannels.length < 32) {
                            this.createMIDIChannel();
                        }
                    }
                    // This is a GS reset
                    SpessaLog.coolInfo("MIDI System", "Roland GS");
                    this.reset("gs");
                    return;
                }

                // Patch Parameter
                if (a1 === 0x40 || a1 === 0x50) {
                    // 50 means BLOCK B (+16 channels)
                    // Testcase: 95043-2.KYC.mid
                    if (a1 === 0x50) {
                        channelOffset += 16;
                    }
                    // System Parameter
                    if (a2 === 0x00) {
                        switch (a3) {
                            case 0x00: {
                                // Roland GS master tune
                                const tune =
                                    (data << 12) |
                                    (syx[8] << 8) |
                                    (syx[9] << 4) |
                                    syx[10];
                                const cents = (tune - 1024) / 10;
                                this.setMIDIParameter("fineTune", cents);
                                SpessaLog.gsInfo("Master Tune", cents, "cents");
                                break;
                            }

                            case 0x04: {
                                // Roland GS master volume
                                SpessaLog.gsInfo("Master Volume", data);
                                this.setMIDIParameter("volume", data / 127);
                                break;
                            }

                            case 0x05: {
                                // Roland master key shift
                                const transpose = data - 64;
                                SpessaLog.gsInfo(
                                    "Master Key-Shift",
                                    transpose,
                                    "keys"
                                );
                                this.setMIDIParameter("keyShift", transpose);
                                break;
                            }

                            case 0x06: {
                                // Roland master pan
                                // 63, it ranges from 1 to 127, NOT 0 to 127!
                                const pan = (data - 64) / 63;

                                SpessaLog.gsInfo("Master Pan", pan);
                                this.setMIDIParameter("pan", pan);
                                break;
                            }

                            case 0x7f: {
                                // Roland mode set
                                // GS mode set
                                if (data === 0x00) {
                                    // This is a GS reset
                                    SpessaLog.coolInfo(
                                        "MIDI System",
                                        "Roland GS"
                                    );
                                    this.reset("gs");
                                } else if (data === 0x7f) {
                                    // GS mode off
                                    SpessaLog.coolInfo(
                                        "MIDI System",
                                        "General MIDI 1"
                                    );
                                    this.reset("gm");
                                }
                                break;
                            }

                            default: {
                                SpessaLog.gsFail("System Parameter", syx);
                                break;
                            }
                        }
                        return;
                    }

                    // Part Parameter, Patch Common (Effects)
                    if (a2 === 0x01) {
                        const isReverb = a3 >= 0x30 && a3 <= 0x37;
                        const isChorus = a3 >= 0x38 && a3 <= 0x40;
                        const isDelay = a3 >= 0x50 && a3 <= 0x5a;
                        // Disable effect editing if locked
                        if (isReverb && this.systemParameters.gsReverbLock)
                            return;
                        if (isChorus && this.systemParameters.gsChorusLock)
                            return;
                        if (isDelay && this.systemParameters.gsDelayLock)
                            return;

                        switch (a3) {
                            default: {
                                SpessaLog.gsFail("Patch Common Parameter", [
                                    a3
                                ]);
                                break;
                            }

                            case 0x00: {
                                // Patch name
                                const patchName = readBinaryString(syx, 16, 7);
                                SpessaLog.gsInfo("Patch name", patchName);
                                this.callEvent("displayMessage", [...syx]);
                                break;
                            }
                            // Reverb
                            case 0x30: {
                                // Reverb macro
                                this.setReverbMacro(data);
                                SpessaLog.gsInfo("Reverb Macro", data);
                                // Event called in setMacro
                                break;
                            }
                            case 0x31: {
                                // Reverb character
                                this.gsReverbProcessor.character = data;
                                SpessaLog.gsInfo("Reverb Character", data);
                                this.callEvent("effectChange", {
                                    effect: "gsReverb",
                                    parameter: "character",
                                    value: data
                                });
                                break;
                            }
                            case 0x32: {
                                // Reverb pre-PLF
                                this.gsReverbProcessor.preLowpass = data;
                                SpessaLog.gsInfo("Reverb Pre-LPF", data);
                                this.callEvent("effectChange", {
                                    effect: "gsReverb",
                                    parameter: "preLowpass",
                                    value: data
                                });
                                break;
                            }
                            case 0x33: {
                                // Reverb level
                                this.gsReverbProcessor.level = data;
                                SpessaLog.gsInfo("Reverb Level", data);
                                this.callEvent("effectChange", {
                                    effect: "gsReverb",
                                    parameter: "level",
                                    value: data
                                });
                                break;
                            }
                            case 0x34: {
                                // Reverb time
                                this.gsReverbProcessor.time = data;
                                SpessaLog.gsInfo("Reverb Time", data);
                                this.callEvent("effectChange", {
                                    effect: "gsReverb",
                                    parameter: "time",
                                    value: data
                                });
                                break;
                            }
                            case 0x35: {
                                // Reverb delay feedback
                                this.gsReverbProcessor.delayFeedback = data;
                                SpessaLog.gsInfo("Reverb Delay Feedback", data);
                                this.callEvent("effectChange", {
                                    effect: "gsReverb",
                                    parameter: "delayFeedback",
                                    value: data
                                });
                                break;
                            }

                            case 0x36: {
                                // Reverb send to chorus, legacy SC-55 that's recognized by later models and unsupported.
                                break;
                            }

                            case 0x37: {
                                // Reverb predelay time
                                this.gsReverbProcessor.preDelayTime = data;
                                SpessaLog.gsInfo("Reverb Predelay Time", data);
                                this.callEvent("effectChange", {
                                    effect: "gsReverb",
                                    parameter: "preDelayTime",
                                    value: data
                                });
                                break;
                            }

                            // Chorus
                            case 0x38: {
                                // Chorus macro
                                this.setChorusMacro(data);
                                SpessaLog.gsInfo("Chorus Macro", data);
                                // Event called in setMacro
                                break;
                            }
                            case 0x39: {
                                // Chorus pre-LPF
                                this.gsChorusProcessor.preLowpass = data;
                                SpessaLog.gsInfo("Chorus Pre-LPF", data);
                                this.callEvent("effectChange", {
                                    effect: "gsChorus",
                                    parameter: "preLowpass",
                                    value: data
                                });
                                break;
                            }
                            case 0x3a: {
                                // Chorus level
                                this.gsChorusProcessor.level = data;
                                SpessaLog.gsInfo("Chorus Level", data);
                                this.callEvent("effectChange", {
                                    effect: "gsChorus",
                                    parameter: "level",
                                    value: data
                                });
                                break;
                            }
                            case 0x3b: {
                                // Chorus feedback
                                this.gsChorusProcessor.feedback = data;
                                SpessaLog.gsInfo("Chorus Feedback", data);
                                this.callEvent("effectChange", {
                                    effect: "gsChorus",
                                    parameter: "feedback",
                                    value: data
                                });
                                break;
                            }
                            case 0x3c: {
                                // Chorus delay
                                this.gsChorusProcessor.delay = data;
                                SpessaLog.gsInfo("Chorus Delay", data);
                                this.callEvent("effectChange", {
                                    effect: "gsChorus",
                                    parameter: "delay",
                                    value: data
                                });
                                break;
                            }
                            case 0x3d: {
                                // Chorus rate
                                this.gsChorusProcessor.rate = data;
                                SpessaLog.gsInfo("Chorus Rate", data);
                                this.callEvent("effectChange", {
                                    effect: "gsChorus",
                                    parameter: "rate",
                                    value: data
                                });
                                break;
                            }
                            case 0x3e: {
                                // Chorus depth
                                this.gsChorusProcessor.depth = data;
                                SpessaLog.gsInfo("Chorus Depth", data);
                                this.callEvent("effectChange", {
                                    effect: "gsChorus",
                                    parameter: "depth",
                                    value: data
                                });
                                break;
                            }
                            case 0x3f: {
                                // Chorus send level to reverb
                                this.gsChorusProcessor.sendLevelToReverb = data;
                                SpessaLog.gsInfo(
                                    "Chorus Send Level To Reverb",
                                    data
                                );
                                this.callEvent("effectChange", {
                                    effect: "gsChorus",
                                    parameter: "sendLevelToReverb",
                                    value: data
                                });
                                break;
                            }
                            case 0x40: {
                                // Chorus send level to delay
                                this.gsChorusProcessor.sendLevelToDelay = data;
                                this.updateActiveGSEffects();
                                SpessaLog.gsInfo(
                                    "Chorus Send Level To Delay",
                                    data
                                );
                                this.callEvent("effectChange", {
                                    effect: "gsChorus",
                                    parameter: "sendLevelToDelay",
                                    value: data
                                });
                                break;
                            }

                            // Delay
                            case 0x50: {
                                // Delay macro
                                this.setDelayMacro(data);
                                SpessaLog.gsInfo("Delay Macro", data);
                                // Event called in setMacro
                                break;
                            }
                            case 0x51: {
                                // Delay pre-PLF
                                this.gsDelayProcessor.preLowpass = data;
                                SpessaLog.gsInfo("Delay Pre-LPF", data);
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "preLowpass",
                                    value: data
                                });
                                break;
                            }
                            case 0x52: {
                                // Delay time center
                                this.gsDelayProcessor.timeCenter = data;
                                SpessaLog.gsInfo("Delay Time Center", data);
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "timeCenter",
                                    value: data
                                });
                                break;
                            }
                            case 0x53: {
                                // Delay time ratio left
                                this.gsDelayProcessor.timeRatioLeft = data;
                                SpessaLog.gsInfo("Delay Time Ratio Left", data);
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "timeRatioLeft",
                                    value: data
                                });
                                break;
                            }
                            case 0x54: {
                                // Delay time ratio right
                                this.gsDelayProcessor.timeRatioRight = data;
                                SpessaLog.gsInfo(
                                    "Delay Time Ratio Right",
                                    data
                                );
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "timeRatioRight",
                                    value: data
                                });
                                break;
                            }
                            case 0x55: {
                                // Delay level center
                                this.gsDelayProcessor.levelCenter = data;
                                SpessaLog.gsInfo("Delay Level Center", data);
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "levelCenter",
                                    value: data
                                });
                                break;
                            }
                            case 0x56: {
                                // Delay level left
                                this.gsDelayProcessor.levelLeft = data;
                                SpessaLog.gsInfo("Delay Level Left", data);
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "levelLeft",
                                    value: data
                                });
                                break;
                            }
                            case 0x57: {
                                // Delay level right
                                this.gsDelayProcessor.levelRight = data;
                                SpessaLog.gsInfo("Delay Level Right", data);
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "levelRight",
                                    value: data
                                });
                                break;
                            }
                            case 0x58: {
                                // Delay level
                                this.gsDelayProcessor.level = data;
                                SpessaLog.gsInfo("Delay Level", data);
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "level",
                                    value: data
                                });
                                break;
                            }
                            case 0x59: {
                                // Delay feedback
                                this.gsDelayProcessor.feedback = data;
                                SpessaLog.gsInfo("Delay Feedback", data);
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "feedback",
                                    value: data
                                });
                                break;
                            }
                            case 0x5a: {
                                // Delay send level to reverb
                                this.gsDelayProcessor.sendLevelToReverb = data;
                                SpessaLog.gsInfo(
                                    "Delay Send Level To Reverb",
                                    data
                                );
                                this.callEvent("effectChange", {
                                    effect: "gsDelay",
                                    parameter: "sendLevelToReverb",
                                    value: data
                                });
                                break;
                            }
                        }
                        break;
                    }

                    // Equalizer
                    if (a2 === 0x02) {
                        if (this.systemParameters.gsEqualizerLock) return;
                        const parameter = (
                            [
                                "lowFrequency",
                                "lowGain",
                                "highFrequency",
                                "highGain"
                            ] as const
                        )[a3];
                        if (parameter === undefined) {
                            SpessaLog.gsFail("Equalizer", [a3]);
                            return;
                        }
                        this.gsEqualizerProcessor[parameter] = data;
                        SpessaLog.gsInfo(`EQ ${parameter}`, data);
                        this.callEvent("effectChange", {
                            effect: "gsEqualizer",
                            parameter,
                            value: data
                        });
                        return;
                    }

                    // EFX Parameter
                    if (a2 === 0x03) {
                        if (this.systemParameters.gsInsertionLock) return;
                        const insertion = this.gsInsertionBlock;

                        if (a3 >= 0x03 && a3 <= 0x16) {
                            insertion.setParameter(a3 - 0x03, data);
                            SpessaLog.gsInfo(`EFX Parameter ${a3 - 2}`, data);
                            this.callEvent("effectChange", {
                                effect: "gsInsertion",
                                parameter: a3 - 0x03,
                                value: data
                            });
                            return;
                        }
                        switch (a3) {
                            default: {
                                SpessaLog.gsFail("Insertion Effect", [a3]);
                                return;
                            }

                            case 0x00: {
                                // EFX Type
                                const type = (data << 8) | syx[8];
                                SpessaLog.gsInfo("EFX Type", type.toString(16));
                                insertion.setType(type);
                                // The type change resets the send to delay
                                this.updateActiveGSEffects();
                                // Special case: 16-bit value
                                this.callEvent("effectChange", {
                                    effect: "gsInsertion",
                                    parameter: "type",
                                    value: type
                                });
                                return;
                            }

                            case 0x17: {
                                // To reverb
                                insertion.sendLevelToReverb = data;
                                SpessaLog.gsInfo(
                                    "EFX Send Level to Reverb",
                                    data
                                );
                                this.callEvent("effectChange", {
                                    effect: "gsInsertion",
                                    parameter: "sendLevelToReverb",
                                    value: data
                                });
                                return;
                            }

                            case 0x18: {
                                // To chorus
                                insertion.sendLevelToChorus = data;
                                SpessaLog.gsInfo(
                                    "EFX Send Level to Chorus",
                                    data
                                );
                                this.callEvent("effectChange", {
                                    effect: "gsInsertion",
                                    parameter: "sendLevelToChorus",
                                    value: data
                                });
                                return;
                            }

                            case 0x19: {
                                // To delay
                                insertion.sendLevelToDelay = data;
                                this.updateActiveGSEffects();
                                SpessaLog.gsInfo(
                                    "EFX Send Level to Delay",
                                    data
                                );
                                this.callEvent("effectChange", {
                                    effect: "gsInsertion",
                                    parameter: "sendLevelToDelay",
                                    value: data
                                });
                                return;
                            }

                            case 0x1b:
                            case 0x1c:
                            case 0x1d:
                            case 0x1e: {
                                // EFX control source and depth 1, 2
                                const parameter = (
                                    [
                                        "controlSource1",
                                        "controlDepth1",
                                        "controlSource2",
                                        "controlDepth2"
                                    ] as const
                                )[a3 - 0x1b];
                                insertion[parameter] = data;
                                SpessaLog.gsInfo(`EFX ${parameter}`, data);
                                this.callEvent("effectChange", {
                                    effect: "gsInsertion",
                                    parameter,
                                    value: data
                                });
                                return;
                            }

                            case 0x1f: {
                                // Send EQ switch, 0 is off and anything else is on
                                const on = data !== 0;
                                insertion.sendEQSwitch = on;
                                SpessaLog.gsInfo(
                                    "EFX Send EQ Switch",
                                    on ? "ON" : "OFF"
                                );
                                this.callEvent("effectChange", {
                                    effect: "gsInsertion",
                                    parameter: "sendEQSwitch",
                                    value: on
                                });
                                return;
                            }
                        }
                    }

                    // Patch Parameters
                    if (a2 >> 4 === 1) {
                        // This is an individual part (channel) parameter
                        // Determine the channel
                        // Note that: 0 means channel 9 (drums), and only then 1 means channel 0, 2 channel 1, etc.
                        // SC-8850 manual, page 237
                        const channel =
                            MIDIUtils.gsPartToChannel(a2 & 0x0f) +
                            channelOffset;
                        // For example, 0x1A means A = 10, which corresponds to channel 11 (counting from 1)
                        const ch = this.midiChannels[channel];
                        if (!ch) {
                            // Testcase: Sarah Geronimo - Maybe This Time
                            SpessaLog.gsFail(
                                `Patch Parameter for ${channel}`,
                                syx,
                                "Invalid part number."
                            );
                            return;
                        }
                        switch (a3) {
                            default: {
                                // This is some other GS sysex...
                                SpessaLog.gsFail(
                                    `Patch Part Parameter for ${channel}`,
                                    [a3]
                                );
                                return;
                            }

                            case 0x00: {
                                // Tone number (program change)
                                ch.controllerChange(
                                    MIDIControllers.bankSelect,
                                    data
                                );
                                ch.programChange(syx[8]);
                                break;
                            }

                            case 0x02: {
                                // Rx. channel (0x10 is OFF)
                                const rxChannel =
                                    data === 0x10 ? -1 : data + channelOffset;
                                ch.setMIDIParameter("rxChannel", rxChannel);
                                this.customChannelNumbers ||=
                                    rxChannel !== ch.channel;
                                SpessaLog.gsInfo(
                                    `Rx. Channel on ${channel}`,
                                    rxChannel
                                );
                                break;
                            }

                            case 0x13: {
                                // Mono/poly
                                ch.setMIDIParameter("polyMode", data === 1);
                                SpessaLog.gsInfo(
                                    `Mono/poly on ${channel}`,
                                    ch.midiParameters.polyMode ? "POLY" : "MONO"
                                );
                                break;
                            }

                            case 0x14: {
                                ch.setMIDIParameter("assignMode", data);
                                SpessaLog.gsInfo(
                                    `Assign mode on ${channel}`,
                                    data
                                );
                                break;
                            }

                            case 0x15: {
                                // This is the Use for Rhythm Part sysex (multiple drums)
                                const prevMap = ch.midiParameters.drumMap;
                                ch.setMIDIParameter("drumMap", data);
                                const newMap = ch.midiParameters.drumMap;
                                // Non-melodic means a drum channel
                                const isDrums = data > MELODIC_MAP;
                                // Testcase: gs_drum_change_test
                                // GS resets to the default kit not only when toggling drums,
                                // But on any map change too.
                                if (
                                    !ch.systemParameters.presetLock &&
                                    (isDrums !== ch.patch.isGMGSDrum ||
                                        newMap !== prevMap)
                                ) {
                                    ch.patch.bankMSB = 0;
                                    ch.patch.bankLSB = 0;
                                    ch.patch.isGMGSDrum = isDrums;
                                    ch.programChange(0);
                                }
                                SpessaLog.gsInfo(
                                    `Drums on ${channel}`,
                                    isDrums.toString()
                                );
                                return;
                            }

                            case 0x16: {
                                // This is the pitch key shift sysex
                                const keyShift = data - 64;
                                ch.setMIDIParameter("keyShift", keyShift);
                                SpessaLog.gsInfo(
                                    `Key Shift for ${channel}`,
                                    keyShift
                                );
                                return;
                            }

                            // Pitch offset fine in Hz is not supported so far

                            case 0x19: {
                                // Part level (cc#7)
                                ch.controllerChange(
                                    MIDIControllers.mainVolume,
                                    data
                                );
                                return;
                            }

                            case 0x1a: {
                                // Velocity Sense Depth
                                ch.setMIDIParameter("velocitySenseDepth", data);
                                SpessaLog.gsInfo(
                                    `Velocity Sense Depth for ${channel}`,
                                    data
                                );
                                return;
                            }

                            case 0x1b: {
                                // Velocity Sense Offset
                                ch.setMIDIParameter(
                                    "velocitySenseOffset",
                                    data
                                );
                                SpessaLog.gsInfo(
                                    `Velocity Sense Offset for ${channel}`,
                                    data
                                );
                                return;
                            }

                            // Pan position
                            case 0x1c: {
                                // 0 is random
                                const panPosition = data;
                                const randomPan = panPosition === 0;
                                ch.setMIDIParameter("randomPan", randomPan);
                                if (randomPan)
                                    SpessaLog.gsInfo(
                                        `Random pan on ${channel}`,
                                        "ON"
                                    );
                                else
                                    ch.controllerChange(
                                        MIDIControllers.pan,
                                        panPosition
                                    );

                                break;
                            }

                            case 0x1f: {
                                // CC1 controller number
                                ch.setMIDIParameter(
                                    "cc1",
                                    data as MIDIController
                                );
                                SpessaLog.gsInfo(
                                    `CC1 Controller Number for ${channel}`,
                                    data
                                );
                                break;
                            }

                            case 0x20: {
                                // CC2 controller number
                                ch.setMIDIParameter(
                                    "cc2",
                                    data as MIDIController
                                );
                                SpessaLog.gsInfo(
                                    `CC2 Controller Number for ${channel}`,
                                    data
                                );
                                break;
                            }

                            // Chorus send
                            case 0x21: {
                                ch.controllerChange(
                                    MIDIControllers.chorusDepth,
                                    data
                                );
                                break;
                            }

                            // Reverb send
                            case 0x22: {
                                ch.controllerChange(
                                    MIDIControllers.reverbDepth,
                                    data
                                );
                                break;
                            }

                            case 0x2a: {
                                // Fine tune
                                // 0-16384
                                const tune = (data << 7) | syx[8];
                                const cents = (tune - 8192) / 81.92;
                                ch.setMIDIParameter("fineTune", cents);
                                SpessaLog.gsInfo(
                                    `Fine tuning for ${channel}`,
                                    Math.round(cents),
                                    "cents"
                                );
                                break;
                            }

                            // Delay send
                            case 0x2c: {
                                ch.controllerChange(
                                    MIDIControllers.variationDepth,
                                    data
                                );
                                break;
                            }

                            case 0x30: {
                                // Vibrato rate
                                ch.controllerChange(
                                    MIDIControllers.vibratoRate,
                                    data
                                );
                                break;
                            }

                            case 0x31: {
                                // Vibrato depth
                                ch.controllerChange(
                                    MIDIControllers.vibratoDepth,
                                    data
                                );
                                break;
                            }

                            case 0x32: {
                                // Filter cutoff
                                // It's so out of order, Roland...
                                ch.controllerChange(
                                    MIDIControllers.brightness,
                                    data
                                );
                                break;
                            }

                            case 0x33: {
                                // Filter resonance
                                ch.controllerChange(
                                    MIDIControllers.filterResonance,
                                    data
                                );
                                break;
                            }

                            case 0x34: {
                                // Attack time
                                ch.controllerChange(
                                    MIDIControllers.attackTime,
                                    data
                                );
                                break;
                            }

                            case 0x35: {
                                // Decay time
                                ch.controllerChange(
                                    MIDIControllers.decayTime,
                                    data
                                );
                                break;
                            }

                            case 0x36: {
                                // Release time
                                ch.controllerChange(
                                    MIDIControllers.releaseTime,
                                    data
                                );
                                break;
                            }

                            case 0x37: {
                                // Vibrato delay
                                // It seems that they forgot about it and put it last...
                                ch.controllerChange(
                                    MIDIControllers.vibratoDelay,
                                    data
                                );
                                break;
                            }

                            case 0x40: {
                                // Scale tuning: up to 12 bytes
                                const tuningBytes = syx.length - 9; // Data starts at 7, minus checksum and f7
                                // Read em bytes
                                const newTuning = new Int8Array(12);
                                for (let i = 0; i < tuningBytes; i++) {
                                    newTuning[i] = syx[i + 7] - 64;
                                }
                                ch.setOctaveTuning(newTuning);
                                SpessaLog.gsInfo(
                                    `Octave Scale Tuning for ${channel}`,
                                    newTuning.join(", ")
                                );
                                break;
                            }
                        }
                        return;
                    }

                    // Patch Parameter controllers
                    if (a2 >> 4 === 2) {
                        // This is an individual part (channel) parameter
                        // Determine the channel
                        // Note that: 0 means channel 9 (drums), and only then 1 means channel 0, 2 channel 1, etc.
                        // SC-8850 manual, page 237
                        const channel =
                            MIDIUtils.gsPartToChannel(a2 & 0x0f) +
                            channelOffset;
                        // For example, 0x1A means A = 10, which corresponds to channel 11 (counting from 1)
                        const ch = this.midiChannels[channel];
                        if (!ch) {
                            SpessaLog.gsFail(
                                `Patch Parameter Controller for ${channel}`,
                                syx,
                                "Invalid part number."
                            );
                            return;
                        }
                        switch (a3 & 0xf0) {
                            default: {
                                // This is some other GS sysex...
                                SpessaLog.gsFail(
                                    `Patch Parameter Controller for ${channel}`,
                                    [a3 & 0xf0]
                                );
                                break;
                            }

                            case 0x00: {
                                // Modulation wheel
                                if ((a3 & 0x0f) === 0x04) {
                                    // LFO1 Pitch depth
                                    // Special case:
                                    // If the source is a mod wheel, it's a strange way of setting the modulation depth
                                    // Testcase: J-Cycle.mid (it affects gm.dls which uses LFO1 for modulation)
                                    const cents = (data / 127) * 600;
                                    ch.setMIDIParameter(
                                        "modulationDepth",
                                        cents
                                    );
                                    SpessaLog.gsInfo(
                                        `Modulation depth for ${channel}`,
                                        Math.round(cents),
                                        "cents"
                                    );
                                    break;
                                }
                                ch.dynamicModulators.setupReceiverGS(
                                    a3,
                                    data,
                                    MIDIControllers.modulationWheel,
                                    true,
                                    "mod wheel"
                                );
                                break;
                            }

                            case 0x10: {
                                // Pitch wheel
                                if ((a3 & 0x0f) === 0x00) {
                                    // See https://github.com/spessasus/SpessaSynth/issues/154
                                    // Pitch control
                                    // Special case:
                                    // If the source is a pitch wheel, it's a strange way of setting the pitch wheel range
                                    // Testcase: th07_03.mid
                                    const centeredValue = data - 64;
                                    ch.setMIDIParameter(
                                        "pitchWheelRange",
                                        centeredValue
                                    );
                                    SpessaLog.gsInfo(
                                        `Pitch Wheel Range for ${channel}`,
                                        centeredValue,
                                        "semitones"
                                    );
                                    break;
                                }
                                ch.dynamicModulators.setupReceiverGS(
                                    a3,
                                    data,
                                    ModulatorControllerSources.pitchWheel,
                                    false,
                                    "pitch wheel",
                                    true
                                );
                                break;
                            }

                            case 0x20: {
                                // Channel pressure
                                ch.dynamicModulators.setupReceiverGS(
                                    a3,
                                    data,
                                    ModulatorControllerSources.channelPressure,
                                    false,
                                    "channel pressure"
                                );
                                break;
                            }

                            case 0x30: {
                                // Poly pressure
                                ch.dynamicModulators.setupReceiverGS(
                                    a3,
                                    data,
                                    ModulatorControllerSources.polyPressure,
                                    false,
                                    "poly pressure"
                                );
                                break;
                            }

                            case 0x40: {
                                // CC1
                                ch.dynamicModulators.setupReceiverGS(
                                    a3,
                                    data,
                                    ch.midiParameters.cc1,
                                    true,
                                    "CC1"
                                );
                                break;
                            }

                            case 0x50: {
                                // CC2
                                ch.dynamicModulators.setupReceiverGS(
                                    a3,
                                    data,
                                    ch.midiParameters.cc2,
                                    true,
                                    "CC2"
                                );
                            }
                        }
                        return;
                    }

                    // Patch Parameter Tone Map
                    if (a2 >> 4 === 4) {
                        // This is an individual part (channel) parameter
                        // Determine the channel
                        // Note that: 0 means channel 9 (drums), and only then 1 means channel 0, 2 channel 1, etc.
                        // SC-8850 manual, page 237
                        const channel =
                            MIDIUtils.gsPartToChannel(a2 & 0x0f) +
                            channelOffset;
                        // For example, 0x1A means A = 10, which corresponds to channel 11 (counting from 1)
                        const ch = this.midiChannels[channel];
                        if (!ch) {
                            SpessaLog.gsFail(
                                `Patch Parameter Tone Map for ${channel}`,
                                syx,
                                "Invalid part number."
                            );
                            return;
                        }

                        switch (a3) {
                            default: {
                                // This is some other GS sysex...
                                SpessaLog.gsFail("Patch Part Parameter", [a3]);
                                break;
                            }

                            case 0x00:
                            case 0x01: {
                                // Tone map number (cc#32)
                                ch.controllerChange(
                                    MIDIControllers.bankSelectLSB,
                                    data
                                );
                                break;
                            }

                            case 0x20: {
                                // EQ on/off
                                const eq = data === 1;
                                ch.setMIDIParameter("eqEnabled", eq);
                                SpessaLog.gsInfo(
                                    `EQ for ${channel}`,
                                    eq ? "ON" : "OFF"
                                );
                                break;
                            }

                            case 0x22: {
                                // EFX assign
                                const efx = data === 1;
                                ch.setMIDIParameter("efxAssign", efx);
                                SpessaLog.gsInfo(
                                    `EFX assign for ${channel}`,
                                    efx ? "EFX" : "BYPASS"
                                );
                                this.updateActiveGSEffects();
                            }
                        }
                        return;
                    }
                    SpessaLog.gsFail("Patch Parameter", syx);
                    return;
                }
                // Drum Setup
                if (a1 === 0x41 || a1 === 0x51) {
                    // 51 means BLOCK B (+16 channels)
                    // Testcase: 95043-2.KYC.mid
                    if (this.systemParameters.drumLock) return;
                    // In gs, the map is offset by the default (e.g. 1)
                    // So 0 means drum map 1, 1 means drum map 2, etc.
                    const map = (a2 >> 4) + DEFAULT_GS_DRUM_MAP;
                    const drumKey = a3;
                    const param = a2 & 0xf;
                    switch (param) {
                        default: {
                            SpessaLog.gsFail("Drum Setup", [param]);
                            return;
                        }

                        case 0x0: {
                            // Drum map name
                            const patchName = readBinaryString(syx, 12, 7);
                            SpessaLog.gsInfo(
                                `Drum Map Name for MAP${map}`,
                                patchName
                            );
                            this.callEvent("displayMessage", [...syx]);
                            break;
                        }

                        case 0x1: {
                            // Here it's relative to 60, not 64 like NRPN. For some reason...

                            const pitch = data - 60;
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                // Apply same thing: SC-55 uses 100 cents, SC-88 and above is 50
                                ch.drumParams[drumKey].pitchCoarse =
                                    pitch * (ch.patch.bankLSB === 1 ? 1 : 0.5);
                            }
                            SpessaLog.gsInfo(
                                `Drum Pitch for MAP${map}, key ${drumKey}`,
                                pitch
                            );
                            break;
                        }

                        case 0x2: {
                            // Drum Level
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                ch.drumParams[drumKey].level = data;
                            }
                            SpessaLog.gsInfo(
                                `Drum Level for MAP${map}, key ${drumKey}`,
                                data
                            );
                            break;
                        }

                        case 0x3: {
                            // Drum Assign Group (exclusive class)
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                ch.drumParams[drumKey].assignGroup = data;
                            }
                            SpessaLog.gsInfo(
                                `Drum Assign Group for MAP${map}, key ${drumKey}`,
                                data
                            );
                            break;
                        }

                        case 0x4: {
                            // Pan
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                ch.drumParams[drumKey].pan = data;
                            }
                            SpessaLog.gsInfo(
                                `Drum Pan for MAP${map}, key ${drumKey}`,
                                data
                            );
                            break;
                        }

                        case 0x5: {
                            // Reverb
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                ch.drumParams[drumKey].reverbSend = data;
                            }
                            SpessaLog.gsInfo(
                                `Drum Reverb for MAP${map}, key ${drumKey}`,
                                data
                            );
                            break;
                        }

                        case 0x6: {
                            // Chorus
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                ch.drumParams[drumKey].chorusSend = data;
                            }
                            SpessaLog.gsInfo(
                                `Drum Chorus for MAP${map}, key ${drumKey}`,
                                data
                            );
                            break;
                        }

                        case 0x7: {
                            // Receive Note Off
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                ch.drumParams[drumKey].rxNoteOff = data === 1;
                            }
                            SpessaLog.gsInfo(
                                `Drum Note Off for MAP${map}, key ${drumKey}`,
                                data === 1 ? "ON" : "OFF"
                            );
                            break;
                        }

                        case 0x8: {
                            // Receive Note On
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                ch.drumParams[drumKey].rxNoteOn = data === 1;
                            }
                            SpessaLog.gsInfo(
                                `Drum Note On for MAP${map}, key ${drumKey}`,
                                data === 1 ? "ON" : "OFF"
                            );
                            break;
                        }

                        case 0x9: {
                            // Delay
                            for (const ch of this.midiChannels) {
                                if (ch.midiParameters.drumMap !== map) continue;
                                ch.drumParams[drumKey].variationSend = data;
                            }
                            SpessaLog.gsInfo(
                                `Drum Delay for MAP${map}, key ${drumKey}`,
                                data
                            );
                            break;
                        }
                    }
                    return;
                }
                // User Drum Set
                if (a1 === 0x21) {
                    handleUserDrum.call(this, a2, a3, data, syx);
                    return;
                }

                // User Drum Set Bulk Dump
                if (a1 === 0x29) {
                    const dataLength = syx.length - 9;
                    SpessaLog.info(
                        `%cUser Drum Set Bulk Dump detected! Keys: %c${dataLength}`,
                        ConsoleColors.recognized,
                        ConsoleColors.value
                    );

                    // Top half of a2 stays the same (indicates which user drum)
                    // While the bottom param is something else
                    // Guessed by analyzing 95043-2.KYC.mid

                    let actualDrumParam: number;
                    switch (a2 & 0x0f) {
                        default: {
                            SpessaLog.gsFail(
                                "User Drum Bulk Dump System Exclusive",
                                syx
                            );
                            return;
                        }

                        case 0x0: {
                            // Most at 60 = play note?
                            actualDrumParam = 1;
                            break;
                        }

                        case 0x1: {
                            // Level?
                            actualDrumParam = 2;
                            break;
                        }

                        case 0x2: {
                            // Matches gm.dls exclusive class pretty well, assign group?
                            actualDrumParam = 3;
                            break;
                        }

                        case 0x3: {
                            // Most at 64, so pan?
                            actualDrumParam = 4;
                            break;
                        }

                        case 0x4: {
                            // 0 on bass, so reverb?
                            actualDrumParam = 5;
                            break;
                        }

                        case 0x5: {
                            // 0 on all, so chorus?
                            actualDrumParam = 6;
                            break;
                        }

                        case 0x6: {
                            // 16 on all
                            // In the order, rx notes should be here, it's 0x10, so maybe
                            // It's both? on << 4 | off?
                            // Special handling is needed
                            const address2Off = (a2 & 0xf0) | 7;
                            const address2On = (a2 & 0xf0) | 8;
                            for (
                                let midiNote = 0;
                                midiNote < dataLength;
                                midiNote++
                            ) {
                                handleUserDrum.call(
                                    this,
                                    address2Off,
                                    midiNote,
                                    syx[midiNote + 7] & 0xf,
                                    syx
                                );
                                handleUserDrum.call(
                                    this,
                                    address2On,
                                    midiNote,
                                    syx[midiNote + 7] >> 4,
                                    syx
                                );
                            }
                            return;
                        }

                        case 0x7: {
                            // All 0, so delay
                            actualDrumParam = 9;
                            break;
                        }

                        case 0x8: {
                            // All 2 and this is a 88pro midi, so the map is 2
                            actualDrumParam = 0xa;
                            break;
                        }

                        case 0x9: {
                            // 0xA matches note number so the only one left is the program
                            actualDrumParam = 0xb;
                            break;
                        }

                        case 0xa: {
                            // Drum numbers increase so source note
                            actualDrumParam = 0xc;
                            break;
                        }

                        case 0xb: {
                            // 16 chars, seems to be a name (spec is wrong? says 12)
                            actualDrumParam = 0;
                            break;
                        }
                    }

                    const address2 = (a2 & 0xf0) | actualDrumParam;
                    for (let midiNote = 0; midiNote < dataLength; midiNote++) {
                        handleUserDrum.call(
                            this,
                            address2,
                            midiNote,
                            syx[midiNote + 7],
                            syx
                        );
                    }
                    return;
                }

                // This is some other GS sysex...
                SpessaLog.gsFail("System Exclusive", syx);
                return;
            }

            // GS Display
            case 0x45: {
                // 0x45: GS Display Data
                // Check for embedded copyright
                // (Roland SC display sysex) http://www.bandtrax.com.au/sysex.htm
                // Sound Canvas Display
                if (syx[4] === 0x10) {
                    this.callEvent("displayMessage", [...syx]);
                }
                // 0x20: SC-8850 160x64 display
                // Thanks to midi-movie-player for details on this message
                else if (syx[4] === 0x20) {
                    this.callEvent("displayMessage", [...syx]);
                }
                return;
            }

            // Some Roland
            // This sysEx gets emitted by Falcosoft MIDI Player
            case 0x16: {
                if (syx[4] === 0x10) {
                    // This is a roland master volume message
                    this.setMIDIParameter("volume", syx[7] / 100);
                    SpessaLog.coolInfo("Roland Master Volume Control", syx[7]);
                    return;
                } else {
                    SpessaLog.unsupported("Roland", syx);
                }
            }
        }
    } else {
        // This is something else...
        SpessaLog.unsupported("Roland", syx);
        return;
    }
}
