import { absCentsToHz, cbAttenuationToGain } from "../voice/unit_converter";
import type { Voice } from "../voice/voice";
import type { MIDIChannel } from "./midi_channel";
import { GeneratorTypes } from "../../../soundbank/basic_soundbank/generator_types";
import { MIDIControllers } from "../../../midi/enums";

const TWO_PI = Math.PI * 2;

const HALF_PI = Math.PI / 2;

/**
 * The maximum number of voice send buffers per channel.
 * Voices that don't fit are mixed directly in renderVoice() with the shared processor buffer.
 */
const MAX_VOICE_SEND_BUFFERS = 16;

const MIN_PAN = -500;
const MAX_PAN = 500;
const PAN_RESOLUTION = MAX_PAN - MIN_PAN;

// Initialize pan lookup tables
const panTableLeft = new Float32Array(PAN_RESOLUTION + 1);
const panTableRight = new Float32Array(PAN_RESOLUTION + 1);
for (let pan = MIN_PAN; pan <= MAX_PAN; pan++) {
    // Normalize to 0-1
    const realPan = (pan - MIN_PAN) / PAN_RESOLUTION;
    const tableIndex = pan - MIN_PAN;
    panTableLeft[tableIndex] = Math.cos(HALF_PI * realPan);
    panTableRight[tableIndex] = Math.sin(HALF_PI * realPan);
}

/**
 * Computes the LFO value for the given phase.
 * All waveforms are at zero and rising at the default start phase of 0.25.
 * @param phase the LFO phase, from 0 to 1.
 * @param waveform 0 for triangle, 1 for sawtooth, 2 for sine.
 * @returns the LFO value, from -1 to 1.
 */
function getLfoValue(phase: number, waveform: number) {
    if (waveform === 2) {
        // Sine
        return Math.sin(TWO_PI * (phase - 0.25));
    }
    if (waveform === 1) {
        // Rising sawtooth
        const p = phase + 0.25;
        return 2 * (p >= 1 ? p - 1 : p) - 1;
    }
    // Triangle
    return 1 - 4 * Math.abs(phase - 0.5);
}

/**
 * Renders a voice into one of the channel's voice send buffers,
 * which are later mixed into the stereo output and the effect sends.
 * @param voice the voice to render
 * @param timeNow current time in seconds
 * @param sampleCount the number of samples to render (the buffers are 0-based, so no offset is needed)
 */
export function renderVoice(
    this: MIDIChannel,
    voice: Voice,
    timeNow: number,
    sampleCount: number
) {
    // Delayed voice start (SFE): nothing runs until the voice starts
    if (timeNow < voice.startTime) {
        voice.hasRendered = true;
        return;
    }
    // Check if release
    if (
        !voice.isInRelease && // If not in release, check if the release time is
        timeNow >= voice.releaseStartTime
    ) {
        // Release the voice here
        voice.isInRelease = true;
        voice.volEnv.startRelease(voice);
        voice.modEnv.startRelease(voice);
        voice.modEnv2.startRelease(voice);

        // Looping mode 3
        if (voice.loopingMode === 3) {
            voice.wavetable.isLooping = false;
        }
    }
    voice.hasRendered = true;

    // Important sanity check, as we may disable the voice now
    // Testcase: mono mode with chords
    if (!voice.isActive) return;

    const core = this.synthCore;
    const sampleRate = core.sampleRate;
    const modulated = voice.modulatedGenerators;

    // CALCULATION START
    // TUNING
    let targetKey = voice.targetKey;
    // Calculate tuning
    let cents =
        voice.pitchOffset + // Voice pitch offset
        modulated[GeneratorTypes.fineTune] + // Soundfont fine tune
        this.octaveTuning[targetKey] + // MTS octave tuning
        this.currentTuning; // Channel tuning
    let semitones = modulated[GeneratorTypes.coarseTune]; // Soundfont coarse tuning

    // MIDI Tuning Standard
    // Use `midiNote` here since it was used for selecting the preset if tuning was active
    const tuning =
        core.tunings[
            // The preset can be gone while voices play (a removed bank),
            // But the patch is always there for us!
            (this.preset?.program ?? this.patch.program) * 128 + voice.midiNote
        ];
    if (tuning !== -1) {
        // Tuning is encoded as float
        // For example: 60.56 means key 60 and 56 cents (or 0.56 semitones)
        // Override key
        targetKey = Math.trunc(tuning);
        // Add microtonal tuning
        semitones += tuning - targetKey;
    }

    // Portamento
    if (voice.portamentoFromKey > -1) {
        // 0 to 1
        const elapsed = Math.min(
            (timeNow - voice.startTime) / voice.portamentoDuration,
            1
        );
        const diff = targetKey - voice.portamentoFromKey;
        // Zero progress means the pitch being in fromKey, full progress means the normal pitch
        semitones -= diff * (1 - elapsed);
    }

    // Calculate tuning by key using soundfont's scale tuning
    cents +=
        (targetKey - voice.rootKey) * modulated[GeneratorTypes.scaleTuning];

    // Low pass excursion with LFO and mod envelope
    let lowpassExcursion = 0;
    let volumeExcursionCentibels = 0;
    let voiceGain =
        voice.gainModifier * (1 + modulated[GeneratorTypes.amplitude] / 1000);

    // Vibrato LFO
    if (timeNow >= voice.vibLfoStartTime) {
        const vibPitchDepth = modulated[GeneratorTypes.vibLfoToPitch];
        const vibVolDepth = modulated[GeneratorTypes.vibLfoToVolume];
        const vibFilterDepth = modulated[GeneratorTypes.vibLfoToFilterFc];
        const vibAmplitudeDepth =
            modulated[GeneratorTypes.vibLfoAmplitudeDepth];
        if (
            vibPitchDepth !== 0 ||
            vibVolDepth !== 0 ||
            vibFilterDepth !== 0 ||
            vibAmplitudeDepth !== 0
        ) {
            const vibFreqHz = Math.max(
                0,
                absCentsToHz(modulated[GeneratorTypes.freqVibLFO]) +
                    modulated[GeneratorTypes.vibLfoRate] / 100
            );
            const rateInc = (vibFreqHz * sampleCount) / sampleRate;
            let vibLfoValue = getLfoValue(
                voice.vibLfoPhase,
                modulated[GeneratorTypes.vibLfoWaveform]
            );
            if ((voice.vibLfoPhase += rateInc) >= 1) voice.vibLfoPhase -= 1;
            // Fade in (SFE)
            if (voice.vibLfoFade > 0) {
                const fade =
                    (timeNow - voice.vibLfoStartTime) / voice.vibLfoFade;
                if (fade < 1) vibLfoValue *= fade;
            }
            cents += vibLfoValue * vibPitchDepth;
            // Low pass frequency
            lowpassExcursion += vibLfoValue * vibFilterDepth;

            // Vol env volume offset
            // Negate the lfo value because audigy starts with increase rather than decrease
            volumeExcursionCentibels += -vibLfoValue * vibVolDepth;

            // Amplitude depth
            // Like SCVA: double gain at peak, 0 at lowest (times depth)
            voiceGain *= 1 + vibLfoValue * (vibAmplitudeDepth / 1000);
        }
    }

    // Mod LFO
    if (timeNow >= voice.modLfoStartTime) {
        const modPitchDepth = modulated[GeneratorTypes.modLfoToPitch];
        const modVolDepth = modulated[GeneratorTypes.modLfoToVolume];
        const modFilterDepth = modulated[GeneratorTypes.modLfoToFilterFc];
        const modAmplitudeDepth =
            modulated[GeneratorTypes.modLfoAmplitudeDepth];
        // Don't compute mod lfo unless necessary
        if (
            modPitchDepth !== 0 ||
            modFilterDepth !== 0 ||
            modVolDepth !== 0 ||
            modAmplitudeDepth !== 0
        ) {
            const modFreqHz = Math.max(
                0,
                absCentsToHz(modulated[GeneratorTypes.freqModLFO]) +
                    modulated[GeneratorTypes.modLfoRate] / 100
            );
            const rateInc = (modFreqHz * sampleCount) / sampleRate;
            let modLfoValue = getLfoValue(
                voice.modLfoPhase,
                modulated[GeneratorTypes.modLfoWaveform]
            );
            if ((voice.modLfoPhase += rateInc) >= 1) voice.modLfoPhase -= 1;
            // Fade in (SFE)
            if (voice.modLfoFade > 0) {
                const fade =
                    (timeNow - voice.modLfoStartTime) / voice.modLfoFade;
                if (fade < 1) modLfoValue *= fade;
            }
            cents += modLfoValue * modPitchDepth;
            // Vol env volume offset
            // Negate the lfo value because audigy starts with increase rather than decrease
            volumeExcursionCentibels += -modLfoValue * modVolDepth;
            // Low pass frequency
            lowpassExcursion += modLfoValue * modFilterDepth;

            // Amplitude depth
            // Like SCVA: double gain at peak, 0 at lowest (times depth)
            voiceGain *= 1 + modLfoValue * (modAmplitudeDepth / 1000);
        }
    }

    const { systemParameters } = core;

    // Channel vibrato (custom vibrato)
    // TODO: Replace this with proper GS vibrato someday
    if (
        systemParameters.customVibrato &&
        this._midiControllers[MIDIControllers.modulationWheel] === 0 &&
        this.customVibrato.depth > 0
    ) {
        // Inlined LFO from 4.2.0
        const vibStart = voice.startTime + this.customVibrato.delay;
        if (timeNow >= vibStart) {
            const elapsed = timeNow - vibStart;

            // 2pif t gives a full sine cycle at the specified frequency
            cents +=
                Math.sin(TWO_PI * this.customVibrato.rate * elapsed) *
                this.customVibrato.depth;
        }
    }

    // Mod env
    const modEnvPitchDepth = modulated[GeneratorTypes.modEnvToPitch];
    const modEnvFilterDepth = modulated[GeneratorTypes.modEnvToFilterFc];
    // Don't compute mod env unless necessary
    if (modEnvFilterDepth !== 0 || modEnvPitchDepth !== 0) {
        const modEnv = voice.modEnv.process(voice, timeNow);
        // Apply values
        lowpassExcursion += modEnv * modEnvFilterDepth;
        cents += modEnv * modEnvPitchDepth;
    }

    // Second mod env (SFE)
    const modEnv2PitchDepth = modulated[GeneratorTypes.modEnv2ToPitch];
    const modEnv2FilterDepth = modulated[GeneratorTypes.modEnv2ToFilterFc];
    if (modEnv2FilterDepth !== 0 || modEnv2PitchDepth !== 0) {
        const modEnv2 = voice.modEnv2.process(voice, timeNow);
        lowpassExcursion += modEnv2 * modEnv2FilterDepth;
        cents += modEnv2 * modEnv2PitchDepth;
    }

    // Default resonant modulator: it does not affect the filter gain (neither XG nor GS did that)
    volumeExcursionCentibels -= voice.resonanceOffset;

    // Finally, calculate the playback rate
    const centsTotal = cents + semitones * 100;
    const centsRounded = centsTotal | 0;
    // Round for testing if equal,
    // But let's allow sub-microtonal tunings, because why not? :-)
    if (centsRounded !== voice.tuningCents) {
        voice.tuningCents = centsRounded;
        voice.tuningRatio = Math.pow(2, centsTotal / 1200);
    }

    // Gain target
    const gainTarget =
        cbAttenuationToGain(modulated[GeneratorTypes.initialAttenuation]) *
        cbAttenuationToGain(volumeExcursionCentibels);

    // Looping mode 2: start on release. process only volEnv
    if (voice.loopingMode === 2 && !voice.isInRelease) {
        voice.isActive = voice.volEnv.process(sampleCount, gainTarget);
        return;
    }

    // SYNTHESIS
    const buffer = core.voiceBuffer;
    // Wave table oscillator
    voice.isActive = voice.wavetable.process(
        sampleCount,
        voice.tuningRatio,
        buffer
    );

    // Vol env (output gain calculation)
    // Get the previous value
    let gain = voice.volEnv.outputGain;
    // Compute the new value
    const envActive = voice.volEnv.process(sampleCount, gainTarget);

    // Note, we do not use &&= as it short-circuits!
    // And we don't do = either as wavetable might've marked it as inactive (end of sample)
    voice.isActive = voice.isActive && envActive;

    // Pan
    let pan: number;
    if (voice.overridePan) {
        pan = voice.overridePan;
    } else {
        // Smooth out pan to prevent clicking
        voice.currentPan +=
            (modulated[GeneratorTypes.pan] - voice.currentPan) *
            core.panSmoothingFactor;
        pan = voice.currentPan;
    }

    const outputGain = this.currentGain * voiceGain;
    const panIndex =
        (Math.min(Math.max(-500, pan + this.currentPan), 500) + 500) | 0;

    /**
     * Do not send to effects if:
     * - Either effects are disabled
     * - Or insertion is active on this channel (Insertion takes over the voice data)
     * - Or the channel is assigned to an XG insertion effect.
     * XG ignores per-drum sends when insertion is enabled, and only the post-insertion (global) audio is sent (so whole drum audio, even if send is 0 for a specific drum)
     */
    // Send levels, relative to the voice's output gain (0-1)
    let reverbLevel = 0;
    let chorusLevel = 0;
    let variationLevel = 0;
    if (
        systemParameters.effectsEnabled &&
        !(this._midiParameters.efxAssign && core.gsInsertionActive) &&
        !this.xgInsertionAssigned
    ) {
        const reverbSend =
            modulated[GeneratorTypes.reverbEffectsSend] * voice.reverbGain;
        const chorusSend =
            modulated[GeneratorTypes.chorusEffectsSend] * voice.chorusGain;
        if (reverbSend > 0)
            reverbLevel = systemParameters.reverbGain * (reverbSend / 1000);
        if (chorusSend > 0)
            chorusLevel = systemParameters.chorusGain * (chorusSend / 1000);

        // XG variation send is system-only, in insertion mode CC94 does nothing.
        // GS delay is only sent to when it's active.
        const isXG = core.midiParameters.system === "xg";
        if (isXG ? !core.xgVariationBlock.insertionMode : core.gsDelayActive) {
            const variationSend =
                this._midiControllers[MIDIControllers.variationDepth] *
                voice.variationGain;
            if (variationSend > 0)
                variationLevel =
                    ((variationSend >> 7) / 127) *
                    (isXG
                        ? systemParameters.xgVariationGain
                        : systemParameters.gsDelayGain);
        }
    }

    /*
     * Voices sharing the pan and the send levels are summed into one mono buffer,
     * which is mixed into the channel output
     * and the effect sends once per block.
     * This way, each voice only performs a single mixing loop, which is faster.
     * Then output gain is applied together with the volume envelope.
     */

    // Find a free voice send buffer
    let voiceSendBuffer: VoiceSendBuffer | undefined = undefined;
    const sendBuffers = this.voiceSendBuffers;
    const count = this.voiceSendBufferCount;
    for (let i = 0; i < count; i++) {
        const sendBuffer = sendBuffers[i];
        if (
            sendBuffer.panIndex === panIndex &&
            sendBuffer.reverb === reverbLevel &&
            sendBuffer.chorus === chorusLevel &&
            sendBuffer.variation === variationLevel
        ) {
            // Found a match
            voiceSendBuffer = sendBuffer;
            break;
        }
    }
    if (!voiceSendBuffer) {
        if (count < sendBuffers.length) {
            // Use the free one
            voiceSendBuffer = sendBuffers[count];
            this.voiceSendBufferCount++;
        } else if (count < MAX_VOICE_SEND_BUFFERS) {
            // Create a new one
            voiceSendBuffer = new VoiceSendBuffer(this.synthCore.maxBufferSize);
            sendBuffers.push(voiceSendBuffer);
            this.voiceSendBufferCount++;
        } else {
            // Nothing found, use synth's temporary buffer
            voiceSendBuffer = this.synthCore.sharedVoiceSendBuffer;
        }
        voiceSendBuffer.panIndex = panIndex;
        voiceSendBuffer.reverb = reverbLevel;
        voiceSendBuffer.chorus = chorusLevel;
        voiceSendBuffer.variation = variationLevel;
    }

    const out = voiceSendBuffer.buffer;
    gain *= outputGain;
    // Calculate increase
    const gainInc = (voice.volEnv.outputGain * outputGain - gain) / sampleCount;

    // Low pass filter and gain (inlined for performance, confirmed with Node.js)
    {
        const f = voice.filter;
        const initialFc = modulated[GeneratorTypes.initialFilterFc];

        if (f.initialized) {
            /* Note:
             * We only smooth out the initialFc part,
             * the modulation envelope and LFO excursions are not smoothed.
             */
            const step = f.smoothingStep;
            f.currentInitialFc += Math.max(
                -step,
                Math.min(step, initialFc - f.currentInitialFc)
            );
        } else {
            // Filter initialization, set the current fc to target
            f.initialized = true;
            f.currentInitialFc = initialFc;
        }

        // The final cutoff for this calculation
        let targetCutoff = f.currentInitialFc + lowpassExcursion;
        // Cutoff ceiling (SFE), 13500 means no ceiling
        const maxCutoff = modulated[GeneratorTypes.maxFilterFc];
        if (maxCutoff < 13_500 && targetCutoff > maxCutoff)
            targetCutoff = maxCutoff;
        const modulatedResonance = modulated[GeneratorTypes.initialFilterQ];
        /* Note:
         * the check for initialFC is because of the filter optimization
         * (if cents are the maximum then the filter is open)
         * filter cannot use this optimization if it's dynamic (see #53), and
         * the filter can only be dynamic if the initial filter is not open
         */
        if (
            f.currentInitialFc > 13_499 &&
            targetCutoff > 13_499 &&
            modulatedResonance === 0
        ) {
            f.currentInitialFc = 13_500;
            // Filter is open, apply gain
            for (let i = 0; i < sampleCount; i++) {
                out[i] += buffer[i] * gain;
                gain += gainInc;
            }
        } else {
            // Check if the frequency has changed. if so, calculate new coefficients
            if (
                Math.abs(f.lastTargetCutoff - targetCutoff) > 1 ||
                f.resonanceCb !== modulatedResonance
            ) {
                f.lastTargetCutoff = targetCutoff;
                f.resonanceCb = modulatedResonance;
                f.calculateCoefficients(targetCutoff);
            }

            // Filter the input
            // Initial filtering code was ported from meltysynth created by sinshu.
            const { a0, a1, a2, a3, a4 } = f;
            let { x1, x2, y1, y2 } = f;
            /*
             * Two samples per iteration, the second one directly from y1:
             * f0 = p0 - a3 * y1, where p0 = a0 * in0 + a1 * x1 + a2 * x2 - a4 * y2
             * f1 = q1 - a3 * f0 - a4 * y1 = q1 - a3 * p0 + (a3 * a3 - a4) * y1
             */
            const b3 = a3 * a3 - a4;
            let i = 0;
            for (; i + 1 < sampleCount; i += 2) {
                const in0 = buffer[i];
                const in1 = buffer[i + 1];
                const p0 = a0 * in0 + a1 * x1 + a2 * x2 - a4 * y2;
                const q1 = a0 * in1 + a1 * in0 + a2 * x1;
                const f0 = p0 - a3 * y1;
                const f1 = q1 - a3 * p0 + b3 * y1;
                x2 = in0;
                x1 = in1;
                y2 = f0;
                y1 = f1;

                // Apply filter and THEN gain
                // Per SF2 spec apply order, also see
                // https://github.com/FluidSynth/fluidsynth/issues/1427
                out[i] += f0 * gain;
                gain += gainInc;
                out[i + 1] += f1 * gain;
                gain += gainInc;
            }
            // Odd sample count, process the last sample
            if (i < sampleCount) {
                const input = buffer[i];
                const filtered =
                    a0 * input + a1 * x1 + a2 * x2 - a4 * y2 - a3 * y1;
                x2 = x1;
                x1 = input;
                y2 = y1;
                y1 = filtered;
                out[i] += filtered * gain;
            }
            f.x1 = x1;
            f.x2 = x2;
            f.y1 = y1;
            f.y2 = y2;
        }
    }

    // No buffer available.
    if (voiceSendBuffer === core.sharedVoiceSendBuffer)
        mixVoiceSendBuffer(this, voiceSendBuffer, sampleCount);
}

/**
 * A mono sum of the voices of a channel that share the pan and the effect send levels.
 * This allows to group voices and have them mixed only once, where the group is then mixed with sends, which is faster.
 * @internal
 */
export class VoiceSendBuffer {
    /**
     * The summed voice audio, with the output gain applied.
     */
    public readonly buffer: Float64Array;
    /**
     * The pan table index.
     */
    public panIndex = 0;
    /**
     * The reverb send level. (0-1)
     */
    public reverb = 0;
    /**
     * The chorus send level. (0-1)
     */
    public chorus = 0;
    /**
     * The GS delay or XG variation send level. (0-1)
     */
    public variation = 0;

    public constructor(bufferSize: number) {
        this.buffer = new Float64Array(bufferSize);
    }
}

/**
 * Mixes a voice send buffer into the channel output and the effect sends, then clears it.
 * @param channel The channel that owns the buffer.
 * @param buffer The voice send buffer to mix.
 * @param sampleCount The number of samples to mix.
 */
export function mixVoiceSendBuffer(
    channel: MIDIChannel,
    buffer: VoiceSendBuffer,
    sampleCount: number
) {
    const core = channel.synthCore;
    const input = buffer.buffer;
    const panLeft = panTableLeft[buffer.panIndex];
    const panRight = panTableRight[buffer.panIndex];
    const { outputLeft, outputRight } = channel;
    for (let i = 0; i < sampleCount; i++) {
        const s = input[i];
        outputLeft[i] += panLeft * s;
        outputRight[i] += panRight * s;
    }

    const { reverb, chorus, variation } = buffer;
    if (core.midiParameters.system === "xg") {
        // XG effects have stereo inputs
        if (reverb > 0)
            sendToStereo(
                input,
                core.xgReverbSendL,
                core.xgReverbSendR,
                reverb * panLeft,
                reverb * panRight,
                sampleCount
            );
        if (chorus > 0)
            sendToStereo(
                input,
                core.xgChorusSendL,
                core.xgChorusSendR,
                chorus * panLeft,
                chorus * panRight,
                sampleCount
            );
        if (variation > 0)
            sendToStereo(
                input,
                core.xgVariationSendL,
                core.xgVariationSendR,
                variation * panLeft,
                variation * panRight,
                sampleCount
            );
    } else {
        // GS effects are mono
        if (reverb > 0)
            sendToMono(input, core.gsReverbSend, reverb, sampleCount);
        if (chorus > 0)
            sendToMono(input, core.gsChorusSend, chorus, sampleCount);
        if (variation > 0)
            sendToMono(input, core.gsDelaySend, variation, sampleCount);
    }
    input.fill(0, 0, sampleCount);
}

/**
 * Adds the voice audio to a mono effect send.
 * @param input The voice audio.
 * @param output The send to add to.
 * @param gain The send gain.
 * @param sampleCount The number of samples.
 */
function sendToMono(
    input: Float64Array,
    output: Float64Array,
    gain: number,
    sampleCount: number
) {
    for (let i = 0; i < sampleCount; i++) {
        output[i] += gain * input[i];
    }
}

/**
 * Adds the voice audio to a stereo effect send.
 * @param input The voice audio.
 * @param outputLeft The left send to add to.
 * @param outputRight The right send to add to.
 * @param gainLeft The left send gain.
 * @param gainRight The right send gain.
 * @param sampleCount The number of samples.
 */
function sendToStereo(
    input: Float64Array,
    outputLeft: Float64Array,
    outputRight: Float64Array,
    gainLeft: number,
    gainRight: number,
    sampleCount: number
) {
    for (let i = 0; i < sampleCount; i++) {
        const s = input[i];
        outputLeft[i] += s * gainLeft;
        outputRight[i] += s * gainRight;
    }
}
