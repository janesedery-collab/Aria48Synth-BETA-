import { GSInsertionControlSources } from "./enums";
import {
    type MIDIController,
    MIDIControllers,
    type MIDIMessageType,
    MIDIMessageTypes
} from "../midi/enums";
import type { BasicPreset } from "../soundbank/basic_soundbank/basic_preset";
import {
    type MIDIPatch,
    MIDIPatchTools
} from "../soundbank/basic_soundbank/midi_patch";
import { IndexedByteArray } from "../utils/indexed_array";
import { SpessaLog } from "../utils/loggin";
import { ConsoleColors } from "../utils/other";
import type {
    GSChorusProcessor,
    GSDelayProcessor,
    SynthesizerEvent,
    SynthesizerEventCallback,
    SynthesizerPatch,
    SynthMethodOptions,
    SynthProcessorOptions
} from "./types";
import { MIDIChannel } from "./audio_engine/channel/midi_channel";
import {
    mixVoiceSendBuffer,
    VoiceSendBuffer
} from "./audio_engine/channel/render_voice";
import {
    DEFAULT_GLOBAL_SYSTEM_PARAMETERS,
    type GlobalSystemParameter,
    setSystemParameterInternal
} from "./audio_engine/parameters/system";
import { SoundBankManager } from "./audio_engine/sound_bank_manager";
import {
    DEFAULT_SYNTH_METHOD_OPTIONS,
    DEFAULT_SYNTH_MODE,
    EMBEDDED_SOUND_BANK_ID
} from "./audio_engine/synth_constants";
import { Voice } from "./audio_engine/voice/voice";
import { CachedVoice } from "./audio_engine/voice/voice_cache";

import { MIDIMessage } from "../midi/midi_message";
import type { SysExAcceptedArray, UserDrumSetParameter } from "../midi/types";
import type { MIDISystem } from "../soundbank/types";
import { DefaultGSChorus } from "./audio_engine/effects/gs/implementation/chorus";
import { DefaultGSDelay } from "./audio_engine/effects/gs/implementation/delay";
import { DefaultGSEqualizer } from "./audio_engine/effects/gs/implementation/equalizer";
import { DefaultGSInsertion } from "./audio_engine/effects/gs/implementation/insertion";
import { DefaultGSReverb } from "./audio_engine/effects/gs/implementation/reverb";
import {
    DEFAULT_GLOBAL_MIDI_PARAMETERS,
    type GlobalMIDIParameter,
    lockMIDIParameterInternal,
    setMIDIParameterInternal
} from "./audio_engine/parameters/midi";
import type { UserDrumSetChangeEvent } from "./events";
import { universalSystemExclusive } from "./audio_engine/system_exclusive/universal";
import { rolandSystemExclusive } from "./audio_engine/system_exclusive/roland";
import { yamahaSystemExclusive } from "./audio_engine/system_exclusive/yamaha";
import { BasicSoundBank } from "../soundbank/basic_soundbank/basic_soundbank";
import { fillWithDefaults } from "../utils/fill_with_defaults";
import { DEFAULT_SYNTH_OPTIONS } from "./audio_engine/synth_processor_options";
import { SoundBankLoader } from "../soundbank/sound_bank_loader";
import {
    applySnapshot,
    getSynthesizerSnapshot,
    type SynthesizerSnapshot
} from "./audio_engine/synthesizer_snapshot";
import type {
    GSChorusParameter,
    GSDelayParameter,
    GSEqualizerParameter,
    GSEqualizerProcessor,
    GSInsertionBlock,
    GSReverbParameter,
    GSReverbProcessor
} from "./audio_engine/effects/gs/types";
import type { XGVariationBlock } from "./audio_engine/effects/xg/interface/xg_variation_block";
import type { XGReverbBlock } from "./audio_engine/effects/xg/interface/xg_reverb_block";
import type { XGChorusBlock } from "./audio_engine/effects/xg/interface/xg_chorus_block";
import type { XGInsertionBlock } from "./audio_engine/effects/xg/interface/xg_insertion_block";
import { DefaultXGReverb } from "./audio_engine/effects/xg/implementation/reverb";
import { DefaultXGChorus } from "./audio_engine/effects/xg/implementation/chorus";
import { DefaultXGVariation } from "./audio_engine/effects/xg/implementation/variation";
import { DefaultXGInsertion } from "./audio_engine/effects/xg/implementation/insertion";
import { DecodedSampleCache } from "./audio_engine/decoded_sample_cache";

/**
 * Gain smoothing for rapid volume changes. Must be run EVERY SAMPLE
 */
const GAIN_SMOOTHING_FACTOR = 0.01;

/**
 * Pan smoothing for rapid pan changes
 */
const PAN_SMOOTHING_FACTOR = 0.05;
/**
 * A list of voices for a given key:velocity.
 */
type CachedVoiceList = CachedVoice[];

/**
 * MU2000 has 4 insertion effects. We can do more but leave it at 4 for now
 */
const XG_INSERTION_COUNT = 4;

/**
 * The GS reverb parameters set by the reverb macro.
 */
const GS_REVERB_MACRO_PARAMETERS: (keyof GSReverbParameter)[] = [
    "character",
    "preLowpass",
    "level",
    "time",
    "delayFeedback",
    "preDelayTime"
];

/**
 * The GS chorus parameters set by the chorus macro.
 */
const GS_CHORUS_MACRO_PARAMETERS: (keyof GSChorusParameter)[] = [
    "preLowpass",
    "level",
    "feedback",
    "delay",
    "rate",
    "depth",
    "sendLevelToReverb",
    "sendLevelToDelay"
];

/**
 * The default GS equalizer parameters (SC-8850 manual p.236).
 */
const DEFAULT_GS_EQUALIZER: GSEqualizerParameter = {
    lowFrequency: 0,
    lowGain: 0x40,
    highFrequency: 0,
    highGain: 0x40
};

const GS_EQUALIZER_PARAMETERS = Object.keys(
    DEFAULT_GS_EQUALIZER
) as (keyof GSEqualizerParameter)[];

/**
 * The GS delay parameters set by the delay macro.
 */
const GS_DELAY_MACRO_PARAMETERS: (keyof GSDelayParameter)[] = [
    "preLowpass",
    "timeCenter",
    "timeRatioLeft",
    "timeRatioRight",
    "levelCenter",
    "levelLeft",
    "levelRight",
    "level",
    "feedback",
    "sendLevelToReverb"
];

/**
 * Moves the voice sends into an effect input buffer, clearing the sends for the next quantum.
 * @param sends The double precision voice sends.
 * @param input The effect input buffer, overwritten.
 * @param sampleCount The number of samples to move.
 */
function moveSends(
    sends: Float64Array,
    input: Float32Array,
    sampleCount: number
) {
    for (let i = 0; i < sampleCount; i++) {
        input[i] = sends[i];
        sends[i] = 0;
    }
}

/**
 * The core synthesis engine of SpessaSynth.
 * This module converts sound bank and MIDI data into PCM audio data.
 * The internal synthesis system is modeled after SoundFont2 synthesis model,
 * with additional extensions and functionality.
 *
 * [MIDI implementation of the synthesizer can be found here.](../../docs/extra/midi-implementation.md)
 *
 * ### Effect processors reference
 *
 * #### GS
 *
 * These are active when {@link GlobalMIDIParameter.system} is set to `gm`, `gm2`, or `gs`.
 *
 * - {@link GSReverbProcessor} - How to implement your own GS reverb processor.
 * - {@link GSChorusProcessor} - How to implement your own GS chorus processor.
 * - {@link GSDelayProcessor} - How to implement your own GS delay processor.
 * - {@link GSInsertionBlock} - How to implement your own GS insertion processor.
 *
 * #### XG
 *
 * These are active when {@link GlobalMIDIParameter.system} is set to `xg`.
 *
 * - {@link XGReverbBlock} - How to implement your own XG reverb processor.
 * - {@link XGChorusBlock} - How to implement your own XG chorus processor.
 * - {@link XGVariationBlock} - How to implement your own XG variation processor.
 * - {@link XGInsertionBlock} - How to implement your own XG insertion processor.
 *
 * ### Managers
 *
 * - {@link SoundBankManager} - Manages the sound banks within the processor.
 *
 * @group Synthesizer
 */
export class SpessaSynthProcessor {
    /**
     * A `Promise` that must be awaited before
     * the processor can be used with a compressed sound bank.
     *
     */
    public readonly ready = BasicSoundBank.ready;
    /**
     * Voices of this synthesizer, as a fixed voice pool.
     * @internal
     */
    public readonly voices: Voice[] = [];
    /**
     * All MIDI channels of the synthesizer.
     */
    public readonly midiChannels: MIDIChannel[] = [];
    /**
     * The maximum allowed buffer size to render.
     * @internal
     */
    public readonly maxBufferSize: number;
    /**
     * The buffer to use when rendering a voice.
     * @internal
     */
    public readonly voiceBuffer;
    /**
     * The voice buffer used when a channel has no free voice send buffers.
     * @internal
     */
    public readonly sharedVoiceSendBuffer;
    /**
     * The GS insertion processor's left input buffer.
     * @internal
     */
    public readonly insertionInputL;
    /**
     * The GS insertion processor's right input buffer.
     * @internal
     */
    public readonly insertionInputR;
    /**
     * The GS equalizer's left input buffer.
     * @internal
     */
    public readonly equalizerInputL;
    /**
     * The GS equalizer's right input buffer.
     * @internal
     */
    public readonly equalizerInputR;
    /**
     * The GS reverb processor's input buffer.
     * @internal
     */
    public readonly gsReverbInput;
    /**
     * The GS chorus processor's input buffer.
     * @internal
     */
    public readonly gsChorusInput;
    /**
     * The GS delay processor's input buffer.
     * @internal
     */
    public readonly gsDelayInput;
    /**
     * The XG reverb block's left input buffer.
     * XG effects are stereo, unlike GS effects (except insertion).
     * @internal
     */
    public readonly xgReverbInputL;
    /**
     * The XG reverb block's right input buffer.
     * @internal
     */
    public readonly xgReverbInputR;
    /**
     * The XG chorus block's left input buffer.
     * @internal
     */
    public readonly xgChorusInputL;
    /**
     * The XG chorus block's right input buffer.
     * @internal
     */
    public readonly xgChorusInputR;
    /**
     * The XG variation block's left input buffer (system mode).
     * @internal
     */
    public readonly xgVariationInputL;
    /**
     * The XG variation block's right input buffer (system mode).
     * @internal
     */
    public readonly xgVariationInputR;
    /**
     * Voice sends for {@link gsReverbInput}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly gsReverbSend;
    /**
     * Voice sends for {@link gsChorusInput}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly gsChorusSend;
    /**
     * Voice sends for {@link gsDelayInput}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly gsDelaySend;
    /**
     * Voice sends for {@link xgReverbInputL}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly xgReverbSendL;
    /**
     * Voice sends for {@link xgReverbInputR}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly xgReverbSendR;
    /**
     * Voice sends for {@link xgChorusInputL}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly xgChorusSendL;
    /**
     * Voice sends for {@link xgChorusInputR}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly xgChorusSendR;
    /**
     * Voice sends for {@link xgVariationInputL}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly xgVariationSendL;
    /**
     * Voice sends for {@link xgVariationInputR}.
     *
     * F64 instead of f32 here, as that is faster in JS than float32 for the voice path.
     * This is moved into f32 effect input buffers once per quantum.
     * @internal
     */
    public readonly xgVariationSendR;
    /**
     * Delay is not used outside SC-88+ MIDIs, this is an optimization.
     * @internal
     */
    public gsDelayActive = false;
    /**
     * The sample rate, in Hertz.
     */
    public readonly sampleRate;
    /**
     * This.tunings[program * 128 + key] = midiNote,cents (fraction)
     * All MIDI Tuning Standard tunings, 128 keys for each of 128 programs.
     * -1 means no change.
     * @internal
     */
    public readonly tunings = new Float32Array(128 * 128).fill(-1);
    /**
     * An object indicating if a Global MIDI parameter, at the equivalent key, is locked
     * (i.e., not allowed changing).
     * A locked parameter cannot be modified.
     * @internal
     */
    public readonly lockedMIDIParameters = Object.fromEntries(
        // This funky code takes DEFAULT_PARAMETERS and sets the values to false
        (
            Object.keys(
                DEFAULT_GLOBAL_MIDI_PARAMETERS
            ) as (keyof GlobalMIDIParameter)[]
        ).map((key) => [key, false])
    ) as Record<keyof GlobalMIDIParameter, boolean>;
    /**
     * The global MIDI parameters of the synthesizer.
     * These are only editable via MIDI messages.
     */
    public readonly midiParameters: Readonly<GlobalMIDIParameter> = {
        ...DEFAULT_GLOBAL_MIDI_PARAMETERS
    }; // Copy, not set!
    /**
     * The global system parameters of the synthesizer.
     * These are only editable via the API.
     *
     * Use {@link SpessaSynthProcessor.setSystemParameter} to set them.
     */
    public readonly systemParameters: Readonly<GlobalSystemParameter> = {
        ...DEFAULT_GLOBAL_SYSTEM_PARAMETERS
    }; // Copy, not set!
    /**
     * The current time of the synthesizer, in seconds.
     */
    public readonly currentTime;
    /**
     * Synth's default (reset) preset.
     * @internal
     */
    public defaultPreset: SynthesizerPatch | undefined;
    /**
     * Synth's default (reset) drum preset.
     * @internal
     */
    public drumPreset: SynthesizerPatch | undefined;
    /**
     * Gain smoothing factor, adjusted to the sample rate.
     * @internal
     */
    public readonly gainSmoothingFactor: number;
    /**
     * Pan smoothing factor, adjusted to the sample rate.
     * @internal
     */
    public readonly panSmoothingFactor: number;
    /**
     * This property can be defined as a function that listens for events.
     * All events are defined in {@link SynthesizerEvent}.
     * It is not called while the `eventsEnabled` system parameter is false.
     *
     * @param event The event that occurred.
     */
    public onEventCall?: (event: SynthesizerEventCallback) => unknown;
    /**
     * Cached voices for all presets for this synthesizer.
     * Nesting is calculated in getCachedVoiceIndex, returns a list of voices for this note.
     * @internal
     */
    public readonly cachedVoices = new Map<number, CachedVoiceList>();
    /**
     * Insertion is not used outside SC-88Pro+ MIDIs, this is an optimization.
     * @internal
     */
    public gsInsertionActive = false;
    /**
     * The synthesizer's XG variation block.
     *
     * Variation is public so voice render can check if sends should be routed to it.
     *
     * Used when {@link GlobalMIDIParameter.system} is `xg`.
     * @internal
     */
    public readonly xgVariationBlock: XGVariationBlock;
    /**
     * The synthesizer's GS insertion block.
     *
     * Used when {@link GlobalMIDIParameter.system} is `gm` `gm2` or `gs`.
     * Public so the channels can pass the EFX control sources to it.
     * @internal
     */
    public readonly gsInsertionBlock: GSInsertionBlock;
    /**
     * Keeps the decoded sample data under the budget from the options.
     * @internal
     */
    protected readonly decodedSamples: DecodedSampleCache;
    /**
     * The sound bank manager, which manages all sound banks and presets.
     */
    public readonly soundBankManager: SoundBankManager = new SoundBankManager(
        this.updatePresetList.bind(this),
        (bank) => {
            // Created later in the constructor, a bank can not be removed before that
            this.decodedSamples.forget(bank.samples);
        }
    );
    /**
     * The synthesizer's GS reverb processor.
     *
     * Used when {@link GlobalMIDIParameter.system} is `gm` `gm2` or `gs`.
     * @internal
     */
    protected readonly gsReverbProcessor: GSReverbProcessor;
    /**
     * The synthesizer's GS chorus processor.
     *
     * Used when {@link GlobalMIDIParameter.system} is `gm` `gm2` or `gs`.
     * @internal
     */
    protected readonly gsChorusProcessor: GSChorusProcessor;
    /**
     * The synthesizer's GS delay processor.
     *
     * Used when {@link GlobalMIDIParameter.system} is `gm` `gm2` or `gs`.
     * @internal
     */
    protected readonly gsDelayProcessor: GSDelayProcessor;
    /**
     * The synthesizer's GS equalizer processor.
     *
     * Used when {@link GlobalMIDIParameter.system} is `gm` `gm2` or `gs`.
     * @internal
     */
    protected readonly gsEqualizerProcessor: GSEqualizerProcessor;
    /**
     * The synthesizer's XG reverb block.
     *
     * Used when {@link GlobalMIDIParameter.system} is `xg`.
     * @internal
     */
    protected readonly xgReverbBlock: XGReverbBlock;
    /**
     * The synthesizer's XG chorus block.
     *
     * Used when {@link GlobalMIDIParameter.system} is `xg`.
     * @internal
     */
    protected readonly xgChorusBlock: XGChorusBlock;
    /**
     * XG insertion effect blocks.
     *
     * Used when {@link GlobalMIDIParameter.system} is `xg`.
     * @internal
     */
    protected readonly xgInsertionBlocks: XGInsertionBlock[];

    /**
     * A sysEx may set a "Part" (channel) to receive on a different channel number.
     * This slows down the access, so this toggle tracks if it's enabled or not.
     * @internal
     */
    protected customChannelNumbers = false;
    /**
     * For F5 system exclusive.
     * @internal
     */
    protected portSelectChannelOffset = 0;
    /**
     * Left float32 buffer for processing XG insertion effects in-place.
     * (channel outputs are double precision)
     */
    private readonly xgInsertionBufferL;
    /**
     * Right float32 buffer for processing XG insertion effects in-place.
     */
    private readonly xgInsertionBufferR;
    /**
     * Last time the priorities were assigned.
     * Used to prevent assigning priorities multiple times when more than one voice is triggered during a quantum.
     * @internal
     */
    private lastPriorityAssignmentTime = 0;
    /**
     * Synth's event queue from the main thread
     */
    private eventQueue: {
        message: SysExAcceptedArray;
        channelOffset: number;
        time: number;
    }[] = [];
    /**
     * The time of a single sample, in seconds.
     */
    private readonly sampleTime: number;
    /**
     * For applying the snapshot after an override sound bank too.
     */
    private savedSnapshot?: SynthesizerSnapshot;

    /**
     * Initializes a new MIDI Synthesizer engine.
     * @param sampleRate The sample rate of the synthesizer, in Hertz.
     * @param opts Additional options when initializing the synthesizer.
     */
    public constructor(
        sampleRate: number,
        opts: Partial<SynthProcessorOptions> = {}
    ) {
        const options = fillWithDefaults(opts, DEFAULT_SYNTH_OPTIONS);
        if (
            !Number.isFinite(options.initialTime) ||
            !Number.isFinite(sampleRate)
        ) {
            throw new TypeError(
                `Initial time or sample rate is invalid! initial time: ${options.initialTime}, sample rate: ${sampleRate}`
            );
        }
        this.sampleRate = sampleRate;
        this.sampleTime = 1 / sampleRate;
        this.currentTime = options.initialTime;
        // Replace the stubs with bound functions for less overhead
        this.lockMIDIParameter = lockMIDIParameterInternal.bind(this);
        this.setSystemParameter = setSystemParameterInternal.bind(this);
        this.setMIDIParameter = setMIDIParameterInternal.bind(this);

        this.setSystemParameter("effectsEnabled", options.effectsEnabled);
        this.setSystemParameter("eventsEnabled", options.eventsEnabled);
        this.maxBufferSize = options.maxBufferSize;
        this.decodedSamples = new DecodedSampleCache(
            options.decodedSampleBudget,
            this.cachedVoices
        );

        // For GS user drum set
        this.soundBankManager.systemGetter = () => this.midiParameters.system;
        // These smoothing factors were tested on 44,100 Hz, adjust them to target sample rate here
        // Volume  smoothing factor
        this.gainSmoothingFactor =
            GAIN_SMOOTHING_FACTOR * (44_100 / sampleRate);
        // Pan smoothing factor
        this.panSmoothingFactor = PAN_SMOOTHING_FACTOR * (44_100 / sampleRate);

        const bufSize = this.maxBufferSize;
        // Initialize effects
        this.gsReverbProcessor =
            options.gsReverbProcessor ??
            new DefaultGSReverb(sampleRate, bufSize);
        this.gsChorusProcessor =
            options.gsChorusProcessor ??
            new DefaultGSChorus(sampleRate, bufSize);
        this.gsDelayProcessor =
            options.gsDelayProcessor ?? new DefaultGSDelay(sampleRate, bufSize);
        this.gsEqualizerProcessor =
            options.gsEqualizerProcessor ?? new DefaultGSEqualizer(sampleRate);
        this.gsInsertionBlock =
            options.gsInsertionBlock ??
            new DefaultGSInsertion(sampleRate, bufSize);

        this.xgReverbBlock =
            options.xgReverbBlock ?? new DefaultXGReverb(sampleRate, bufSize);
        this.xgChorusBlock =
            options.xgChorusBlock ?? new DefaultXGChorus(sampleRate, bufSize);
        this.xgVariationBlock =
            options.xgVariationBlock ??
            new DefaultXGVariation(sampleRate, bufSize);
        this.xgInsertionBlocks =
            options.xgInsertionBlocks ??
            Array.from(
                { length: XG_INSERTION_COUNT },
                () => new DefaultXGInsertion(sampleRate, bufSize)
            );

        // Initialize buffers
        this.voiceBuffer = new Float64Array(bufSize);
        this.sharedVoiceSendBuffer = new VoiceSendBuffer(bufSize);
        this.insertionInputL = new Float32Array(bufSize);
        this.insertionInputR = new Float32Array(bufSize);
        this.equalizerInputL = new Float32Array(bufSize);
        this.equalizerInputR = new Float32Array(bufSize);
        this.gsReverbInput = new Float32Array(bufSize);
        this.gsChorusInput = new Float32Array(bufSize);
        this.gsDelayInput = new Float32Array(bufSize);
        this.xgReverbInputL = new Float32Array(bufSize);
        this.xgReverbInputR = new Float32Array(bufSize);
        this.xgChorusInputL = new Float32Array(bufSize);
        this.xgChorusInputR = new Float32Array(bufSize);
        this.xgVariationInputL = new Float32Array(bufSize);
        this.xgVariationInputR = new Float32Array(bufSize);
        this.gsReverbSend = new Float64Array(bufSize);
        this.gsChorusSend = new Float64Array(bufSize);
        this.gsDelaySend = new Float64Array(bufSize);
        this.xgReverbSendL = new Float64Array(bufSize);
        this.xgReverbSendR = new Float64Array(bufSize);
        this.xgChorusSendL = new Float64Array(bufSize);
        this.xgChorusSendR = new Float64Array(bufSize);
        this.xgVariationSendL = new Float64Array(bufSize);
        this.xgVariationSendR = new Float64Array(bufSize);
        this.xgInsertionBufferL = new Float32Array(bufSize);
        this.xgInsertionBufferR = new Float32Array(bufSize);

        // Initialize voices
        this.allocateNewVoices(this.systemParameters.voiceCap);

        for (let i = 0; i < 16; i++) {
            // Don't send events as we're creating the initial channels
            this.createMIDIChannelInternal(false);
        }
        void this.ready.then(() => {
            SpessaLog.info("%cSpessaSynth is ready!", ConsoleColors.recognized);
        });
    }

    /**
     * Current total amount of voices that are playing.
     */
    private _voiceCount = 0;

    /**
     * Current total amount of voices that are playing.
     */
    public get voiceCount(): number {
        return this._voiceCount;
    }

    /**
     * The decoded sample data kept under {@link SynthProcessorOptions.decodedSampleBudget}, in bytes.
     * It is only counted when a budget is set.
     */
    public get decodedSampleBytes() {
        return this.decodedSamples.totalBytes;
    }

    /**
     * Locks or unlocks a given {@link GlobalMIDIParameter}.
     * This prevents any changes to it until it's unlocked.
     * @param parameter The Global MIDI Parameter to lock.
     * @param isLocked If the parameter should be locked.
     */
    public lockMIDIParameter<P extends keyof GlobalMIDIParameter>(
        parameter: P,
        isLocked: boolean
    ) {
        // Patched with the actual function in the constructor.
        void parameter;
        void isLocked;
    }

    /**
     * Sets a {@link GlobalSystemParameter} of the synthesizer.
     * @param parameter The type of the system parameter to set.
     * @param value The value to set for the system parameter.
     */
    public setSystemParameter<P extends keyof GlobalSystemParameter>(
        parameter: P,
        value: GlobalSystemParameter[P]
    ) {
        // Patched with the actual function in the constructor.
        void parameter;
        void value;
    }

    /**
     * A handler for missing presets during program change.
     * By default, it warns to console, unless no sound bank has been added yet.
     * It may be useful for allowing the synthesizer to work without any sound banks.
     * @param patch The MIDI patch that was requested.
     * @param system The MIDI System for the request.
     * @returns If a {@link BasicPreset} instance is returned, it will be used by the channel as a fallback.
     */
    public onMissingPreset = (
        patch: MIDIPatch,
        system: MIDISystem
    ): BasicPreset | undefined => {
        // Nothing to warn about before any sound bank is added.
        // The channels look up their presets again once one is
        if (this.soundBankManager.soundBankList.length === 0) return undefined;
        SpessaLog.warn(
            `No preset found for ${MIDIPatchTools.toMIDIString(patch)}! Did you forget to add a sound bank?`
        );
        // Make tsc happy!
        void system;
        return undefined;
    };

    /**
     * Executes a system exclusive message for the synthesizer.
     *
     * > **Tip**
     * >
     * > Refer to the [MIDI Implementation](../../docs/extra/midi-implementation.md)
     * > for the list of supported System Exclusives.
     *
     * @param syx The system exclusive message as an array of bytes, without the starting `F0` byte.
     * @param channelOffset The channel offset for the message as they usually can only address the first 16 channels.
     * For example, to send a system exclusive on channel 16,
     * send a system exclusive for channel 0 and set an offset of 16.
     */
    public systemExclusive(
        this: SpessaSynthProcessor,
        syx: SysExAcceptedArray,
        channelOffset = 0
    ) {
        channelOffset += this.portSelectChannelOffset;
        const manufacturer = syx[0];
        // Ensure that the device ID matches (F5 has the port number there instead)
        if (
            manufacturer !== 0xf5 &&
            // The device ID can be set to "all" which it is by default
            this.systemParameters.deviceID !== -1 &&
            syx[1] !== 0x7f && // 0x7f means broadcast, i.e. all MIDI devices
            this.systemParameters.deviceID !== syx[1]
        ) {
            // Not our device ID
            return;
        }

        switch (manufacturer) {
            default: {
                SpessaLog.unsupported(
                    "System Exclusive",
                    syx,
                    `Unknown manufacturer: ${manufacturer}`
                );
                break;
            }

            // Non realtime GM
            case 0x7e:
            // Realtime GM
            case 0x7f: {
                universalSystemExclusive.call(this, syx, channelOffset);
                break;
            }

            // Roland
            case 0x41: {
                rolandSystemExclusive.call(this, syx, channelOffset);
                break;
            }

            // Yamaha
            case 0x43: {
                yamahaSystemExclusive.call(this, syx, channelOffset);
                break;
            }

            // Port select (Falcosoft MIDI Player)
            // https://www.vogons.org/viewtopic.php?p=1404746#p1404746
            case 0xf5: {
                if (syx.length < 2) return;
                // Ports are 1-based, treat 0 as the first port
                this.portSelectChannelOffset = Math.max(0, syx[1] - 1) * 16;
                // Create new port if needed
                while (
                    this.midiChannels.length <= this.portSelectChannelOffset
                ) {
                    SpessaLog.info(
                        `%cPort select, channel offset %c${this.portSelectChannelOffset}%c. Creating a new port!`,
                        ConsoleColors.info,
                        ConsoleColors.value,
                        ConsoleColors.info
                    );
                    for (let i = 0; i < 16; i++) {
                        this.createMIDIChannel();
                    }
                }
                break;
            }
        }
    }

    /**
     * Executes a MIDI controller change message on the specified channel.
     * @param channel The MIDI channel to change the controller on.
     * It usually ranges from 0 to 15, but it depends on the channel count.
     * @param controller The MIDI controller number (0-127).
     * Refer to the [MIDI Implementation](../../docs/extra/midi-implementation.md) for the list of controllers
     * supported by default.
     * @param value The value of the controller (0-127).
     */
    public controllerChange(
        channel: number,
        controller: MIDIController,
        value: number
    ) {
        if (this.customChannelNumbers) {
            for (const ch of this.midiChannels)
                if (ch.midiParameters.rxChannel === channel) {
                    ch.controllerChange(controller, value);
                    ch.efxControl(controller, value);
                }
            return;
        }
        const ch = this.midiChannels[channel + this.portSelectChannelOffset];
        ch.controllerChange(controller, value);
        ch.efxControl(controller, value);
    }

    /**
     * Executes a MIDI Note On message on the specified channel.
     * Starts playing a note.
     * @param channel The MIDI channel to send the note on.
     * It usually ranges from 0 to 15, but it depends on the channel count.
     * @param midiNote The MIDI note number to play.
     * Ranges from 0 to 127.
     * @param velocity The velocity of the note, from 0 to 127.
     * Ranges from 0 to 127, where 127 is the loudest and 1 is the quietest.
     * If the velocity is 0, it will be treated as a Note Off message.
     */
    public noteOn(channel: number, midiNote: number, velocity: number) {
        if (this.customChannelNumbers) {
            for (const ch of this.midiChannels)
                if (ch.midiParameters.rxChannel === channel)
                    ch.noteOn(midiNote, velocity);
            return;
        }
        this.midiChannels[channel + this.portSelectChannelOffset].noteOn(
            midiNote,
            velocity
        );
    }

    /**
     * Executes a MIDI Note Off message on the specified channel.
     * Stops playing a note.
     * @param channel The MIDI channel to send the note off.
     * It usually ranges from 0 to 15, but it depends on the channel count.
     * @param midiNote The MIDI note number to stop playing.
     * Ranges from 0 to 127.
     */
    public noteOff(channel: number, midiNote: number) {
        if (this.customChannelNumbers) {
            for (const ch of this.midiChannels)
                if (ch.midiParameters.rxChannel === channel)
                    ch.noteOff(midiNote);
            return;
        }
        this.midiChannels[channel + this.portSelectChannelOffset].noteOff(
            midiNote
        );
    }

    /**
     * Executes a MIDI Poly Pressure (Aftertouch) message on the specified channel.
     * This differs from the Channel Pressure in that it's per-note and not for the whole channel.
     * @param channel The MIDI channel to send the poly pressure on.
     * It usually ranges from 0 to 15, but it depends on the channel count.
     * @param midiNote The MIDI note number to apply the pressure to.
     * Ranges from 0 to 127.
     * @param pressure The pressure value, from 0 to 127.
     */
    public polyPressure(channel: number, midiNote: number, pressure: number) {
        if (this.customChannelNumbers) {
            for (const ch of this.midiChannels)
                if (ch.midiParameters.rxChannel === channel)
                    ch.polyPressure(midiNote, pressure);
            return;
        }
        this.midiChannels[channel + this.portSelectChannelOffset].polyPressure(
            midiNote,
            pressure
        );
    }

    /**
     * Executes a MIDI Channel Pressure (Aftertouch) message on the specified channel.
     * @param channel The MIDI channel to send the channel pressure on.
     * It usually ranges from 0 to 15, but it depends on the channel count.
     * @param pressure The pressure value, from 0 to 127.
     */
    public channelPressure(channel: number, pressure: number) {
        const source = GSInsertionControlSources.channelPressure;
        if (this.customChannelNumbers) {
            for (const ch of this.midiChannels)
                if (ch.midiParameters.rxChannel === channel) {
                    ch.setMIDIParameter("pressure", pressure);
                    ch.efxControl(source, pressure);
                }
            return;
        }
        const ch = this.midiChannels[channel + this.portSelectChannelOffset];
        ch.setMIDIParameter("pressure", pressure);
        ch.efxControl(source, pressure);
    }

    /**
     * Executes a MIDI Pitch Wheel message on the specified channel.
     * @param channel The MIDI channel to send the pitch wheel on.
     * It usually ranges from 0 to 15, but it depends on the channel count.
     * @param pitch The new 14-bit MIDI pitch value (0-16,383). 8,192 is center.
     * @param midiNote The MIDI note number for the per-note pitch wheel mode.
     * Leave unset or set it to -1 for the regular pitch wheel.
     */
    public pitchWheel(channel: number, pitch: number, midiNote = -1) {
        // The per-note pitch wheel is not an EFX control source
        const source =
            midiNote === -1
                ? GSInsertionControlSources.pitchBend
                : GSInsertionControlSources.off;
        if (this.customChannelNumbers) {
            for (const ch of this.midiChannels)
                if (ch.midiParameters.rxChannel === channel) {
                    ch.pitchWheel(pitch, midiNote);
                    ch.efxControl(source, pitch);
                }
            return;
        }
        const ch = this.midiChannels[channel + this.portSelectChannelOffset];
        ch.pitchWheel(pitch, midiNote);
        ch.efxControl(source, pitch);
    }

    /**
     * Executes a MIDI Program Change message on the specified channel.
     * @param channel The MIDI channel to send the program change on.
     * It usually ranges from 0 to 15, but it depends on the channel count.
     * @param programNumber The program number to change to, from 0 to 127.
     */
    public programChange(channel: number, programNumber: number) {
        if (this.customChannelNumbers) {
            for (const ch of this.midiChannels)
                if (ch.midiParameters.rxChannel === channel)
                    ch.programChange(programNumber);
            return;
        }
        this.midiChannels[channel + this.portSelectChannelOffset].programChange(
            programNumber
        );
    }

    /**
     * Assigns the first available voice for use.
     * If none available, will assign priorities.
     * @internal
     */
    public assignVoice() {
        for (let i = 0; i < this.systemParameters.voiceCap; i++) {
            const v = this.voices[i];
            if (!v.isActive) {
                // Prevent this voice from being stolen
                v.priority = Infinity;
                return v;
            }
        }
        // No match, assign priorities
        if (this.systemParameters.autoAllocateVoices) {
            SpessaLog.info(
                `%cAllocating a new voice, total count %c${this.systemParameters.voiceCap + 1}.`,
                ConsoleColors.info,
                ConsoleColors.value
            );
            // Allocate a new voice and return it
            this.allocateNewVoices(1);
            const v = this.voices[this.voices.length - 1];
            // @ts-expect-error Setter here, readonly for consumers
            this.systemParameters.voiceCap++;
            // Prevent this voice from being stolen
            v.priority = Infinity;
            return v;
        }
        this.assignVoicePriorities();
        let lowest = this.voices[0];
        for (let i = 0; i < this.systemParameters.voiceCap; i++) {
            const v = this.voices[i];
            if (v.priority < lowest.priority) lowest = v;
        }
        lowest.priority = Infinity;
        return lowest;
    }

    /**
     * Stops all notes on all channels.
     * @param force If true, all notes are stopped immediately,
     * otherwise they are stopped gracefully.
     */
    public stopAll(force = false) {
        SpessaLog.info("%cStop all received!", ConsoleColors.info);
        for (const channel of this.midiChannels) {
            channel.stopAllNotes(force);
        }
    }

    /**
     * Processes a raw MIDI message and allows scheduling it at a specific time.
     * @param message The binary MIDI message data to process.
     * @param channelOffset The channel offset for the message. It will be added to message's channel number if applicable.
     * @param options Additional options for scheduling the message.
     */
    public processMessage(
        message: SysExAcceptedArray | MIDIMessage,
        channelOffset = 0,
        options: SynthMethodOptions = DEFAULT_SYNTH_METHOD_OPTIONS
    ) {
        const raw =
            message instanceof MIDIMessage
                ? [message.statusByte, ...message.data]
                : message;

        const time = options.time;
        if (time > this.currentTime) {
            this.eventQueue.push({
                message: raw,
                channelOffset,
                time
            });
            this.eventQueue.sort((e1, e2) => e1.time - e2.time);
        } else {
            this.processMessageInternal(raw, channelOffset);
        }
    }

    // noinspection JSUnusedGlobalSymbols
    /**
     * Processes multiple MIDI messages and allows scheduling them at a specific time.
     * @param messages The binary MIDI messages to process.
     * @param channelOffset The channel offset for the messages. It will be added to messages' channel numbers if applicable.
     * @param options Additional options for scheduling the messages.
     */
    public processMessages(
        messages: (SysExAcceptedArray | MIDIMessage)[],
        channelOffset = 0,
        options: SynthMethodOptions = DEFAULT_SYNTH_METHOD_OPTIONS
    ) {
        for (const message of messages)
            this.processMessage(message, channelOffset, options);
    }

    // noinspection JSUnusedGlobalSymbols
    /**
     * Destroy the synthesizer processor, clearing all channels and voices.
     *
     * > **Warning**
     * >
     * > This is irreversible, so use with caution.
     */
    public destroy() {
        this.voices.length = 0;
        for (const c of this.midiChannels) c.destroy();
        this.clearCache();
        this.midiChannels.length = 0;
        this.soundBankManager.destroy();
    }

    /**
     * @param channel channel to get voices for
     * @param midiNote the MIDI note to use
     * @param velocity the velocity to use
     * @returns output is an array of Voices
     * @internal
     */
    public getVoices(
        channel: number,
        midiNote: number,
        velocity: number
    ): CachedVoiceList {
        const channelObject = this.midiChannels[channel];

        const preset = channelObject.preset;

        // Warning is handled in program change
        if (!preset) {
            return [];
        }

        return this.getVoicesForPreset(preset, midiNote, velocity);
    }

    /**
     * Applies the snapshot to this `SpessaSynthProcessor` instance.
     *
     * > **Warning**
     * >
     * > This method overrides the existing System Parameters with the ones from the snapshot.
     *
     * If this processor has more XG insertion blocks than the snapshot,
     * the blocks without snapshot data are reset to their defaults.
     *
     * @param snapshot The snapshot to apply.
     */
    public applySnapshot(snapshot: SynthesizerSnapshot) {
        this.savedSnapshot = snapshot;
        applySnapshot.call(this, snapshot);
        // Don't reset here, I don't know why I put a reset here previously.
    }

    // noinspection JSUnusedGlobalSymbols
    /**
     * Gets a synthesizer snapshot from this processor instance.
     */
    public getSnapshot(): SynthesizerSnapshot {
        return getSynthesizerSnapshot.call(this);
    }

    // noinspection JSUnusedGlobalSymbols
    /**
     * Sets the embedded sound bank.
     * @param bank The sound bank file to set.
     * @param offset The bank offset of the embedded sound bank.
     * @internal
     */
    public setEmbeddedSoundBank(bank: ArrayBuffer, offset: number) {
        // The embedded bank is set as the first bank in the manager,
        // With a special ID that is randomized.
        const loadedFont = SoundBankLoader.fromArrayBuffer(bank);
        this.soundBankManager.addSoundBank(
            loadedFont,
            EMBEDDED_SOUND_BANK_ID,
            offset
        );
        // Rearrange so the embedded is first (most important as it overrides all others)
        const order = this.soundBankManager.priorityOrder.filter(
            (id) => id !== EMBEDDED_SOUND_BANK_ID
        );
        order.unshift(EMBEDDED_SOUND_BANK_ID);
        this.soundBankManager.priorityOrder = order;

        // Apply snapshot again if applicable
        if (this.savedSnapshot !== undefined) {
            this.applySnapshot(this.savedSnapshot);
        }
        SpessaLog.info(
            `%cEmbedded sound bank set at offset %c${offset}`,
            ConsoleColors.recognized,
            ConsoleColors.value
        );
    }

    // noinspection JSUnusedGlobalSymbols
    /**
     * Removes the embedded sound bank from the synthesizer.
     * @internal
     */
    public clearEmbeddedSoundBank() {
        if (
            this.soundBankManager.soundBankList.some(
                (s) => s.id === EMBEDDED_SOUND_BANK_ID
            )
        ) {
            this.soundBankManager.deleteSoundBank(EMBEDDED_SOUND_BANK_ID);
        }
    }

    /**
     * Creates a new MIDI channel and adds it to the synthesizer.
     * Emits a {@link SynthesizerEvent.channelAdded} event.
     */
    public createMIDIChannel() {
        this.createMIDIChannelInternal(true);
    }

    /**
     * Executes a full system reset of the synthesizer.
     * This will stop all notes and reset all controllers to their default values,
     * except for the locked controllers.
     * @param system The MIDI system to reset the synthesizer to. Defaults to `gs`.
     */
    public reset(system: MIDISystem = DEFAULT_SYNTH_MODE) {
        // Listeners get this before anything is reset
        this.callEvent("reset", system);
        this.stopAll();
        // Reset MIDI parameters
        this.setMIDIParameter("system", system);
        this.setMIDIParameter("volume", DEFAULT_GLOBAL_MIDI_PARAMETERS.volume);
        this.setMIDIParameter("pan", DEFAULT_GLOBAL_MIDI_PARAMETERS.pan);
        this.setMIDIParameter(
            "keyShift",
            DEFAULT_GLOBAL_MIDI_PARAMETERS.keyShift
        );
        this.setMIDIParameter(
            "fineTune",
            DEFAULT_GLOBAL_MIDI_PARAMETERS.fineTune
        );
        // Reset private props
        this.tunings.fill(-1); // Set all to no change
        this.portSelectChannelOffset = 0;
        this.customChannelNumbers = false;
        // Hall2 default
        this.setReverbMacro(4);
        // Chorus3 default
        this.setChorusMacro(2);
        // Delay1 default
        this.setDelayMacro(0);
        if (!this.systemParameters.gsEqualizerLock) {
            const eq = this.gsEqualizerProcessor;
            for (const parameter of GS_EQUALIZER_PARAMETERS) {
                eq[parameter] = DEFAULT_GS_EQUALIZER[parameter];
                this.callEvent("effectChange", {
                    effect: "gsEqualizer",
                    parameter,
                    value: eq[parameter]
                });
            }
        }
        if (!this.systemParameters.gsInsertionLock) {
            this.gsInsertionBlock.reset();
            this.callEvent("effectChange", {
                effect: "gsInsertion",
                parameter: "type",
                value: this.gsInsertionBlock.getType()
            });
        }

        // Reset XG params
        if (!this.systemParameters.xgReverbLock) {
            const reverb = this.xgReverbBlock;
            reverb.reset();
            this.callEvent("effectChange", {
                effect: "xgReverb",
                parameter: "type",
                value: reverb.getType()
            });
            this.callEvent("effectChange", {
                effect: "xgReverb",
                parameter: "return",
                value: reverb.return
            });
            this.callEvent("effectChange", {
                effect: "xgReverb",
                parameter: "pan",
                value: reverb.pan
            });
        }
        if (!this.systemParameters.xgChorusLock) {
            const chorus = this.xgChorusBlock;
            chorus.reset();
            this.callEvent("effectChange", {
                effect: "xgChorus",
                parameter: "type",
                value: chorus.getType()
            });
            this.callEvent("effectChange", {
                effect: "xgChorus",
                parameter: "return",
                value: chorus.return
            });
            this.callEvent("effectChange", {
                effect: "xgChorus",
                parameter: "pan",
                value: chorus.pan
            });
            this.callEvent("effectChange", {
                effect: "xgChorus",
                parameter: "sendToReverb",
                value: chorus.sendToReverb
            });
        }
        if (!this.systemParameters.xgVariationLock) {
            const variation = this.xgVariationBlock;
            variation.reset();
            this.callEvent("effectChange", {
                effect: "xgVariation",
                parameter: "type",
                value: variation.getType()
            });
            this.callEvent("effectChange", {
                effect: "xgVariation",
                parameter: "return",
                value: variation.return
            });
            this.callEvent("effectChange", {
                effect: "xgVariation",
                parameter: "pan",
                value: variation.pan
            });
            this.callEvent("effectChange", {
                effect: "xgVariation",
                parameter: "sendToReverb",
                value: variation.sendToReverb
            });
            this.callEvent("effectChange", {
                effect: "xgVariation",
                parameter: "sendToChorus",
                value: variation.sendToChorus
            });
            this.callEvent("effectChange", {
                effect: "xgVariation",
                parameter: "connection",
                value: variation.insertionMode ? "insertion" : "system"
            });
            this.callEvent("effectChange", {
                effect: "xgVariation",
                parameter: "partNumber",
                value: variation.partNumber
            });
        }
        if (!this.systemParameters.xgInsertionLock) {
            for (
                let insertionNumber = 0;
                insertionNumber < this.xgInsertionBlocks.length;
                insertionNumber++
            ) {
                const insertion = this.xgInsertionBlocks[insertionNumber];
                insertion.reset();
                this.callEvent("effectChange", {
                    effect: "xgInsertion",
                    insertionNumber,
                    parameter: "type",
                    value: insertion.getType()
                });
                this.callEvent("effectChange", {
                    effect: "xgInsertion",
                    insertionNumber,
                    parameter: "partNumber",
                    value: insertion.partNumber
                });
            }
        }

        // Reset GS user drums
        if (!this.systemParameters.userDrumLock)
            for (const userDrum of this.soundBankManager.userDrumSets)
                userDrum.reset();

        // Reset channels
        // Do not send CC changes as we call reset
        for (const ch of this.midiChannels) ch.reset(false);

        // Update if the effects should still be active.
        this.updateActiveGSEffects();
    }

    /**
     * Renders Float32 PCM audio data to stereo outputs; buffer size must be equal or smaller than {@link SynthProcessorOptions.maxBufferSize `maxBufferSize`}.
     * All float arrays must have the same length.
     *
     * The audio is added to the existing contents of the output arrays,
     * so make sure to clear them when reusing them.
     *
     * > **Warning**
     * >
     * > This method renders a single quantum of audio.
     * > The LFOs and envelopes are only processed at the beginning.
     * > `sampleCount` cannot exceed `maxBufferSize`. Larger values will throw an exception!
     *
     * > **Tip**
     * >
     * > The legacy `processSplit` method has been superseded in 4.4.0 by process with visualization channels.
     * > This approach allows visualization with insertion effects and upcoming EQ.
     *
     * @param left The left output buffer for PCM data.
     * @param right The right output buffer for PCM data.
     * @param startIndex The offset at which to start rendering audio in the provided arrays. Default is 0.
     * @param sampleCount The number of samples to render.
     * Default is the entire length, starting from `startIndex`.
     * @param channelOutputs optional stereo channel outputs with dry (no effects) PCM data of specific channels.
     * These shouldn't be added to the `left` and `right` outputs. Recommended use-case is visualization.
     */
    public process(
        left: Float32Array,
        right: Float32Array,
        startIndex = 0,
        sampleCount = 0,
        channelOutputs?: Float32Array[][]
    ) {
        /**
         * The main rendering pipeline, renders all voices and processes the effects:
         * ```
         *                   ┌────────────────────────────────┐
         *                   │        Voice Processor         │
         *                   └───────────────┬────────────────┘
         *                                   │
         *                   ┌───────────────┴────────────────┐
         *                   │      Insertion Processor       │
         *                   │      (Bypass or Process)       │
         *                   └───────────────┬────────────────┘
         *                                   │
         *              ┌──────────┬─────────┼────────────────────────┐
         *              │          │         │                        │
         *              │          │         𜸊                        │
         *              │          │ ┌───────┴───────┐                │
         *              │          │ │    Chorus     │                │
         *              │          │ │   Processor   ├──────────┐     │
         *              │          │ └─┬──────────┬──┘          │     │
         *         ┌────┴────┐     │   │          │             │     │
         *         │Equalizer│     │   │          │             │     │
         *         │or Bypass│     │   │          │             │     │
         *         └────┬────┘     │   │          │             │     │
         *              │          │   │          𜸊             𜸊     𜸊
         *              │          │   │ ┌────────┴───────┐   ┌─┴─────┴────────┐
         *              │          └───┼>┤     Delay      ├─>>┤     Reverb     │
         *              │              │ │   Processor    │   │   Processor    │
         *              │              │ └────────┬───────┘   └───────┬────────┘
         *              │              │          │                   │
         *              │              │          │                   │
         *              │              │          │                   │
         *              │              │          │                   │
         *              𜸊              𜸊          𜸊                   𜸊
         *    ┌─────────┴──────────────┴──────────┴───────────────────┴────┐
         *    │                        Stereo Output                       │
         *    └────────────────────────────────────────────────────────────┘
         * ```
         */
        // Process event queue
        if (this.eventQueue.length > 0) {
            const time = this.currentTime;
            while (this.eventQueue[0]?.time <= time) {
                const q = this.eventQueue.shift();
                if (q) {
                    this.processMessageInternal(q.message, q.channelOffset);
                }
            }
        }

        // Validate
        startIndex = Math.max(startIndex, 0);
        sampleCount = sampleCount || left.length - startIndex;
        if (sampleCount > this.maxBufferSize)
            throw new Error(
                `Requested ${sampleCount} samples, but maxBufferSize is ${this.maxBufferSize}`
            );

        const isXG = this.midiParameters.system === "xg";
        const variationInsertion = this.xgVariationBlock.insertionMode;
        const fx = this.systemParameters.effectsEnabled;
        const eq = fx && !isXG;

        // For XG, renderVoice always checks if insertion is assigned to bypass effect sends
        // Cache it here
        if (isXG && fx) {
            for (const channel of this.midiChannels)
                channel.xgInsertionAssigned = false;

            for (const insertion of this.xgInsertionBlocks) {
                const channel = this.midiChannels[insertion.partNumber];
                if (channel) channel.xgInsertionAssigned = true;
            }
            if (variationInsertion) {
                const channel =
                    this.midiChannels[this.xgVariationBlock.partNumber];
                if (channel) channel.xgInsertionAssigned = true;
            }
        }

        // Clear the buffers
        // (The effect inputs are overwritten with the voice sends after rendering)
        if (this.gsInsertionActive) {
            this.insertionInputL.fill(0);
            this.insertionInputR.fill(0);
        }
        if (eq) {
            this.equalizerInputL.fill(0);
            this.equalizerInputR.fill(0);
        }
        for (const c of this.midiChannels) {
            // And voice count
            c.clearVoiceCount();
            // Silent channels are already cleared
            if (c.outputDirty) {
                c.outputRight.fill(0);
                c.outputLeft.fill(0);
                c.outputDirty = false;
            }
        }
        this._voiceCount = 0;

        // Process voices
        const cap = this.systemParameters.voiceCap;
        const outputCount = channelOutputs?.length ?? 0;
        for (let i = 0; i < cap; i++) {
            const v = this.voices[i];
            if (!v.isActive) continue;
            const ch = this.midiChannels[v.channel];

            ch.renderVoice(v, this.currentTime, sampleCount);

            // Update voice count
            ch.voiceCount++;
            ch.outputDirty = true;
            this._voiceCount++;
        }
        for (const c of this.midiChannels) {
            if (c.voiceSendBufferCount > 0) {
                for (let i = 0; i < c.voiceSendBufferCount; i++)
                    mixVoiceSendBuffer(c, c.voiceSendBuffers[i], sampleCount);
                c.voiceSendBufferCount = 0;
            }
        }

        // Move the voice sends into the effect inputs
        if (isXG) {
            // Not worth inlining after testing with node
            moveSends(this.xgReverbSendL, this.xgReverbInputL, sampleCount);
            moveSends(this.xgReverbSendR, this.xgReverbInputR, sampleCount);
            moveSends(this.xgChorusSendL, this.xgChorusInputL, sampleCount);
            moveSends(this.xgChorusSendR, this.xgChorusInputR, sampleCount);
            moveSends(
                this.xgVariationSendL,
                this.xgVariationInputL,
                sampleCount
            );
            moveSends(
                this.xgVariationSendR,
                this.xgVariationInputR,
                sampleCount
            );
        } else {
            moveSends(this.gsReverbSend, this.gsReverbInput, sampleCount);
            moveSends(this.gsChorusSend, this.gsChorusInput, sampleCount);
            if (this.gsDelayActive)
                moveSends(this.gsDelaySend, this.gsDelayInput, sampleCount);
        }

        // Process insertion effects
        if (isXG && fx) {
            for (const insertion of this.xgInsertionBlocks) {
                const channel = this.midiChannels[insertion.partNumber];
                if (channel)
                    this.processXGInsertion(insertion, channel, sampleCount);
            }

            // Variation is processed last
            // See MU128 manual, page 154
            if (variationInsertion) {
                const channel =
                    this.midiChannels[this.xgVariationBlock.partNumber];
                if (channel)
                    this.processXGInsertion(
                        this.xgVariationBlock,
                        channel,
                        sampleCount
                    );
            }

            // If a channel has insertion assigned (or variation in insertion mode) then its sends are routed globally (not in renderVoice)
            // If effectsEnabled is false it does not matter, so the code here can also be skipped.
            // The reverb and chorus gains apply here too, like they do in renderVoice
            const { reverbGain, chorusGain } = this.systemParameters;
            for (const ch of this.midiChannels) {
                if (!ch.xgInsertionAssigned) continue;

                const revSend =
                    (reverbGain *
                        (ch.midiControllers[MIDIControllers.reverbDepth] >>
                            7)) /
                    127;
                const choSend =
                    (chorusGain *
                        (ch.midiControllers[MIDIControllers.chorusDepth] >>
                            7)) /
                    127;
                if (revSend <= 0 && choSend <= 0) continue;

                const { outputLeft, outputRight } = ch;
                for (let i = 0; i < sampleCount; i++) {
                    const wetL = outputLeft[i];
                    const wetR = outputRight[i];
                    this.xgReverbInputL[i] += wetL * revSend;
                    this.xgReverbInputR[i] += wetR * revSend;
                    this.xgChorusInputL[i] += wetL * choSend;
                    this.xgChorusInputR[i] += wetR * choSend;
                }
            }
        }

        // Mix channel data
        for (let channel = 0; channel < this.midiChannels.length; channel++) {
            const ch = this.midiChannels[channel];
            // Nothing to mix
            if (!ch.outputDirty) continue;
            const { outputLeft, outputRight, midiParameters } = ch;
            // Mix visualization first
            if (outputCount) {
                const out = channelOutputs![channel % outputCount];
                const outL = out[0];
                const outR = out[1];

                for (let i = 0; i < sampleCount; i++) {
                    const idx = startIndex + i;
                    outL[idx] += outputLeft[i];
                    outR[idx] += outputRight[i];
                }
            }

            // Straight into the insertion EFX, but only if it is active
            if (midiParameters.efxAssign && fx && this.gsInsertionActive) {
                const insertionL = this.insertionInputL;
                const insertionR = this.insertionInputR;
                // Index is 0-based here as it's internal
                for (let i = 0; i < sampleCount; i++) {
                    insertionL[i] += outputLeft[i];
                    insertionR[i] += outputRight[i];
                }
                continue;
            }

            // Into the equalizer instead of the output
            if (eq && midiParameters.eqEnabled) {
                const equalizerL = this.equalizerInputL;
                const equalizerR = this.equalizerInputR;
                for (let i = 0; i < sampleCount; i++) {
                    equalizerL[i] += outputLeft[i];
                    equalizerR[i] += outputRight[i];
                }
                continue;
            }

            // Dry level is only active in XG with variation connection set to SYSTEM.
            if (isXG && !variationInsertion) {
                // Mix down taking dry level into account
                const gain = midiParameters.dryLevel / 127;
                for (let i = 0; i < sampleCount; i++) {
                    const idx = startIndex + i;
                    left[idx] += outputLeft[i] * gain;
                    right[idx] += outputRight[i] * gain;
                }
            } else {
                // Mix down normally
                for (let i = 0; i < sampleCount; i++) {
                    const idx = startIndex + i;
                    left[idx] += outputLeft[i];
                    right[idx] += outputRight[i];
                }
            }
        }

        // Process effects
        if (fx) {
            const {
                gsChorusInput,
                gsDelayInput,
                gsReverbInput,
                insertionInputR,
                insertionInputL
            } = this;

            if (isXG) {
                // Variation system first, feeds the chorus and reverb
                if (!variationInsertion) {
                    this.xgVariationBlock.process(
                        this.xgVariationInputL,
                        this.xgVariationInputR,
                        left,
                        right,
                        this.xgChorusInputL,
                        this.xgChorusInputR,
                        this.xgReverbInputL,
                        this.xgReverbInputR,
                        startIndex,
                        sampleCount
                    );
                }
                // Chorus feeds reverb, reverb goes straight to the output
                this.xgChorusBlock.process(
                    this.xgChorusInputL,
                    this.xgChorusInputR,
                    left,
                    right,
                    this.xgReverbInputL,
                    this.xgReverbInputR,
                    startIndex,
                    sampleCount
                );

                // Reverb last, doesn't feed to anything.
                this.xgReverbBlock.process(
                    this.xgReverbInputL,
                    this.xgReverbInputR,
                    left,
                    right,
                    startIndex,
                    sampleCount
                );
            } else {
                // Insertion first
                if (this.gsInsertionActive) {
                    const insertion = this.gsInsertionBlock;
                    // The send EQ switch routes the insertion output into the equalizer
                    const toEqualizer = eq && insertion.sendEQSwitch;
                    insertion.process(
                        insertionInputL,
                        insertionInputR,
                        toEqualizer ? this.equalizerInputL : left,
                        toEqualizer ? this.equalizerInputR : right,
                        gsReverbInput,
                        gsChorusInput,
                        gsDelayInput,
                        toEqualizer ? 0 : startIndex,
                        sampleCount
                    );
                }

                // Then the equalizer, the system effects do not pass through it
                if (eq) {
                    this.gsEqualizerProcessor.process(
                        this.equalizerInputL,
                        this.equalizerInputR,
                        left,
                        right,
                        startIndex,
                        sampleCount
                    );
                }

                // Chorus first, it feeds to reverb and delay
                this.gsChorusProcessor.process(
                    gsChorusInput,
                    left,
                    right,
                    gsReverbInput,
                    gsDelayInput,
                    startIndex,
                    sampleCount
                );
                if (this.gsDelayActive) {
                    // Process delay
                    this.gsDelayProcessor.process(
                        gsDelayInput,
                        left,
                        right,
                        gsReverbInput,
                        startIndex,
                        sampleCount
                    );
                }
                // Finally process the reverb processor (it goes directly into the output buffer)
                this.gsReverbProcessor.process(
                    gsReverbInput,
                    left,
                    right,
                    startIndex,
                    sampleCount
                );
            }
        }

        // Advance the time appropriately
        // @ts-expect-error This is readonly to consumers
        this.currentTime += sampleCount * this.sampleTime;
    }

    /**
     * Gets voices for a preset.
     * @param preset The preset to get voices for.
     * @param midiNote The MIDI note to use.
     * @param velocity The velocity to use.
     * @returns Output is an array of voices.
     * @internal
     */
    public getVoicesForPreset(
        preset: SynthesizerPatch,
        midiNote: number,
        velocity: number
    ): CachedVoiceList {
        const cached = this.getCachedVoice(preset, midiNote, velocity);
        // If cached, return it!
        if (cached !== undefined) {
            if (this.decodedSamples.enabled) {
                const key = this.getCachedVoiceIndex(
                    preset,
                    midiNote,
                    velocity
                );
                for (const v of cached)
                    this.decodedSamples.touch(v.sample, key);
            }
            return cached;
        }
        // Not cached...
        // Create the voices
        const voices = new Array<CachedVoice>();
        for (const voiceParams of preset.getVoiceParameters(
            midiNote,
            velocity
        )) {
            const sample = voiceParams.sample;
            try {
                // Decodes the sample if needed, which throws for invalid data
                sample.getAudioData();
            } catch (error) {
                SpessaLog.warn(
                    `Discarding invalid sample: ${sample.name} (${error as string})`
                );
                continue;
            }
            voices.push(
                new CachedVoice(
                    voiceParams,
                    midiNote,
                    velocity,
                    this.sampleRate
                )
            );
        }
        // Cache the voice
        this.setCachedVoice(preset, midiNote, velocity, voices);
        if (this.decodedSamples.enabled) {
            const key = this.getCachedVoiceIndex(preset, midiNote, velocity);
            for (const v of voices) this.decodedSamples.touch(v.sample, key);
        }
        return voices;
    }

    /**
     * Updates the synthesizer after the added sound banks were edited.
     * It rebuilds the preset list, clears the voice cache,
     * and points every channel at the current preset for its patch.
     *
     * Unlike adding a sound bank, this does not reset the synthesizer or send program changes,
     * so playback continues. Voices that are already playing keep the old data until they end.
     *
     * > **Tip**
     * >
     * > Call it after adding, removing or renumbering presets in a sound bank that is already added.
     * > For edits inside existing presets, {@link clearCache} is enough.
     */
    public refreshPresets() {
        this.soundBankManager.refresh();
    }

    /**
     * Clears the synthesizer's voice cache.
     * This can be used to hear the changes after editing a {@link BasicSoundBank}
     */
    public clearCache() {
        this.cachedVoices.clear();
    }

    /**
     * Copied callback so MIDI channels can call it.
     * @internal
     */
    public callEvent<K extends keyof SynthesizerEvent>(
        type: K,
        data: SynthesizerEvent[K]
    ) {
        if (!this.systemParameters.eventsEnabled) return;
        this.onEventCall?.({
            type,
            data
        } as SynthesizerEventCallback);
    }

    /**
     * @internal
     * Checks if we can disable insertion and delay effects.
     */
    public updateActiveGSEffects() {
        if (!this.systemParameters.gsInsertionLock)
            this.gsInsertionActive = this.midiChannels.some(
                (c) => c.midiParameters.efxAssign
            );
        if (!this.systemParameters.gsDelayLock)
            this.gsDelayActive =
                this.midiParameters.system === "xg"
                    ? false
                    : this.gsChorusProcessor.sendLevelToDelay > 0 ||
                      this.gsInsertionBlock.sendLevelToDelay > 0 ||
                      this.midiChannels.some(
                          (c) =>
                              c.midiControllers[
                                  MIDIControllers.variationDepth
                              ] > 0
                      );
    }

    /**
     * Removes every cached voice of the given patch.
     * @internal
     */
    public purgeCachedPatch(patch: MIDIPatch) {
        // The patch occupies the lowest digits of the cache key (below 256 * 128 * 128)
        const patchKey = this.getCachedVoiceIndex(patch, 0, 0);
        for (const key of this.cachedVoices.keys()) {
            if (key % 4_194_304 === patchKey) this.cachedVoices.delete(key);
        }
    }

    /**
     * Sets a global MIDI parameter of the synthesizer.
     * @param parameter The type of the global MIDI parameter to set.
     * @param value The value to set for the global MIDI parameter.
     * @internal
     */
    protected setMIDIParameter<P extends keyof GlobalMIDIParameter>(
        parameter: P,
        value: GlobalMIDIParameter[P]
    ) {
        // Patched with the actual function in the constructor.
        void parameter;
        void value;
    }

    /**
     * @internal
     */
    protected setUserDrumSetParam<K extends keyof UserDrumSetParameter>(
        drumSet: number,
        midiNote: number,
        parameter: K,
        value: UserDrumSetParameter[K]
    ) {
        const set = this.soundBankManager.userDrumSets[drumSet];
        // Optimization for bulk dump
        // Testcase FADED88.mid
        if (set.keyParams[midiNote][parameter] === value) {
            return;
        }
        set.keyParams[midiNote][parameter] = value;
        this.callEvent("userDrumSetChange", {
            midiNote,
            drumSet,
            parameter,
            value
        } as UserDrumSetChangeEvent);
        SpessaLog.gsInfo(
            `User Drum Set ${drumSet} ${parameter}, key ${midiNote}`,
            value.toString()
        );
    }

    /**
     * @internal
     */
    protected setReverbMacro(macro: number) {
        if (this.systemParameters.gsReverbLock) return;
        if (macro > 7) {
            // Invalid macros are ignored
            // Testcase: 18 - Dichromatic Lotus Butterfly ~ Ancients (ZUN).mid
            SpessaLog.warn(`Invalid reverb macro: ${macro}`);
            return;
        }
        // SC-8850 manual page 81
        const rev = this.gsReverbProcessor;
        rev.level = 64;
        rev.preDelayTime = 0;
        switch (macro) {
            /**
             * REVERB MACRO is a macro parameter that allows global setting of reverb parameters.
             * When you select the reverb type with REVERB MACRO, each reverb parameter will be set to their most
             * suitable value.
             *
             * Room1, Room2, Room3
             * These reverbs simulate the reverberation of a room. They provide a well-defined
             * spacious reverberation.
             * Hall1, Hall2
             * These reverbs simulate the reverberation of a concert hall. They provide a deeper
             * reverberation than the Room reverbs.
             * Plate
             * This simulates a plate reverb (a studio device using a metal plate).
             * Delay
             * This is a conventional delay that produces echo effects.
             * Panning Delay
             * This is a special delay in which the delayed sounds move left and right.
             * It is effective when you are listening in stereo.
             */
            case 0: {
                // Room1
                rev.character = 0;
                rev.preLowpass = 3;
                rev.time = 80;
                rev.delayFeedback = 0;
                rev.preDelayTime = 0;
                break;
            }

            case 1: {
                // Room2
                rev.character = 1;
                rev.preLowpass = 4;
                rev.time = 56;
                rev.delayFeedback = 0;
                break;
            }

            case 2: {
                // Room3
                rev.character = 2;
                rev.preLowpass = 0;
                rev.time = 72;
                rev.delayFeedback = 0;
                break;
            }

            case 3: {
                // Hall1
                rev.character = 3;
                rev.preLowpass = 4;
                rev.time = 72;
                rev.delayFeedback = 0;
                break;
            }

            case 4: {
                // Hall2
                rev.character = 4;
                rev.preLowpass = 0;
                rev.time = 64;
                rev.delayFeedback = 0;
                break;
            }

            case 5: {
                // Plate
                rev.character = 5;
                rev.preLowpass = 0;
                rev.time = 88;
                rev.delayFeedback = 0;
                break;
            }

            case 6: {
                // Delay
                rev.character = 6;
                rev.preLowpass = 0;
                rev.time = 32;
                rev.delayFeedback = 40;
                break;
            }

            case 7: {
                // Panning delay
                rev.character = 7;
                rev.preLowpass = 0;
                rev.time = 64;
                rev.delayFeedback = 32;
                break;
            }
        }
        for (const parameter of GS_REVERB_MACRO_PARAMETERS) {
            this.callEvent("effectChange", {
                effect: "gsReverb",
                parameter,
                value: rev[parameter]
            });
        }
        // The macro is reported last, after its parameters
        this.callEvent("effectChange", {
            effect: "gsReverb",
            parameter: "macro",
            value: macro
        });
    }
    /**
     * @internal
     */
    protected setChorusMacro(macro: number) {
        if (this.systemParameters.gsChorusLock) return;
        if (macro > 7) {
            // Invalid macros are ignored
            // Testcase: 18 - Dichromatic Lotus Butterfly ~ Ancients (ZUN).mid
            SpessaLog.warn(`Invalid chorus macro: ${macro}`);
            return;
        }
        // SC-8850 manual page 83
        const chr = this.gsChorusProcessor;
        chr.level = 64;
        chr.preLowpass = 0;
        chr.delay = 127;
        chr.sendLevelToDelay = 0;
        chr.sendLevelToReverb = 0;
        // The send to delay changed, so the delay may no longer be needed
        this.updateActiveGSEffects();
        switch (macro) {
            /**
             * CHORUS MACRO is a macro parameter that allows global setting of chorus parameters.
             * When you select the chorus type with CHORUS MACRO, each chorus parameter will be set to their
             * most suitable value.
             *
             * Chorus1, Chorus2, Chorus3, Chorus4
             * These are conventional chorus effects that add spaciousness and depth to the
             * sound.
             * Feedback Chorus
             * This is a chorus with a flanger-like effect and a soft sound.
             * Flanger
             * This is an effect sounding somewhat like a jet airplane taking off and landing.
             * Short Delay
             * This is a delay with a short delay time.
             * Short Delay (FB)
             * This is a short delay with many repeats.
             */
            case 0: {
                // Chorus1
                chr.feedback = 0;
                chr.delay = 112;
                chr.rate = 3;
                chr.depth = 5;
                break;
            }

            case 1: {
                // Chorus2
                chr.feedback = 5;
                chr.delay = 80;
                chr.rate = 9;
                chr.depth = 19;
                break;
            }

            case 2: {
                // Chorus3
                chr.feedback = 8;
                chr.delay = 80;
                chr.rate = 3;
                chr.depth = 19;
                break;
            }

            case 3: {
                // Chorus4
                chr.feedback = 16;
                chr.delay = 64;
                chr.rate = 9;
                chr.depth = 16;
                break;
            }

            case 4: {
                // FbChorus
                chr.feedback = 64;
                chr.delay = 127;
                chr.rate = 2;
                chr.depth = 24;
                break;
            }

            case 5: {
                // Flanger
                chr.feedback = 112;
                chr.delay = 127;
                chr.rate = 1;
                chr.depth = 5;
                break;
            }

            case 6: {
                // SDelay
                chr.feedback = 0;
                chr.delay = 127;
                chr.rate = 0;
                chr.depth = 127;
                break;
            }

            case 7: {
                // SDelayFb
                chr.feedback = 80;
                chr.delay = 127;
                chr.rate = 0;
                chr.depth = 127;
                break;
            }
        }
        for (const parameter of GS_CHORUS_MACRO_PARAMETERS) {
            this.callEvent("effectChange", {
                effect: "gsChorus",
                parameter,
                value: chr[parameter]
            });
        }
        // The macro is reported last
        this.callEvent("effectChange", {
            effect: "gsChorus",
            parameter: "macro",
            value: macro
        });
    }
    /**
     * @internal
     */
    protected setDelayMacro(macro: number) {
        if (this.systemParameters.gsDelayLock) return;
        if (macro > 9) {
            // Invalid macros are ignored
            // Testcase: 18 - Dichromatic Lotus Butterfly ~ Ancients (ZUN).mid
            SpessaLog.warn(`Invalid delay macro: ${macro}`);
            return;
        }
        // SC-8850 manual page 85
        const dly = this.gsDelayProcessor;
        dly.level = 64;
        dly.preLowpass = 0;
        dly.sendLevelToReverb = 0;
        dly.levelRight = dly.levelLeft = 0;
        dly.levelCenter = 127;
        switch (macro) {
            /**
             * DELAY MACRO is a macro parameter that allows global setting of delay parameters. When you select the delay type with DELAY MACRO, each delay parameter will be set to their most
             * suitable value.
             *
             * Delay1, Delay2, Delay3
             * These are conventional delays. 1, 2 and 3 have progressively longer delay times.
             * Delay4
             * This is a delay with a rather short delay time.
             * Pan Delay1. Pan Delay2. Pan Delay3
             * The delay sound moves between left and right. This is effective when listening in
             * stereo. 1, 2 and 3 have progressively longer delay times.
             * Pan Delay4
             * This is a rather short delay with the delayed sound moving between left and
             * right.
             * It is effective when listening in stereo.
             * Dly To Rev
             * Reverb is added to the delay sound, which moves between left and right.
             * It is effective when listening in stereo.
             * PanRepeat
             * The delay sound moves between left and right,
             * but the pan positioning is different from the effects listed above.
             * It is effective when listening in stereo.
             */
            case 0: {
                // Delay1
                dly.timeCenter = 97;
                dly.timeRatioRight = dly.timeRatioLeft = 1;
                dly.feedback = 80;
                break;
            }

            case 1: {
                // Delay2
                dly.timeCenter = 106;
                dly.timeRatioRight = dly.timeRatioLeft = 1;
                dly.feedback = 80;
                break;
            }

            case 2: {
                // Delay3
                dly.timeCenter = 115;
                dly.timeRatioRight = dly.timeRatioLeft = 1;
                dly.feedback = 72;
                break;
            }

            case 3: {
                // Delay4
                dly.timeCenter = 83;
                dly.timeRatioRight = dly.timeRatioLeft = 1;
                dly.feedback = 72;
                break;
            }

            case 4: {
                // PanDelay1
                dly.timeCenter = 105;
                dly.timeRatioLeft = 12;
                dly.timeRatioRight = 24;
                dly.levelCenter = 0;
                dly.levelLeft = 125;
                dly.levelRight = 60;
                dly.feedback = 74;
                break;
            }

            case 5: {
                // PanDelay2
                dly.timeCenter = 109;
                dly.timeRatioLeft = 12;
                dly.timeRatioRight = 24;
                dly.levelCenter = 0;
                dly.levelLeft = 125;
                dly.levelRight = 60;
                dly.feedback = 71;
                break;
            }

            case 6: {
                // PanDelay3
                dly.timeCenter = 115;
                dly.timeRatioLeft = 12;
                dly.timeRatioRight = 24;
                dly.levelCenter = 0;
                dly.levelLeft = 120;
                dly.levelRight = 64;
                dly.feedback = 73;
                break;
            }

            case 7: {
                // PanDelay4
                dly.timeCenter = 93;
                dly.timeRatioLeft = 12;
                dly.timeRatioRight = 24;
                dly.levelCenter = 0;
                dly.levelLeft = 120;
                dly.levelRight = 64;
                dly.feedback = 72;
                break;
            }

            case 8: {
                // DelayToReverb
                dly.timeCenter = 109;
                dly.timeRatioLeft = 12;
                dly.timeRatioRight = 24;
                dly.levelCenter = 0;
                dly.levelLeft = 114;
                dly.levelRight = 60;
                dly.feedback = 61;
                dly.sendLevelToReverb = 36;
                break;
            }

            case 9: {
                // PanRepeat
                dly.timeCenter = 110;
                dly.timeRatioLeft = 21;
                dly.timeRatioRight = 32;
                dly.levelCenter = 97;
                dly.levelLeft = 127;
                dly.levelRight = 67;
                dly.feedback = 40;
                break;
            }
        }
        for (const parameter of GS_DELAY_MACRO_PARAMETERS) {
            this.callEvent("effectChange", {
                effect: "gsDelay",
                parameter,
                value: dly[parameter]
            });
        }
        // The macro is reported last, after its parameters
        this.callEvent("effectChange", {
            effect: "gsDelay",
            parameter: "macro",
            value: macro
        });
    }

    /**
     * @internal
     */
    protected getCachedVoice(
        patch: MIDIPatch,
        midiNote: number,
        velocity: number
    ): CachedVoiceList | undefined {
        return this.cachedVoices.get(
            this.getCachedVoiceIndex(patch, midiNote, velocity)
        );
    }

    /**
     * @internal
     */
    protected setCachedVoice(
        patch: MIDIPatch,
        midiNote: number,
        velocity: number,
        voices: CachedVoiceList
    ) {
        this.cachedVoices.set(
            this.getCachedVoiceIndex(patch, midiNote, velocity),
            voices
        );
    }

    /**
     * Allocates new voices.
     * @param count
     * @internal
     */
    protected allocateNewVoices(count: number) {
        for (let i = 0; i < count; i++)
            this.voices.push(new Voice(this.sampleRate, this.maxBufferSize));
    }

    /**
     * Processes an XG insertion block in-place on a channel's output.
     * Channel outputs are double precision, while insertion blocks take float32 buffers.
     * @param block The insertion block to process.
     * @param channel The channel assigned to the block.
     * @param sampleCount The number of samples to process.
     */
    private processXGInsertion(
        block: XGInsertionBlock,
        channel: MIDIChannel,
        sampleCount: number
    ) {
        const bufferL = this.xgInsertionBufferL;
        const bufferR = this.xgInsertionBufferR;
        const { outputLeft, outputRight } = channel;
        for (let i = 0; i < sampleCount; i++) {
            bufferL[i] = outputLeft[i];
            bufferR[i] = outputRight[i];
        }
        block.processInsertion(bufferL, bufferR, sampleCount);
        for (let i = 0; i < sampleCount; i++) {
            outputLeft[i] = bufferL[i];
            outputRight[i] = bufferR[i];
        }
        // The insertion output (including its tail) is now in the channel
        channel.outputDirty = true;
    }

    private createMIDIChannelInternal(sendEvent: boolean) {
        const channel: MIDIChannel = new MIDIChannel(
            this,
            this.defaultPreset,
            this.drumPreset,
            this.midiChannels.length
        );
        this.midiChannels.push(channel);
        // Channel is added first, then reset
        if (sendEvent) this.callEvent("channelAdded", undefined);
        // New channels need the default controllers, otherwise they are silent (CC7 = 0)
        channel.reset(false);
    }

    private processMessageInternal(
        message: SysExAcceptedArray,
        channelOffset: number
    ) {
        const byte = message[0] as MIDIMessageType;
        let status: MIDIMessageType;
        let channel = 0;
        if (byte >= 0x80 && byte < 0xf0) {
            // Voice message
            status = (byte & 0xf0) as MIDIMessageType;
            channel = byte & 0x0f;
        } else {
            status = byte;
        }

        channel += channelOffset;
        // Process the event
        switch (status) {
            case MIDIMessageTypes.noteOn: {
                const velocity = message[2];
                if (velocity > 0) {
                    this.noteOn(channel, message[1], velocity);
                } else {
                    this.noteOff(channel, message[1]);
                }
                break;
            }

            case MIDIMessageTypes.noteOff: {
                this.noteOff(channel, message[1]);
                break;
            }

            case MIDIMessageTypes.pitchWheel: {
                // LSB | (MSB << 7)
                this.pitchWheel(channel, (message[2] << 7) | message[1]);
                break;
            }

            case MIDIMessageTypes.controllerChange: {
                this.controllerChange(
                    channel,
                    message[1] as MIDIController,
                    message[2]
                );
                break;
            }

            case MIDIMessageTypes.programChange: {
                this.programChange(channel, message[1]);
                break;
            }

            case MIDIMessageTypes.polyPressure: {
                this.polyPressure(channel, message[1], message[2]);
                break;
            }

            case MIDIMessageTypes.channelPressure: {
                this.channelPressure(channel, message[1]);
                break;
            }

            case MIDIMessageTypes.systemExclusive: {
                this.systemExclusive(
                    new IndexedByteArray(message.slice(1)),
                    channelOffset
                );
                break;
            }

            case MIDIMessageTypes.reset: {
                this.reset();
                break;
            }

            default: {
                break;
            }
        }
    }

    /**
     * Assigns priorities to the voices.
     * Gets the priority of a voice based on its channel and state.
     * Higher priority means the voice is more important and should be kept longer.
     */
    private assignVoicePriorities() {
        if (this.lastPriorityAssignmentTime === this.currentTime) return;
        SpessaLog.info(
            "%cPolyphony exceeded, stealing voices",
            ConsoleColors.warn
        );
        this.lastPriorityAssignmentTime = this.currentTime;
        const cap = this.systemParameters.voiceCap;
        for (let i = 0; i < cap; i++) {
            const voice = this.voices[i];
            voice.priority = 0;
            if (this.midiChannels[voice.channel].drumChannel) {
                // Important
                voice.priority += 5;
            }
            if (voice.isInRelease) {
                // Not important
                voice.priority -= 5;
            }
            // Less velocity = less important
            voice.priority += voice.velocity / 25; // Map to 0-5
            // The newer, more important
            voice.priority -= voice.volEnv.state;
            voice.priority -= voice.volEnv.attenuationCb / 200;
        }
    }

    private updatePresetList(resetSynth: boolean) {
        const mainFont = this.soundBankManager.presetList;
        this.clearCache();
        this.callEvent("presetListChange", mainFont);
        this.getDefaultPresets();
        if (!resetSynth) {
            // Only point the channels at the new preset objects.
            // No program change, so controllers, drum parameters and playing voices stay as they are
            for (const c of this.midiChannels) {
                const locked = c.systemParameters.presetLock;
                // A locked channel keeps its patch, look up that one instead of the MIDI one
                const patch = locked ? c.preset : c.patch;
                if (!patch) continue;
                const preset = this.soundBankManager.getPreset(
                    patch,
                    locked ? c.lockedSystem : c.channelSystem
                );
                if (preset) c.preset = preset;
            }
            return;
        }
        // Update presets
        for (const c of this.midiChannels) {
            const lock = c.systemParameters.presetLock;
            // Unlock and set
            c.setSystemParameter("presetLock", false);
            c.programChange(c.patch.program);
            // Restore
            c.setSystemParameter("presetLock", lock);
        }
        this.reset();
    }

    private getDefaultPresets() {
        // Override this to XG, to set the default preset to NOT be XG drums!
        this.defaultPreset = this.soundBankManager.getPreset(
            {
                bankLSB: 0,
                bankMSB: 0,
                program: 0,
                isGMGSDrum: false
            },
            "xg"
        );
        this.drumPreset = this.soundBankManager.getPreset(
            {
                bankLSB: 0,
                bankMSB: 0,
                program: 0,
                isGMGSDrum: true
            },
            "gs"
        );
    }

    private getCachedVoiceIndex(
        patch: MIDIPatch,
        midiNote: number,
        velocity: number
    ) {
        const { isGMGSDrum, program, bankLSB } = patch;
        // Bank MSB is 0-127, GM/GS drums use 128-255 so they stay apart from melodic patches
        // The drum MSB and LSB both pick the kit
        const bankMSB = isGMGSDrum ? 128 + patch.bankMSB : patch.bankMSB;
        // 256x128x128x128x128 array!
        return (
            bankMSB + // 1
            bankLSB * 256 + // 256 * 128 ^ 0
            program * 32_768 + // 256 * 128 ^ 1
            4_194_304 * midiNote + // 256 * 128 ^ 2
            536_870_912 * velocity // 256 * 128 ^ 3
        );
    }
}
