import { IndexedByteArray } from "../../../utils/indexed_array";
import { writeBinaryStringIndexed } from "../../../utils/byte_functions/string";
import {
    writeDword,
    writeWord
} from "../../../utils/byte_functions/little_endian";
import { RIFFChunk } from "../../../utils/riff_chunk";
import { SF3_BIT_FLAG } from "../read/samples";
import type { BasicSoundBank } from "../../basic_soundbank/basic_soundbank";

import type { ExtendedSF2Chunks } from "./types";

export function getSHDR(
    bank: BasicSoundBank,
    smplStartOffsets: number[],
    smplEndOffsets: number[],
    rf64: boolean
): ExtendedSF2Chunks {
    const sampleLength = 46;
    const shdrSize = sampleLength * (bank.samples.length + 1); // +1 because EOS
    const shdrData = new IndexedByteArray(shdrSize);
    // https://github.com/spessasus/soundfont-proposals/blob/main/extended_limits.md
    const xshdrData = new IndexedByteArray(shdrSize);
    for (const [index, sample] of bank.samples.entries()) {
        // Sample name
        writeBinaryStringIndexed(shdrData, sample.name.slice(0, 20), 20);
        writeBinaryStringIndexed(xshdrData, sample.name.slice(20), 20);
        // Start offset
        const dwStart = smplStartOffsets[index];
        writeDword(shdrData, dwStart);
        xshdrData.currentIndex += 4;
        // End offset
        const dwEnd = smplEndOffsets[index];
        writeDword(shdrData, dwEnd);
        xshdrData.currentIndex += 4;
        // Loop is stored as relative in sample points, change it to absolute sample points here
        let loopStart = sample.loopStart + dwStart;
        let loopEnd = sample.loopEnd + dwStart;
        if (sample.isCompressed) {
            // https://github.com/FluidSynth/fluidsynth/wiki/SoundFont3Format
            loopStart -= dwStart;
            loopEnd -= dwStart;
        }
        writeDword(shdrData, loopStart);
        writeDword(shdrData, loopEnd);
        // Sample rate
        writeDword(shdrData, sample.sampleRate);
        // Pitch and correction
        shdrData[shdrData.currentIndex++] = sample.originalKey;
        shdrData[shdrData.currentIndex++] = sample.pitchCorrection;
        // Skip all those for xshdr
        xshdrData.currentIndex += 14;
        // Sample link
        const sampleLinkIndex = sample.linkedSample
            ? bank.samples.indexOf(sample.linkedSample)
            : 0;
        writeWord(shdrData, Math.max(0, sampleLinkIndex) & 0xff_ff);
        writeWord(xshdrData, Math.max(0, sampleLinkIndex) >> 16);
        // Sample type: add byte if compressed
        let type = sample.sampleType;
        if (sample.isCompressed) {
            type |= SF3_BIT_FLAG;
        }
        writeWord(shdrData, type);
        xshdrData.currentIndex += 2;
    }

    // Write EOS and zero everything else
    writeBinaryStringIndexed(shdrData, "EOS", sampleLength);
    writeBinaryStringIndexed(xshdrData, "EOS", sampleLength);
    const shdr = RIFFChunk.write("shdr", shdrData, rf64);
    const xshdr = RIFFChunk.write("shdr", xshdrData, rf64);
    return {
        pdta: shdr,
        xdta: xshdr
    };
}
