import { Generator } from "../../basic_soundbank/generator";
import { Modulator } from "../../basic_soundbank/modulator";
import type { BasicInstrument } from "../../basic_soundbank/basic_instrument";
import type { SoundFontPreset } from "./presets";
import { GeneratorTypes } from "../../basic_soundbank/generator_types";

/**
 * Preset_zones.ts
 * purpose: reads preset zones from soundfont and gets their respective samples and generators and modulators
 */

/**
 * Reads the given preset zone
 */
export function applyPresetZones(
    indexes: { mod: number[]; gen: number[] },
    presetGens: Generator[],
    presetMods: Modulator[],
    instruments: BasicInstrument[],
    presets: SoundFontPreset[]
) {
    const genStartIndexes = indexes.gen;
    const modStartIndexes = indexes.mod;

    let modIndex = 0;
    let genIndex = 0;
    for (const preset of presets) {
        for (let i = 0; i < preset.zonesCount; i++) {
            const gensStart = genStartIndexes[genIndex++];
            const gensEnd = genStartIndexes[genIndex];
            const gens = presetGens.slice(gensStart, gensEnd);
            const modsStart = modStartIndexes[modIndex++];
            const modsEnd = modStartIndexes[modIndex];
            const mods = presetMods.slice(modsStart, modsEnd);
            // Check for global zone
            if (gens.some((g) => g.type === GeneratorTypes.instrument)) {
                // Regular zone
                preset.createSoundFontZone(mods, gens, instruments);
            } else if (i === 0) {
                // Global zone, only the first zone may be global
                preset.globalZone.addGenerators(...gens);
                preset.globalZone.addModulators(...mods);
            }
            // Other zones without an instrument must be ignored (SF2 2.04 section 7.5)
        }
    }
}
