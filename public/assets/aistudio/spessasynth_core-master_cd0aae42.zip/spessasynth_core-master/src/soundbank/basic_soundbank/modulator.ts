import {
    type GeneratorType,
    GeneratorTypes,
    MAX_GENERATOR
} from "./generator_types";
import type { ModulatorSourceIndex } from "../types";
import {
    ModulatorControllerSources,
    type ModulatorCurveType,
    ModulatorCurveTypes,
    type ModulatorTransformType
} from "../enums";
import { MIDIControllers } from "../../midi/enums";
import { writeWord } from "../../utils/byte_functions/little_endian";
import type { IndexedByteArray } from "../../utils/indexed_array";
import { ModulatorSource } from "./modulator_source";
import type { SoundFontWriteIndexes } from "../soundfont/write/types";

/**
 * Modulators.ts
 * purpose: parses soundfont modulators and the source enums, also includes the default modulators list
 **/

export const MOD_BYTE_SIZE = 10;

export function getModSourceEnum(
    curveType: ModulatorCurveType,
    isBipolar: boolean,
    isNegative: boolean,
    isCC: boolean,
    index: ModulatorSourceIndex
): number {
    return new ModulatorSource(
        index,
        curveType,
        isCC,
        isBipolar,
        isNegative
    ).toSourceEnum();
}

export const DEFAULT_RESONANT_MOD_SOURCE = getModSourceEnum(
    ModulatorCurveTypes.linear,
    true,
    false,
    true,
    MIDIControllers.filterResonance
); // Linear forwards bipolar cc 71

/**
 * This class represents a single modulator (map from a source to a given synthesis parameter).
 *
 * > **Tip**
 * >
 * > Consider reading [Modulator Information](../../../docs/extra/modulator-information.md).
 *
 * @group Sound Banks.Modulators
 */
export class Modulator {
    /**
     * The destination generator for this modulator.
     * This is the target parameter that will be changed.
     */
    public destination: GeneratorType;

    /**
     * The transform amount for this modulator.
     * This is the multiplier of the transformation.
     */
    public transformAmount = 0;

    /**
     * The transform type for this modulator.
     * Usually no operation is performed.
     */
    public transformType: ModulatorTransformType = 0;

    /**
     * The primary source of this modulator.
     */
    public readonly primarySource: ModulatorSource;

    /**
     * The secondary source of this modulator.
     */
    public readonly secondarySource: ModulatorSource;

    /**
     * Creates a new modulator.
     * @param primarySource An optional primary source.
     * @param secondarySource An optional secondary source.
     * @param destination An optional destination can be set here.
     * @param amount An optional amount.
     * @param transformType An optional transform type.
     */
    public constructor(
        primarySource = new ModulatorSource(),
        secondarySource = new ModulatorSource(),
        destination: GeneratorType = GeneratorTypes.invalid,
        amount = 0,
        transformType: ModulatorTransformType = 0
    ) {
        this.primarySource = primarySource;
        this.secondarySource = secondarySource;

        this.destination = destination;
        this.transformAmount = amount;
        this.transformType = transformType;
    }

    private get destinationName() {
        return Object.keys(GeneratorTypes).find(
            (k) =>
                GeneratorTypes[k as keyof typeof GeneratorTypes] ===
                this.destination
        );
    }

    /**
     * Checks if the pair of modulators is identical (in SF2 terms)
     * @param mod1 Modulator 1 to compare.
     * @param mod2 Modulator 2 to compare.
     * @param checkAmount If the amount should be checked too. SF2 specification compares everything except amount.
     * @returns True if the two modulators are identical.
     */
    public static isIdentical(
        mod1: Modulator,
        mod2: Modulator,
        checkAmount = false
    ): boolean {
        return (
            mod1.primarySource.isIdentical(mod2.primarySource) &&
            mod1.secondarySource.isIdentical(mod2.secondarySource) &&
            mod1.destination === mod2.destination &&
            mod1.transformType === mod2.transformType &&
            (!checkAmount || mod1.transformAmount === mod2.transformAmount)
        );
    }

    /**
     * Copies a modulator.
     * @param mod The modulator to copy.
     * @returns The copied modulator.
     */
    public static copyFrom(mod: Modulator) {
        return new Modulator(
            ModulatorSource.copyFrom(mod.primarySource),
            ModulatorSource.copyFrom(mod.secondarySource),
            mod.destination,
            mod.transformAmount,
            mod.transformType
        );
    }

    public toString() {
        return (
            `Source: ${this.primarySource.toString()}\n` +
            `Secondary source: ${this.secondarySource.toString()}\n` +
            `to: ${this.destinationName}\n` +
            `amount: ${this.transformAmount}` +
            (this.transformType === 2 ? "absolute value" : "")
        );
    }

    /**
     * @internal
     * @param modData
     * @param indexes
     */
    public write(modData: IndexedByteArray, indexes?: SoundFontWriteIndexes) {
        writeWord(modData, this.primarySource.toSourceEnum());
        writeWord(modData, this.destination);
        writeWord(modData, this.transformAmount);
        writeWord(modData, this.secondarySource.toSourceEnum());
        writeWord(modData, this.transformType);
        if (!indexes) {
            return;
        }
        indexes.mod++;
    }

    /**
     * Sums transform and create a NEW modulator
     * @param modulator the modulator to sum with
     * @returns the new modulator
     * @internal
     */
    public sumTransform(modulator: Modulator): Modulator {
        const m = Modulator.copyFrom(this);
        m.transformAmount += modulator.transformAmount;
        return m;
    }
}

export class DecodedModulator extends Modulator {
    /**
     * Reads an SF2 modulator
     * @param sourceEnum SF2 source enum
     * @param secondarySourceEnum SF2 secondary source enum
     * @param destination destination
     * @param amount amount
     * @param transformType transform type
     */
    public constructor(
        sourceEnum: number,
        secondarySourceEnum: number,
        destination: GeneratorType,
        amount: number,
        transformType: number
    ) {
        super(
            ModulatorSource.fromSourceEnum(sourceEnum),
            ModulatorSource.fromSourceEnum(secondarySourceEnum),
            destination,
            amount,
            transformType as ModulatorTransformType
        );

        if (this.destination > MAX_GENERATOR) {
            this.destination = GeneratorTypes.invalid; // Flag as invalid (for linked ones)
        }
    }
}

const defaultSoundFont2Modulators = [
    // Vel to attenuation
    new DecodedModulator(
        getModSourceEnum(
            ModulatorCurveTypes.concave,
            false,
            true,
            false,
            ModulatorControllerSources.noteOnVelocity
        ),
        0x0,
        GeneratorTypes.initialAttenuation,
        960,
        0
    ),

    // Mod wheel to vibrato
    new DecodedModulator(0x00_81, 0x0, GeneratorTypes.vibLfoToPitch, 50, 0),

    // Vol to attenuation
    new DecodedModulator(
        getModSourceEnum(
            ModulatorCurveTypes.concave,
            false,
            true,
            true,
            MIDIControllers.mainVolume
        ),
        0x0,
        GeneratorTypes.initialAttenuation,
        960,
        0
    ),

    // Channel pressure to vibrato
    new DecodedModulator(0x00_0d, 0x0, GeneratorTypes.vibLfoToPitch, 50, 0),

    // Pitch wheel to tuning
    new DecodedModulator(0x02_0e, 0x00_10, GeneratorTypes.fineTune, 12_700, 0),

    // Pan to uhh, pan
    // Amount is 500 instead of 1000, see #59
    new DecodedModulator(0x02_8a, 0x0, GeneratorTypes.pan, 500, 0),

    // Expression to attenuation
    new DecodedModulator(
        getModSourceEnum(
            ModulatorCurveTypes.concave,
            false,
            true,
            true,
            MIDIControllers.expression
        ),
        0x0,
        GeneratorTypes.initialAttenuation,
        960,
        0
    ),

    // Reverb effects to send
    new DecodedModulator(
        0x00_db,
        0x0,
        GeneratorTypes.reverbEffectsSend,
        200,
        0
    ),

    // Chorus effects to send
    new DecodedModulator(0x00_dd, 0x0, GeneratorTypes.chorusEffectsSend, 200, 0)
];

/**
 * One term of an envelope time response: a bipolar CC source gated to one half of the CC.
 * @param cc the controller
 * @param curve the curve of the bipolar source
 * @param destination the envelope generator
 * @param amount the amount in timecents
 * @param below true for the half under 64, false for the half over it
 */
function envelopeCC(
    cc: number,
    curve: ModulatorCurveType,
    destination: GeneratorType,
    amount: number,
    below: boolean
) {
    return new DecodedModulator(
        getModSourceEnum(curve, true, false, true, cc as ModulatorSourceIndex),
        getModSourceEnum(
            ModulatorCurveTypes.switch,
            false,
            below,
            true,
            cc as ModulatorSourceIndex
        ),
        destination,
        amount,
        0
    );
}

const defaultSpessaSynthModulators = [
    // Custom modulators heck yeah

    // Attack
    envelopeCC(
        MIDIControllers.attackTime,
        ModulatorCurveTypes.linear,
        GeneratorTypes.attackVolEnv,
        9600,
        true
    ),
    envelopeCC(
        MIDIControllers.attackTime,
        ModulatorCurveTypes.linear,
        GeneratorTypes.attackVolEnv,
        9657,
        false
    ),
    envelopeCC(
        MIDIControllers.attackTime,
        ModulatorCurveTypes.convex,
        GeneratorTypes.attackVolEnv,
        -1445,
        false
    ),

    // Decay
    envelopeCC(
        MIDIControllers.decayTime,
        ModulatorCurveTypes.linear,
        GeneratorTypes.decayVolEnv,
        9779,
        true
    ),
    envelopeCC(
        MIDIControllers.decayTime,
        ModulatorCurveTypes.linear,
        GeneratorTypes.decayVolEnv,
        -2997,
        false
    ),
    envelopeCC(
        MIDIControllers.decayTime,
        ModulatorCurveTypes.concave,
        GeneratorTypes.releaseVolEnv,
        8035,
        false
    ),
    envelopeCC(
        MIDIControllers.decayTime,
        ModulatorCurveTypes.convex,
        GeneratorTypes.decayVolEnv,
        435,
        false
    ),

    // Release
    envelopeCC(
        MIDIControllers.releaseTime,
        ModulatorCurveTypes.linear,
        GeneratorTypes.releaseVolEnv,
        9779,
        true
    ),
    envelopeCC(
        MIDIControllers.releaseTime,
        ModulatorCurveTypes.linear,
        GeneratorTypes.releaseVolEnv,
        -2997,
        false
    ),
    envelopeCC(
        MIDIControllers.releaseTime,
        ModulatorCurveTypes.concave,
        GeneratorTypes.releaseVolEnv,
        8035,
        false
    ),
    envelopeCC(
        MIDIControllers.releaseTime,
        ModulatorCurveTypes.convex,
        GeneratorTypes.releaseVolEnv,
        435,
        false
    ),

    // Cc 74 (brightness) to filterFc
    new DecodedModulator(
        getModSourceEnum(
            ModulatorCurveTypes.linear,
            true,
            false,
            true,
            MIDIControllers.brightness
        ), // Linear forwards bipolar cc 74
        0x0, // No controller
        GeneratorTypes.initialFilterFc,
        9600,
        0
    ),

    // Cc 71 (filter Q) to filter Q (default resonant modulator)
    new DecodedModulator(
        DEFAULT_RESONANT_MOD_SOURCE,
        0x0, // No controller
        GeneratorTypes.initialFilterQ,
        250,
        0
    ),
    // Cc 67 (soft pedal) to filter fc
    new DecodedModulator(
        getModSourceEnum(
            ModulatorCurveTypes.switch,
            false,
            false,
            true,
            MIDIControllers.softPedal
        ), // Switch unipolar positive 67
        0x0, // No controller
        GeneratorTypes.initialFilterFc,
        -1200,
        0
    )
];

export const SPESSASYNTH_DEFAULT_MODULATORS: Modulator[] = [
    ...defaultSoundFont2Modulators,
    ...defaultSpessaSynthModulators
];
