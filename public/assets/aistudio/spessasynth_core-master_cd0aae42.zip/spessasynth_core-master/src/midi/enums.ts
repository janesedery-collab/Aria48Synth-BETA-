/**
 * All MIDI 1.0 defined status bytes
 *
 * > **Tip**
 * >
 * > Consider reading the [supported MIDI messages](../../docs/extra/midi-implementation.md#supported-midi-messages) for more information.
 *
 * @group MIDI.Protocol
 */
export const MIDIMessageTypes = {
    noteOff: 0x80,
    noteOn: 0x90,
    polyPressure: 0xa0,
    controllerChange: 0xb0,
    programChange: 0xc0,
    channelPressure: 0xd0,
    pitchWheel: 0xe0,
    systemExclusive: 0xf0,
    timecode: 0xf1,
    songPosition: 0xf2,
    songSelect: 0xf3,
    tuneRequest: 0xf6,
    /**
     * SMF SysEx escape or continuation event.
     * The data holds the raw bytes that follow the length.
     * https://foldoc.org/pub/misc/midi_file_spec
     */
    systemExclusiveEscape: 0xf7,
    clock: 0xf8,
    start: 0xfa,
    continue: 0xfb,
    stop: 0xfc,
    activeSensing: 0xfe,
    reset: 0xff,
    sequenceNumber: 0x00,
    text: 0x01,
    copyright: 0x02,
    trackName: 0x03,
    instrumentName: 0x04,
    lyric: 0x05,
    marker: 0x06,
    cuePoint: 0x07,
    programName: 0x08,
    midiChannelPrefix: 0x20,
    midiPort: 0x21,
    endOfTrack: 0x2f,
    setTempo: 0x51,
    smpteOffset: 0x54,
    timeSignature: 0x58,
    keySignature: 0x59,
    sequenceSpecific: 0x7f
} as const;

/**
 * @inheritDoc MIDIMessageTypes
 *
 * @group MIDI.Protocol
 */
export type MIDIMessageType =
    (typeof MIDIMessageTypes)[keyof typeof MIDIMessageTypes];

/**
 * All MIDI 1.0 controller numbers.
 *
 * > **Tip**
 * >
 * > Consider reading the [default supported controllers](../../docs/extra/midi-implementation.md#default-supported-controllers) for more information.
 *
 * @group MIDI.Protocol
 */
export const MIDIControllers = {
    bankSelect: 0,
    modulationWheel: 1,
    breathController: 2,
    undefinedCC3: 3,
    footController: 4,
    portamentoTime: 5,
    dataEntryMSB: 6,
    mainVolume: 7,
    balance: 8,
    undefinedCC9: 9,
    pan: 10,
    expression: 11,
    effectControl1: 12,
    effectControl2: 13,
    undefinedCC14: 14,
    undefinedCC15: 15,
    generalPurposeController1: 16,
    generalPurposeController2: 17,
    generalPurposeController3: 18,
    generalPurposeController4: 19,
    undefinedCC20: 20,
    undefinedCC21: 21,
    undefinedCC22: 22,
    undefinedCC23: 23,
    undefinedCC24: 24,
    undefinedCC25: 25,
    undefinedCC26: 26,
    undefinedCC27: 27,
    undefinedCC28: 28,
    undefinedCC29: 29,
    undefinedCC30: 30,
    undefinedCC31: 31,
    bankSelectLSB: 32,
    modulationWheelLSB: 33,
    breathControllerLSB: 34,
    undefinedCC3LSB: 35,
    footControllerLSB: 36,
    portamentoTimeLSB: 37,
    dataEntryLSB: 38,
    mainVolumeLSB: 39,
    balanceLSB: 40,
    undefinedCC9LSB: 41,
    panLSB: 42,
    expressionLSB: 43,
    effectControl1LSB: 44,
    effectControl2LSB: 45,
    undefinedCC14LSB: 46,
    undefinedCC15LSB: 47,
    generalPurposeController1LSB: 48,
    generalPurposeController2LSB: 49,
    generalPurposeController3LSB: 50,
    generalPurposeController4LSB: 51,
    undefinedCC20LSB: 52,
    undefinedCC21LSB: 53,
    undefinedCC22LSB: 54,
    undefinedCC23LSB: 55,
    undefinedCC24LSB: 56,
    undefinedCC25LSB: 57,
    undefinedCC26LSB: 58,
    undefinedCC27LSB: 59,
    undefinedCC28LSB: 60,
    undefinedCC29LSB: 61,
    undefinedCC30LSB: 62,
    undefinedCC31LSB: 63,
    sustainPedal: 64,
    portamentoOnOff: 65,
    sostenutoPedal: 66,
    softPedal: 67,
    legatoFootswitch: 68,
    hold2Pedal: 69,
    soundVariation: 70,
    filterResonance: 71,
    releaseTime: 72,
    attackTime: 73,
    brightness: 74,
    decayTime: 75,
    vibratoRate: 76,
    vibratoDepth: 77,
    vibratoDelay: 78,
    soundController10: 79,
    generalPurposeController5: 80,
    generalPurposeController6: 81,
    generalPurposeController7: 82,
    generalPurposeController8: 83,
    portamentoControl: 84,
    undefinedCC85: 85,
    undefinedCC86: 86,
    undefinedCC87: 87,
    undefinedCC88: 88,
    undefinedCC89: 89,
    undefinedCC90: 90,
    reverbDepth: 91,
    tremoloDepth: 92,
    chorusDepth: 93,
    variationDepth: 94,
    phaserDepth: 95,
    dataIncrement: 96,
    dataDecrement: 97,
    nonRegisteredParameterLSB: 98,
    nonRegisteredParameterMSB: 99,
    registeredParameterLSB: 100,
    registeredParameterMSB: 101,
    undefinedCC102: 102,
    undefinedCC103: 103,
    undefinedCC104: 104,
    undefinedCC105: 105,
    undefinedCC106: 106,
    undefinedCC107: 107,
    undefinedCC108: 108,
    undefinedCC109: 109,
    undefinedCC110: 110,
    undefinedCC111: 111,
    undefinedCC112: 112,
    undefinedCC113: 113,
    undefinedCC114: 114,
    undefinedCC115: 115,
    undefinedCC116: 116,
    undefinedCC117: 117,
    undefinedCC118: 118,
    undefinedCC119: 119,
    allSoundOff: 120,
    resetAllControllers: 121,
    localControlOnOff: 122,
    allNotesOff: 123,
    omniModeOff: 124,
    omniModeOn: 125,
    monoModeOn: 126,
    polyModeOn: 127,

    // Deprecated old names, kept until the next major version.
    // They come last so reverse lookups find the new names first.
    /**
     * @deprecated Use {@link MIDIControllers.generalPurposeController1LSB} instead.
     */
    undefinedCC16LSB: 48,
    /**
     * @deprecated Use {@link MIDIControllers.generalPurposeController2LSB} instead.
     */
    undefinedCC17LSB: 49,
    /**
     * @deprecated Use {@link MIDIControllers.generalPurposeController3LSB} instead.
     */
    undefinedCC18LSB: 50,
    /**
     * @deprecated Use {@link MIDIControllers.generalPurposeController4LSB} instead.
     */
    undefinedCC19LSB: 51,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC102} instead.
     */
    undefinedCC102LSB: 102,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC103} instead.
     */
    undefinedCC103LSB: 103,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC104} instead.
     */
    undefinedCC104LSB: 104,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC105} instead.
     */
    undefinedCC105LSB: 105,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC106} instead.
     */
    undefinedCC106LSB: 106,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC107} instead.
     */
    undefinedCC107LSB: 107,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC108} instead.
     */
    undefinedCC108LSB: 108,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC109} instead.
     */
    undefinedCC109LSB: 109,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC110} instead.
     */
    undefinedCC110LSB: 110,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC111} instead.
     */
    undefinedCC111LSB: 111,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC112} instead.
     */
    undefinedCC112LSB: 112,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC113} instead.
     */
    undefinedCC113LSB: 113,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC114} instead.
     */
    undefinedCC114LSB: 114,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC115} instead.
     */
    undefinedCC115LSB: 115,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC116} instead.
     */
    undefinedCC116LSB: 116,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC117} instead.
     */
    undefinedCC117LSB: 117,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC118} instead.
     */
    undefinedCC118LSB: 118,
    /**
     * @deprecated Use {@link MIDIControllers.undefinedCC119} instead.
     */
    undefinedCC119LSB: 119
} as const;

/**
 * @inheritDoc MIDIControllers
 *
 * @group MIDI.Protocol
 */
export type MIDIController =
    (typeof MIDIControllers)[keyof typeof MIDIControllers];

/**
 * General MIDI Registered Parameter Numbers.
 *
 * @group MIDI.Protocol
 */
export const RegisteredParameterTypes = {
    pitchWheelRange: 0x00_00,
    fineTuning: 0x00_01,
    coarseTuning: 0x00_02,
    modulationDepth: 0x00_05,
    resetParameters: 0x3f_ff
} as const;

/**
 * Roland GS/ Yamaha XG Non-Registered Parameter Numbers (MSB).
 *
 * Sources:
 * - https://cdn.roland.com/assets/media/pdf/SC-8850_OM.pdf
 * - http://hummer.stanford.edu/sig/doc/classes/MidiOutput/rpn.html
 *
 * @group MIDI.Protocol
 */
export const NonRegisteredParameterTypesMSB = {
    partParameter: 0x01,
    drumPitch: 0x18,
    drumPitchFine: 0x19,
    drumLevel: 0x1a,
    drumPan: 0x1c,
    drumReverb: 0x1d,
    drumChorus: 0x1e,
    drumVariation: 0x1f,

    awe32: 0x7f,
    SF2: 120
} as const;

/**
 * Roland GS/ Yamaha XG Non-Registered Parameter Numbers (LSB).
 *
 * Sources:
 * - https://cdn.roland.com/assets/media/pdf/SC-8850_OM.pdf
 * - http://hummer.stanford.edu/sig/doc/classes/MidiOutput/rpn.html
 *
 * @group MIDI.Protocol
 */
export const NonRegisteredParameterTypesLSB = {
    vibratoRate: 0x08,
    vibratoDepth: 0x09,
    vibratoDelay: 0x0a,

    tvfCutoffFrequency: 0x20,
    tvfResonance: 0x21,

    envelopeAttackTime: 0x63,
    envelopeDecayTime: 0x64,
    envelopeReleaseTime: 0x66
} as const;
