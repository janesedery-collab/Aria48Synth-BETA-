import type { BasicMIDI } from "../basic_midi";
import type { SynthesizerSnapshot } from "../../synthesizer/audio_engine/synthesizer_snapshot";
import type { MIDIPatch } from "../../soundbank/basic_soundbank/midi_patch";
import { type MIDIController, MIDIControllers } from "../enums";
import { CONTROLLER_TABLE_SIZE } from "../../synthesizer/audio_engine/synth_constants";
import type {
    ChannelModification,
    ClearableParameter,
    UserDrumModification
} from "./midi_editor";
import type { ChannelMIDIParameter } from "../../synthesizer/audio_engine/channel/parameters/midi";
import type { GlobalMIDIParameter } from "../../synthesizer/audio_engine/parameters/midi";
import { DrumParameterUtils } from "../drum_parameters";

/**
 * Modifies the sequence *in-place* according to the locked presets and controllers in the given snapshot.
 *
 * Note that System Parameters `fineTune` and `keyShift` are passed to the relative tuning parameters of the channels.
 * Only locked MIDI parameters and controllers are applied.
 */
export function applySnapshotInternal(
    midi: BasicMIDI,
    snapshot: SynthesizerSnapshot
) {
    const channels = new Map<number, ClearableParameter<ChannelModification>>();
    const globalKeyShift = snapshot.systemParameters.keyShift;
    const globalFineTune = snapshot.systemParameters.fineTune;
    for (
        let channelNumber = 0;
        channelNumber < snapshot.midiChannels.length;
        channelNumber++
    ) {
        const channelSnapshot = snapshot.midiChannels[channelNumber];
        if (channelSnapshot.systemParameters.isMuted) {
            channels.set(channelNumber, "clear");
            continue;
        }
        const keyShift =
            channelSnapshot.systemParameters.keyShift +
            (channelSnapshot.drumChannel ? 0 : globalKeyShift);
        const fineTune =
            channelSnapshot.systemParameters.fineTune +
            (channelSnapshot.drumChannel ? 0 : globalFineTune);
        let patch: MIDIPatch | undefined;
        if (
            channelSnapshot.systemParameters.presetLock &&
            channelSnapshot.patch
        ) {
            patch = { ...channelSnapshot.patch };
        }

        const controllers = new Map<MIDIController, number>();
        for (let ccNumber = 0; ccNumber < CONTROLLER_TABLE_SIZE; ccNumber++) {
            if (
                !channelSnapshot.lockedControllers[ccNumber] ||
                ccNumber === MIDIControllers.bankSelect
            ) {
                continue;
            }
            const targetValue = channelSnapshot.midiControllers[ccNumber] >> 7; // Channel controllers are stored as 14 bit values
            controllers.set(ccNumber as MIDIController, targetValue);
        }

        const midiParams = {} as {
            [P in keyof ChannelMIDIParameter]?: ClearableParameter<
                ChannelMIDIParameter[P]
            >;
        };

        for (const [parameter, value] of Object.entries(
            channelSnapshot.midiParameters
        ) as {
            [K in keyof ChannelMIDIParameter]: [K, ChannelMIDIParameter[K]];
        }[keyof ChannelMIDIParameter][]) {
            if (channelSnapshot.lockedMIDIParameters[parameter])
                // Strange cast, but works?
                midiParams[parameter] = value as never;
        }

        channels.set(channelNumber, {
            keyShift,
            fineTune,
            patch,
            controllers,
            midiParams,
            // Drum lock clears all drum edits for every channel
            drumParams: snapshot.systemParameters.drumLock ? "clear" : undefined
        });
    }

    const midiParams = {} as {
        [P in keyof GlobalMIDIParameter]?: ClearableParameter<
            GlobalMIDIParameter[P]
        >;
    };

    for (const [parameter, value] of Object.entries(
        snapshot.midiParameters
    ) as {
        [K in keyof GlobalMIDIParameter]: [K, GlobalMIDIParameter[K]];
    }[keyof GlobalMIDIParameter][]) {
        if (snapshot.lockedMIDIParameters[parameter])
            // Strange cast, but works?
            midiParams[parameter] = value as never;
    }

    // User Drum set
    const userDrumParams = new Map<number, UserDrumModification>();
    if (snapshot.systemParameters.userDrumLock) {
        for (
            let drumSetNumber = 0;
            drumSetNumber < snapshot.userDrumSets.length;
            drumSetNumber++
        ) {
            const userDrumSet = snapshot.userDrumSets[drumSetNumber];
            // Only set the ones that were changed
            const drumSetParams: UserDrumModification = new Map();
            for (let midiNote = 0; midiNote < userDrumSet.length; midiNote++) {
                const param = userDrumSet[midiNote];
                if (!DrumParameterUtils.isUserDefault(param, midiNote)) {
                    drumSetParams.set(midiNote, { ...param });
                }
            }
            userDrumParams.set(drumSetNumber, drumSetParams);
        }
    }

    midi.modify({
        channels,
        gsReverbParams: snapshot.systemParameters.gsReverbLock
            ? snapshot.gsReverbProcessor
            : undefined,
        gsChorusParams: snapshot.systemParameters.gsChorusLock
            ? snapshot.gsChorusProcessor
            : undefined,
        gsDelayParams: snapshot.systemParameters.gsDelayLock
            ? snapshot.gsDelayProcessor
            : undefined,
        gsEqualizerParams: snapshot.systemParameters.gsEqualizerLock
            ? snapshot.gsEqualizerProcessor
            : undefined,
        gsInsertionParams: snapshot.systemParameters.gsInsertionLock
            ? snapshot.gsInsertionBlock
            : undefined,
        // XG blocks have dedicated locks mirroring the GS ones.
        xgReverbParams: snapshot.systemParameters.xgReverbLock
            ? snapshot.xgReverbBlock
            : undefined,
        xgChorusParams: snapshot.systemParameters.xgChorusLock
            ? snapshot.xgChorusBlock
            : undefined,
        xgVariationParams: snapshot.systemParameters.xgVariationLock
            ? snapshot.xgVariationBlock
            : undefined,
        xgInsertionParams: snapshot.systemParameters.xgInsertionLock
            ? new Map(
                  snapshot.xgInsertionBlocks.map(
                      (block, index) => [index, block] as const
                  )
              )
            : undefined,
        userDrumParams,
        midiParams
    });
}
