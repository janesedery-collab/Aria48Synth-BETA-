---
title: Modulator Information
---

# Modulator Information

Modulators are an SF2 feature fully supported in `spessasynth_core`,
allowing for real-time parameter manipulation with MIDI commands.

Below is useful information regarding the implementation of modulators in `spessasynth_core`.

## Modulator sources

Below is the table of modulator sources if the CC flag is not set.
If it is set, the index is the MIDI controller number.

| Index | Name               | Description                                                                                                                                                                                                         |
| ----- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 0     | No controller = 1  | Always returns 1.                                                                                                                                                                                                   |
| 2     | Note on velocity   | The MIDI velocity the note was pressed with.                                                                                                                                                                        |
| 3     | Note on key number | The MIDI key number received.                                                                                                                                                                                       |
| 10    | Poly pressure      | The MIDI poly pressure message received for this note number.                                                                                                                                                       |
| 13    | Channel pressure   | The MIDI channel pressure message received for this channel.                                                                                                                                                        |
| 14    | Pitch Wheel        | The pitch wheel value, 14-bit.                                                                                                                                                                                      |
| 16    | Pitch Wheel range  | The range of the pitch wheel, in semitones.                                                                                                                                                                         |
| 127   | Link (UNSUPPORTED) | Other modulator. This feature is underspecified and not implemented, [similarly to fluidsynth](https://github.com/FluidSynth/fluidsynth/wiki/SoundFont#fluidsynths-implementation-details-of-the-soundfont-2-spec). |

## Modulator curve types

Below are the defined curve types of modulators:

- 0 Linear - normal linear scale
- 1 Concave - logarithmic ramp
- 2 Convex - exponential ramp, the inverse of concave
- 3 Switch - 0.5 and below is 0 (or -1 for bipolar), above is 1

## Default Modulators

Below is the default modulator list for SpessaSynth.

> **Important**
>
> SpessaSynth implements the [default modulators proposal](https://github.com/spessasus/soundfont-proposals/blob/main/default_modulators.md).

Units used in the tables below:

- cB - centibels, 1/10 of a decibel.
- ‰ - 1/10 of a percent.

### SF2 Default

These are the default modulators, as defined by the SF2.04 specification.

`-` denotes source enumeration `0x0` (no controller linear unipolar positive).

> **Note**
>
> The [velocity to filter modulator is intentionally disabled](https://www.fluidsynth.org/wiki/SoundFont/#fluidsynths-implementation-details-of-the-soundfont-2-spec).

| Source                      | Source Transform          | Secondary source                           | Destination          | Transform amount |
| --------------------------- | ------------------------- | ------------------------------------------ | -------------------- | ---------------- |
| Note On Velocity            | Negative Unipolar Concave | -                                          | Initial attenuation  | 960 cB           |
| **CC 1** (Modulation Wheel) | Positive Unipolar Linear  | -                                          | Vibrato LFO to pitch | 50 cents         |
| **CC 7** (Volume)           | Negative Unipolar Concave | -                                          | Initial attenuation  | 960 cB           |
| **Channel Pressure**        | Positive Unipolar Linear  | -                                          | Vibrato LFO to pitch | 50 cents         |
| **Pitch Wheel**             | Positive Bipolar Linear   | Pitch wheel range Positive Unipolar Linear | Fine tune            | 12700 cents      |
| **CC 10** (Pan)             | Positive Bipolar Linear   | -                                          | Pan                  | 500 ‰            |
| **CC 11** (Expression)      | Negative Unipolar Concave | -                                          | Initial attenuation  | 960 cB           |
| **CC 91** (Reverb Depth)    | Positive Unipolar Linear  | -                                          | Reverb effects send  | 200 ‰            |
| **CC 93** (Chorus Depth)    | Positive Unipolar Linear  | -                                          | Chorus effects send  | 200 ‰            |

### Custom modulators

SpessaSynth applies a few extra modulators for extended compatibility with various MIDI standards.

| Source                       | Source Transform         | Secondary source | Destination              | Transform amount |
| ---------------------------- | ------------------------ | ---------------- | ------------------------ | ---------------- |
| **CC 67** (Soft Pedal)       | Switch Unipolar Positive | -                | Initial Filter Cutoff    | -1200 abs cents  |
| **CC 71** (Filter Resonance) | Positive Bipolar Linear  | -                | Initial Filter Resonance | 250 cB           |
| **CC 74** (Filter Cutoff)    | Positive Bipolar Linear  | -                | Initial Filter Cutoff    | 9600 abs cents   |

### Envelope time modulators

Envelope time modulators each use several modulators.
All of them have the CC as a bipolar primary source.
The secondary source is a switch on the same CC that limits the modulator to one half of its range:

- `CC < 64` - Negative Unipolar Switch
- `CC >= 64` - Positive Unipolar Switch

Their sum forms the response curve of the time controllers.

| Primary source              | Primary transform        | Secondary source | Destination             | Transform amount |
| --------------------------- | ------------------------ | ---------------- | ----------------------- | ---------------- |
| **CC 73** (Vol Env Attack)  | Positive Bipolar Linear  | `CC < 64`        | Volume envelope attack  | 9600 timecents   |
| **CC 73** (Vol Env Attack)  | Positive Bipolar Linear  | `CC >= 64`       | Volume envelope attack  | 9657 timecents   |
| **CC 73** (Vol Env Attack)  | Positive Bipolar Convex  | `CC >= 64`       | Volume envelope attack  | -1445 timecents  |
| **CC 75** (Vol Env Decay)   | Positive Bipolar Linear  | `CC < 64`        | Volume envelope decay   | 9779 timecents   |
| **CC 75** (Vol Env Decay)   | Positive Bipolar Linear  | `CC >= 64`       | Volume envelope decay   | -2997 timecents  |
| **CC 75** (Vol Env Decay)   | Positive Bipolar Concave | `CC >= 64`       | Volume envelope release | 8035 timecents   |
| **CC 75** (Vol Env Decay)   | Positive Bipolar Convex  | `CC >= 64`       | Volume envelope decay   | 435 timecents    |
| **CC 72** (Vol Env Release) | Positive Bipolar Linear  | `CC < 64`        | Volume envelope release | 9779 timecents   |
| **CC 72** (Vol Env Release) | Positive Bipolar Linear  | `CC >= 64`       | Volume envelope release | -2997 timecents  |
| **CC 72** (Vol Env Release) | Positive Bipolar Concave | `CC >= 64`       | Volume envelope release | 8035 timecents   |
| **CC 72** (Vol Env Release) | Positive Bipolar Convex  | `CC >= 64`       | Volume envelope release | 435 timecents    |

### Resonant modulator

SpessaSynth treats a specific modulator as a _resonant modulator._ That is:

- Source 1: CC 71 Positive Bipolar Linear
- Source 2: No controller Positive Unipolar Linear (0x0)
- Destination: Initial Filter Resonance

This modulator is coded to not affect the DSP gain like the SF2 specification requires.
This is done because neither XG nor GS reacted that way to CC 71.
Other than that, the filter is fully to the spec.
All other modulators/generators affect the gain as the spec requires.

This approach allows the soundfont engineer to overwrite or delete the modulator, while maintaining the same behavior.

### Reverb and Chorus modulators

SpessaSynth has custom behavior for these modulators, emulating BASSMIDI:

- The modulators affected are all modulators
  that use **Reverb depth Positive Unipolar Linear or Chorus depth Positive Unipolar Linear** as a primary source
  and **No Controller** as the secondary source and either **reverbEffectsSend** or **chorusEffectsSend** as the
  destination
- The transform amount is multiplied by **5** if the initial transform amount is 1000 or below
- If the transform is multiplied, it is capped at **1000**.

#### Reasoning

The amount of `200` (SF2 default) is too low for these modulators, according to Ian from [Un4seen.](https://www.un4seen.com/)
I agree with this,
and also set the default to `1000` (actually it's `200` multiplied by `5` which is `1000`).
But this poses a few problems without using the solution above:

- Sound banks that assume default reverb of `200` will have almost inaudible effects.
  For example, a soundfont might want to slightly decrease the reverb, by setting it to `150`, for example.
  It is way less than the default `1000`,
  and the approach above will make it `150 * 5 = 750` which is still less than default,
  but more audible.
- This approach still allows disabling these modulators.
- Some soundfonts assume a default reverb of `1000` and set some to `800` or similar.
  Using default `200` will cause a big imbalance between the custom and default modulators.
